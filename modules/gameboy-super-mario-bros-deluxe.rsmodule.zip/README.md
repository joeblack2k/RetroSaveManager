# Super Mario Bros. Deluxe Game Boy Module

This module provides structural, read-only support for Super Mario Bros. Deluxe SRAM.

The parser accepts non-blank 8 KiB raw SRAM, matching the documented cartridge SRAM size. No semantic write fields are exposed because a trustworthy save map, checksum rule, or mirrored-slot rule was not found during intake.

The only cheat-pack field is an inert `Keep Current Save` value. Applying it returns the original payload unchanged.

Research sources:

- Data Crystal Super Mario Bros. Deluxe cartridge notes for 8 KiB SRAM.

Known limitation:

- Zophar-hosted Super Mario Bros. Deluxe files inspected during research were emulator savestates, not raw SRAM samples, so they were not used as write proof.
