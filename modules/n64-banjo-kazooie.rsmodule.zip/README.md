# Banjo-Kazooie Game Support Module

This module validates Banjo-Kazooie Nintendo 64 EEPROM saves and exposes checksum-repaired inventory, playtime, note score, location flag, move/tutorial, progress, and Stop n Swop fields.

Supported payloads:

- 512-byte native 4Kbit EEPROM save data.
- 2048-byte emulator EEPROM windows whose first 0x200 bytes contain the Banjo-Kazooie save data.
- 296960-byte RetroArch N64 SRM containers, read-only for semantic details and cheat reads.

Validation uses the BKSaveEditor/Game Tools Collection 0x78-byte slot layout and 32-bit Rare checksum. Active slots require magic `0x11`, display slot remapping for internal slot values 2/3, and a valid checksum over bytes `0x00-0x73` of the slot. Empty/deleted saves can still parse through the valid global Stop n Swop checksum, but no editable slot fields are exposed unless an active slot exists.

Editable fields are limited to byte/bit fields independently confirmed by BKSaveEditor and Game Tools Collection: held items, capacity flags, per-level playtime seconds, per-level note scores, individual Jiggy/Mumbo Token/Extra Honeycomb location flags, learned abilities, used ability tutorial flags, named progress flags, and global Stop n Swop unlocked/obtained flags. Native EEPROM writes rebuild the selected slot checksum and, for Stop n Swop edits, the global checksum. RetroArch SRM containers are parsed/read-only.
