# Mortal Kombat Shaolin Monks PS2 Module

Read-only structural support for the verified Mortal Kombat Shaolin Monks entry in the repository PS2 memory-card fixture.

## Supported Payloads

- 1,037-byte RSM-style PS2 logical ZIP containing `BASLUS-21087/icon.sys` and `BASLUS-21087/game.icn`.

The module validates the logical ZIP central directory and the CRC32 values from the real fixture:

| file | size | crc32 |
|---|---:|---:|
| `BASLUS-21087/icon.sys` | 964 | `f73051b5` |
| `BASLUS-21087/game.icn` | 32896 | `706f9951` |

`icon.sys` in the fixture has `PS2D` magic, title line one `Mortal Kombat`, title line two `Shaolin Monks`, and normal icon file `game.icn`.

## Editable Surface

No editable fields are exposed. The available sample contains only `icon.sys` and `game.icn`, not a gameplay data file. No unlock flags, counters, checksum repair, or mirrored-write rule were proven.
