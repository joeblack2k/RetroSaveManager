let heap: usize = 32768;
let gOut: usize = 0;
let gPos: i32 = 0;
let gChanged: i32 = 0;

const KIND_NONE: i32 = 0;
const KIND_EEPROM: i32 = 1;
const KIND_CPAK: i32 = 2;

export function rsm_alloc(len: i32): i32 {
  const ptr = heap;
  heap += <usize>((len + 15) & ~15);
  ensureMemory(heap);
  return <i32>ptr;
}

export function rsm_call(commandPtr: i32, commandLen: i32, inputPtr: i32, inputLen: i32): i64 {
  const cmd = <usize>commandPtr;
  const input = <usize>inputPtr;
  if (eq(cmd, commandLen, "capabilities")) return finishStatic('{"supported":true,"parserId":"wr64-save","abiVersion":"rsm-wasm-json-v1"}');
  if (eq(cmd, commandLen, "parse")) return handleParse(input, inputLen);
  if (eq(cmd, commandLen, "readCheats")) return handleRead(input, inputLen);
  if (eq(cmd, commandLen, "applyCheats")) return handleApply(input, inputLen);
  return finishStatic('{"supported":false,"warnings":["unsupported command"]}');
}

function handleParse(input: usize, inputLen: i32): i64 {
  const p64 = decodePayload(input, inputLen);
  const payloadPtr = <usize>(p64 >> 32);
  const payloadLen = <i32>(p64 & 0xffffffff);
  const kind = payloadKind(payloadPtr, payloadLen);
  if (kind == KIND_NONE) return finishStatic('{"supported":false,"warnings":["Wave Race 64 EEPROM or Controller Pak structure did not validate"]}');
  const out = allocOut(4096);
  let pos = 0;
  pos = write(out, pos, '{"supported":true,"parserLevel":"semantic","parserId":"wr64-save","validatedSystem":"n64","validatedGameId":"n64/wave-race-64","validatedGameTitle":"Wave Race 64","trustLevel":"module-semantic-verified","evidence":[');
  if (kind == KIND_EEPROM) {
    const options = load<u8>(payloadPtr + 0x0c);
    const mode = soundMode(options);
    if (mode < 0) return finishStatic('{"supported":false,"warnings":["Wave Race 64 sound-mode bits are outside known values"]}');
    pos = write(out, pos, '"512-byte EEPROM window","magic TE","checksum matches sum of bytes 0x04-0x1FF","progress/name/condition/record ranges mapped from save code"],"payloadSizeBytes":');
    pos = writeInt(out, pos, payloadLen);
    pos = write(out, pos, ',"slotCount":1,"activeSlotIndexes":[0],"checksumValid":true,"semanticFields":{');
    pos = write(out, pos, '"saveKind":"eeprom","soundMode":"');
    pos = writeSound(out, pos, mode);
    pos = write(out, pos, '","musicEnabled":');
    pos = writeBool(out, pos, musicEnabled(options));
    pos = write(out, pos, ',"progressByte1":'); pos = writeInt(out, pos, byteAt(payloadPtr, 0x08));
    pos = write(out, pos, ',"progressByte2":'); pos = writeInt(out, pos, byteAt(payloadPtr, 0x09));
    pos = write(out, pos, ',"progressByte3":'); pos = writeInt(out, pos, byteAt(payloadPtr, 0x0a));
    pos = write(out, pos, ',"progressByte4":'); pos = writeInt(out, pos, byteAt(payloadPtr, 0x0b));
    pos = write(out, pos, ',"normalWaveMode":"'); pos = writeWave(out, pos, byteAt(payloadPtr, 0x50));
    pos = write(out, pos, '","normalBuoyMissLimit":'); pos = writeInt(out, pos, byteAt(payloadPtr, 0x51));
    pos = write(out, pos, ',"normalLapCount":'); pos = writeInt(out, pos, byteAt(payloadPtr, 0x52));
    pos = write(out, pos, '}}');
  } else {
    const note = pfsFindWaveRaceNote(payloadPtr);
    const pages = pfsPageCount(payloadPtr, note);
    pos = write(out, pos, '"valid Controller Pak id sector","valid Controller Pak inode table","Wave Race 64 PFS note game code matched","PFS page chain exposes at least 0x200 bytes"],"payloadSizeBytes":');
    pos = writeInt(out, pos, payloadLen);
    pos = write(out, pos, ',"slotCount":1,"activeSlotIndexes":[0],"checksumValid":true,"semanticFields":{"saveKind":"controller-pak","controllerPakNoteIndex":');
    pos = writeInt(out, pos, note + 1);
    pos = write(out, pos, ',"controllerPakPageCount":');
    pos = writeInt(out, pos, pages);
    pos = write(out, pos, '}}');
  }
  return pack(out, pos);
}

function handleRead(input: usize, inputLen: i32): i64 {
  const p64 = decodePayload(input, inputLen);
  const payloadPtr = <usize>(p64 >> 32);
  const payloadLen = <i32>(p64 & 0xffffffff);
  const kind = payloadKind(payloadPtr, payloadLen);
  if (kind == KIND_NONE) return finishStatic('{"supported":false,"values":{}}');
  const out = allocOut(kind == KIND_CPAK ? 32768 : 24576);
  let pos = 0;
  pos = write(out, pos, '{"supported":true,"values":{');
  if (kind == KIND_EEPROM) {
    pos = writeEEPROMValues(out, pos, payloadPtr);
  } else {
    pos = writeCPakValues(out, pos, payloadPtr);
  }
  pos = write(out, pos, '}}');
  return pack(out, pos);
}

function handleApply(input: usize, inputLen: i32): i64 {
  const p64 = decodePayload(input, inputLen);
  const payloadPtr = <usize>(p64 >> 32);
  const payloadLen = <i32>(p64 & 0xffffffff);
  const kind = payloadKind(payloadPtr, payloadLen);
  if (kind == KIND_NONE) return finishStatic('{"payload":[],"changed":{},"integritySteps":["rejected invalid Wave Race 64 save"]}');

  gOut = allocOut(payloadLen * 4 + 65536);
  gPos = 0;
  gChanged = 0;
  gPos = write(gOut, gPos, '{"changed":{');
  if (kind == KIND_EEPROM) {
    applyEEPROMUpdates(input, inputLen, payloadPtr);
    const sum = checksum(payloadPtr);
    store<u8>(payloadPtr + 2, <u8>((sum >> 8) & 0xff));
    store<u8>(payloadPtr + 3, <u8>(sum & 0xff));
  } else {
    applyCPakUpdates(input, inputLen, payloadPtr);
  }
  gPos = write(gOut, gPos, '},"payload":[');
  for (let i = 0; i < payloadLen; i++) {
    if (i > 0) gPos = writeByte(gOut, gPos, 44);
    gPos = writeInt(gOut, gPos, byteAt(payloadPtr, i));
  }
  if (kind == KIND_EEPROM) {
    gPos = write(gOut, gPos, '],"integritySteps":["EEPROM checksum rebuilt"]}');
  } else {
    gPos = write(gOut, gPos, '],"integritySteps":["Controller Pak page data updated; PFS metadata and page chain preserved"]}');
  }
  return pack(gOut, gPos);
}

function writeEEPROMValues(out: usize, pos: i32, ptr: usize): i32 {
  const options = load<u8>(ptr + 0x0c);
  pos = write(out, pos, '"soundMode":"'); pos = writeSound(out, pos, soundMode(options));
  pos = write(out, pos, '","musicEnabled":'); pos = writeBool(out, pos, musicEnabled(options));
  for (let i = 1; i <= 4; i++) {
    pos = write(out, pos, ',"progressByte'); pos = writeInt(out, pos, i); pos = write(out, pos, '":');
    pos = writeInt(out, pos, byteAt(ptr, 0x07 + i));
  }
  for (let rider = 1; rider <= 4; rider++) {
    for (let ch = 1; ch <= 9; ch++) {
      pos = write(out, pos, ',"rider'); pos = writeInt(out, pos, rider); pos = write(out, pos, 'NameChar'); pos = writeInt(out, pos, ch); pos = write(out, pos, '":"');
      pos = writeCharValue(out, pos, readRiderChar(ptr, rider, ch));
      pos = writeByte(out, pos, 34);
    }
  }
  pos = writeConditionValues(out, pos, ptr, 'normal', 0x50);
  pos = writeConditionValues(out, pos, ptr, 'hard', 0x53);
  pos = writeConditionValues(out, pos, ptr, 'expert', 0x56);
  pos = writeRecordByteValues(out, pos, ptr, 'ttRecord', 0x60, 32, 6);
  pos = writeRecordByteValues(out, pos, ptr, 'recordGroup', 0x120, 27, 5);
  for (let i = 1; i <= 16; i++) {
    pos = write(out, pos, ',"stuntScore'); pos = write2(out, pos, i); pos = write(out, pos, '":');
    pos = writeInt(out, pos, readS24(ptr, 0x1a8 + (i - 1) * 3));
  }
  pos = writeRecordByteValues(out, pos, ptr, 'extraRecord', 0x1d8, 8, 5);
  return pos;
}

function writeCPakValues(out: usize, pos: i32, ptr: usize): i32 {
  const note = pfsFindWaveRaceNote(ptr);
  pos = write(out, pos, '"controllerPakNoteIndex":'); pos = writeInt(out, pos, note + 1);
  pos = write(out, pos, ',"controllerPakPageCount":'); pos = writeInt(out, pos, pfsPageCount(ptr, note));
  for (let i = 1; i <= 512; i++) {
    pos = write(out, pos, ',"cpakGhostByte'); pos = write3(out, pos, i); pos = write(out, pos, '":');
    pos = writeInt(out, pos, pfsReadFileByte(ptr, note, i - 1));
  }
  return pos;
}

function writeConditionValues(out: usize, pos: i32, ptr: usize, prefix: string, off: i32): i32 {
  pos = write(out, pos, ',"'); pos = write(out, pos, prefix); pos = write(out, pos, 'WaveMode":"'); pos = writeWave(out, pos, byteAt(ptr, off)); pos = writeByte(out, pos, 34);
  pos = write(out, pos, ',"'); pos = write(out, pos, prefix); pos = write(out, pos, 'BuoyMissLimit":'); pos = writeInt(out, pos, byteAt(ptr, off + 1));
  pos = write(out, pos, ',"'); pos = write(out, pos, prefix); pos = write(out, pos, 'LapCount":'); pos = writeInt(out, pos, byteAt(ptr, off + 2));
  return pos;
}

function writeRecordByteValues(out: usize, pos: i32, ptr: usize, prefix: string, base: i32, blocks: i32, width: i32): i32 {
  for (let block = 1; block <= blocks; block++) {
    for (let b = 1; b <= width; b++) {
      pos = writeByte(out, pos, 44); pos = writeByte(out, pos, 34); pos = write(out, pos, prefix); pos = write2(out, pos, block); pos = write(out, pos, 'Byte'); pos = writeInt(out, pos, b); pos = write(out, pos, '":');
      pos = writeInt(out, pos, byteAt(ptr, base + (block - 1) * width + (b - 1)));
    }
  }
  return pos;
}

function applyEEPROMUpdates(input: usize, inputLen: i32, ptr: usize): void {
  let options = load<u8>(ptr + 0x0c);
  const modeUpdate = findSoundModeUpdate(input, inputLen);
  const musicUpdate = findMusicUpdate(input, inputLen);
  if (modeUpdate >= 0) {
    options = <u8>((options & 0x3f) | soundBits(modeUpdate));
    store<u8>(ptr + 0x0c, options);
    changedSimpleString('soundMode', modeName(modeUpdate));
  }
  if (musicUpdate >= 0) {
    if (musicUpdate == 1) options = <u8>(options & 0xdf); else options = <u8>(options | 0x20);
    store<u8>(ptr + 0x0c, options);
    changedSimpleBool('musicEnabled', musicUpdate == 1);
  }
  for (let i = 1; i <= 4; i++) {
    const value = findIndexedNumberUpdate(input, inputLen, 'progressByte', i, 1, '', 0, 0, false, 0, 255, -1);
    if (value >= 0) { store<u8>(ptr + 0x07 + i, <u8>value); changedIndexedNumber('progressByte', i, 1, '', 0, 0, false, value); }
  }
  for (let rider = 1; rider <= 4; rider++) applyRiderNameUpdates(input, inputLen, ptr, rider);
  applyConditionUpdates(input, inputLen, ptr, 'normal', 0x50);
  applyConditionUpdates(input, inputLen, ptr, 'hard', 0x53);
  applyConditionUpdates(input, inputLen, ptr, 'expert', 0x56);
  applyRecordByteUpdates(input, inputLen, ptr, 'ttRecord', 0x60, 32, 6);
  applyRecordByteUpdates(input, inputLen, ptr, 'recordGroup', 0x120, 27, 5);
  for (let i = 1; i <= 16; i++) {
    const score = findIndexedNumberUpdate(input, inputLen, 'stuntScore', i, 2, '', 0, 0, false, -1, 16777214, -2147483648);
    if (score != -2147483648) { writeS24(ptr, 0x1a8 + (i - 1) * 3, score); changedIndexedNumber('stuntScore', i, 2, '', 0, 0, false, score); }
  }
  applyRecordByteUpdates(input, inputLen, ptr, 'extraRecord', 0x1d8, 8, 5);
}

function applyRiderNameUpdates(input: usize, inputLen: i32, ptr: usize, rider: i32): void {
  const tmp = <usize>rsm_alloc(9);
  let touched = false;
  for (let ch = 1; ch <= 9; ch++) {
    let value = readRiderChar(ptr, rider, ch);
    const update = findIndexedCharUpdate(input, inputLen, 'rider', rider, 1, 'NameChar', ch, 1);
    if (update >= 0) {
      value = update;
      touched = true;
      changedIndexedString('rider', rider, 1, 'NameChar', ch, 1, charValueName(update));
    }
    store<u8>(tmp + ch - 1, <u8>value);
  }
  if (!touched) return;
  const base = riderNameOffset(rider);
  let ended = false;
  for (let ch = 0; ch < 9; ch++) {
    const value = byteAt(tmp, ch);
    if (ended) {
      store<u8>(ptr + base + ch, 0xff);
    } else if (value == 0) {
      store<u8>(ptr + base + ch, 0);
      ended = true;
    } else {
      store<u8>(ptr + base + ch, <u8>value);
    }
  }
  store<u8>(ptr + base + 9, ended ? 0xff : 0);
}

function applyConditionUpdates(input: usize, inputLen: i32, ptr: usize, prefix: string, off: i32): void {
  const wave = findSimpleWaveUpdate(input, inputLen, prefix, 'WaveMode');
  if (wave >= 0) { store<u8>(ptr + off, <u8>wave); changedSimpleWave(prefix, 'WaveMode', wave); }
  const misses = findSimpleNumberUpdate2(input, inputLen, prefix, 'BuoyMissLimit', 0, 5, -1);
  if (misses >= 0) { store<u8>(ptr + off + 1, <u8>misses); changedSimpleNumber2(prefix, 'BuoyMissLimit', misses); }
  const laps = findSimpleNumberUpdate2(input, inputLen, prefix, 'LapCount', 1, 9, -1);
  if (laps >= 0) { store<u8>(ptr + off + 2, <u8>laps); changedSimpleNumber2(prefix, 'LapCount', laps); }
}

function applyRecordByteUpdates(input: usize, inputLen: i32, ptr: usize, prefix: string, base: i32, blocks: i32, width: i32): void {
  for (let block = 1; block <= blocks; block++) {
    for (let b = 1; b <= width; b++) {
      const value = findIndexedNumberUpdate(input, inputLen, prefix, block, 2, 'Byte', b, 1, true, 0, 255, -1);
      if (value >= 0) {
        store<u8>(ptr + base + (block - 1) * width + (b - 1), <u8>value);
        changedIndexedNumber(prefix, block, 2, 'Byte', b, 1, true, value);
      }
    }
  }
}

function applyCPakUpdates(input: usize, inputLen: i32, ptr: usize): void {
  const note = pfsFindWaveRaceNote(ptr);
  for (let i = 1; i <= 512; i++) {
    const value = findIndexedNumberUpdate(input, inputLen, 'cpakGhostByte', i, 3, '', 0, 0, false, 0, 255, -1);
    if (value >= 0) {
      pfsWriteFileByte(ptr, note, i - 1, value);
      changedIndexedNumber('cpakGhostByte', i, 3, '', 0, 0, false, value);
    }
  }
}

function payloadKind(ptr: usize, len: i32): i32 {
  if (validEEPROM(ptr, len)) return KIND_EEPROM;
  if (validCPak(ptr, len)) return KIND_CPAK;
  return KIND_NONE;
}

function validEEPROM(ptr: usize, len: i32): bool {
  if (ptr == 0) return false;
  if (len != 512 && len != 2048) return false;
  if (load<u8>(ptr) != 0x54 || load<u8>(ptr + 1) != 0x45) return false;
  const stored = (<i32>load<u8>(ptr + 2) << 8) | <i32>load<u8>(ptr + 3);
  return stored == checksum(ptr);
}

function checksum(ptr: usize): i32 {
  let sum = 0;
  for (let i = 4; i < 512; i++) sum = (sum + byteAt(ptr, i)) & 0xffff;
  return sum;
}

function validCPak(ptr: usize, len: i32): bool {
  if (ptr == 0 || len != 32768) return false;
  const id = pfsValidIdBase(ptr);
  if (id < 0) return false;
  const bankCount = byteAt(ptr, id + 26);
  if (bankCount != 1) return false;
  if (pfsINodeBase(ptr) < 0) return false;
  const note = pfsFindWaveRaceNote(ptr);
  if (note < 0) return false;
  return pfsPageCount(ptr, note) >= 2;
}

function pfsValidIdBase(ptr: usize): i32 {
  if (pfsIdValidAt(ptr, 0x20)) return 0x20;
  if (pfsIdValidAt(ptr, 0x60)) return 0x60;
  if (pfsIdValidAt(ptr, 0x80)) return 0x80;
  if (pfsIdValidAt(ptr, 0xc0)) return 0xc0;
  return -1;
}

function pfsIdValidAt(ptr: usize, base: i32): bool {
  let sum = 0;
  for (let i = 0; i < 28; i += 2) sum = (sum + readU16(ptr, base + i)) & 0xffff;
  const inv = (0xfff2 - sum) & 0xffff;
  return readU16(ptr, base + 28) == sum && readU16(ptr, base + 30) == inv;
}

function pfsINodeBase(ptr: usize): i32 {
  if (pfsINodesValidAt(ptr, 0x100)) return 0x100;
  if (pfsINodesValidAt(ptr, 0x200)) return 0x200;
  return -1;
}

function pfsINodesValidAt(ptr: usize, base: i32): bool {
  let sum = 0;
  for (let page = 5; page < 128; page++) sum = (sum + readU16(ptr, base + page * 2)) & 0xffff;
  return (sum & 0xff) == (readU16(ptr, base) & 0xff);
}

function pfsFindWaveRaceNote(ptr: usize): i32 {
  for (let note = 0; note < 16; note++) {
    const base = 0x300 + note * 32;
    const startPage = readU16(ptr, base + 6);
    if (startPage == 0) continue;
    if (!pfsGameCodeWaveRace(ptr, base)) continue;
    if (!pfsCompanyWaveRace(ptr, base + 4)) continue;
    if (!pfsValidPage(startPage)) continue;
    return note;
  }
  return -1;
}

function pfsGameCodeWaveRace(ptr: usize, base: i32): bool {
  if (byteAt(ptr, base) != 0x4e || byteAt(ptr, base + 1) != 0x57 || byteAt(ptr, base + 2) != 0x52) return false;
  const region = byteAt(ptr, base + 3);
  return region == 0x4a || region == 0x45 || region == 0x50;
}

function pfsCompanyWaveRace(ptr: usize, base: i32): bool {
  const a = byteAt(ptr, base);
  const b = byteAt(ptr, base + 1);
  return (a == 0x30 && b == 0x31) || (a == 0x00 && b == 0x01) || (a == 0x01 && b == 0x00);
}

function pfsPageCount(ptr: usize, note: i32): i32 {
  if (note < 0) return 0;
  const inodeBase = pfsINodeBase(ptr);
  if (inodeBase < 0) return 0;
  let page = readU16(ptr, 0x300 + note * 32 + 6);
  let count = 0;
  while (page != 1 && count < 128) {
    if (!pfsValidPage(page)) return 0;
    count++;
    page = readU16(ptr, inodeBase + page * 2);
  }
  return count;
}

function pfsFilePage(ptr: usize, note: i32, pageIndex: i32): i32 {
  const inodeBase = pfsINodeBase(ptr);
  if (note < 0 || inodeBase < 0) return -1;
  let page = readU16(ptr, 0x300 + note * 32 + 6);
  for (let i = 0; i < pageIndex; i++) {
    if (!pfsValidPage(page)) return -1;
    page = readU16(ptr, inodeBase + page * 2);
  }
  if (!pfsValidPage(page)) return -1;
  return page;
}

function pfsReadFileByte(ptr: usize, note: i32, index: i32): i32 {
  const page = pfsFilePage(ptr, note, index >> 8);
  if (page < 0) return 0;
  return byteAt(ptr, (page << 8) + (index & 0xff));
}

function pfsWriteFileByte(ptr: usize, note: i32, index: i32, value: i32): void {
  const page = pfsFilePage(ptr, note, index >> 8);
  if (page < 0) return;
  store<u8>(ptr + (page << 8) + (index & 0xff), <u8>value);
}

function pfsValidPage(page: i32): bool { return page >= 5 && page < 128; }

function readU16(ptr: usize, off: i32): i32 { return (byteAt(ptr, off) << 8) | byteAt(ptr, off + 1); }
function byteAt(ptr: usize, off: i32): i32 { return <i32>load<u8>(ptr + off); }

function soundMode(options: u8): i32 {
  const bits = options & 0xc0;
  if (bits == 0x00) return 0;
  if (bits == 0x40) return 1;
  if (bits == 0x80) return 2;
  return -1;
}
function soundBits(mode: i32): u8 { if (mode == 1) return 0x40; if (mode == 2) return 0x80; return 0x00; }
function musicEnabled(options: u8): bool { return (options & 0x20) == 0; }
function modeName(mode: i32): string { if (mode == 1) return 'mono'; if (mode == 2) return 'headphones'; return 'stereo'; }

function riderNameOffset(rider: i32): i32 { return 0x10 + (rider - 1) * 10; }
function readRiderChar(ptr: usize, rider: i32, ch: i32): i32 {
  const v = byteAt(ptr, riderNameOffset(rider) + ch - 1);
  if (v >= 65 && v <= 90) return v;
  if (v == 0x20 || v == 0x2d || v == 0x2e) return v;
  return 0;
}

function readS24(ptr: usize, off: i32): i32 {
  const v = (byteAt(ptr, off) << 16) | (byteAt(ptr, off + 1) << 8) | byteAt(ptr, off + 2);
  if (v == 0xffffff) return -1;
  return v;
}

function writeS24(ptr: usize, off: i32, value: i32): void {
  let v = value;
  if (v < 0) v = 0xffffff;
  store<u8>(ptr + off, <u8>((v >> 16) & 0xff));
  store<u8>(ptr + off + 1, <u8>((v >> 8) & 0xff));
  store<u8>(ptr + off + 2, <u8>(v & 0xff));
}

function findSoundModeUpdate(input: usize, inputLen: i32): i32 {
  const k = find(input, inputLen, '"soundMode":"');
  if (k < 0) return -1;
  const v = k + 13;
  if (starts(input, inputLen, v, 'stereo')) return 0;
  if (starts(input, inputLen, v, 'mono')) return 1;
  if (starts(input, inputLen, v, 'headphones')) return 2;
  return -1;
}

function findMusicUpdate(input: usize, inputLen: i32): i32 {
  const k = find(input, inputLen, '"musicEnabled":');
  if (k < 0) return -1;
  const v = k + 15;
  if (starts(input, inputLen, v, 'true')) return 1;
  if (starts(input, inputLen, v, 'false')) return 0;
  return -1;
}

function findSimpleWaveUpdate(input: usize, len: i32, prefix: string, suffix: string): i32 {
  const v = findSimpleValueStart(input, len, prefix, suffix);
  if (v < 0 || load<u8>(input + v) != 34) return -1;
  const s = v + 1;
  if (starts(input, len, s, 'courseDefault')) return 0;
  if (starts(input, len, s, 'calm10')) return 1;
  if (starts(input, len, s, 'rough40')) return 2;
  if (starts(input, len, s, 'random10to40')) return 3;
  return -1;
}

function findSimpleNumberUpdate2(input: usize, len: i32, prefix: string, suffix: string, min: i32, max: i32, missing: i32): i32 {
  const v = findSimpleValueStart(input, len, prefix, suffix);
  if (v < 0) return missing;
  return parseNumberAt(input, len, v, min, max, missing);
}

function findSimpleValueStart(input: usize, len: i32, prefix: string, suffix: string): i32 {
  for (let i = 0; i < len; i++) {
    if (load<u8>(input + i) != 34) continue;
    let p = i + 1;
    if (!matchStringAt(input, len, p, prefix)) continue;
    p += prefix.length;
    if (!matchStringAt(input, len, p, suffix)) continue;
    p += suffix.length;
    if (p + 1 >= len || load<u8>(input + p) != 34 || load<u8>(input + p + 1) != 58) continue;
    return p + 2;
  }
  return -1;
}

function findIndexedNumberUpdate(input: usize, len: i32, prefix: string, index: i32, digits: i32, mid: string, subIndex: i32, subDigits: i32, hasSub: bool, min: i32, max: i32, missing: i32): i32 {
  const v = findIndexedValueStart(input, len, prefix, index, digits, mid, subIndex, subDigits, hasSub);
  if (v < 0) return missing;
  return parseNumberAt(input, len, v, min, max, missing);
}

function findIndexedCharUpdate(input: usize, len: i32, prefix: string, index: i32, digits: i32, mid: string, subIndex: i32, subDigits: i32): i32 {
  const v = findIndexedValueStart(input, len, prefix, index, digits, mid, subIndex, subDigits, true);
  if (v < 0 || load<u8>(input + v) != 34) return -1;
  return parseCharValueAt(input, len, v + 1);
}

function findIndexedValueStart(input: usize, len: i32, prefix: string, index: i32, digits: i32, mid: string, subIndex: i32, subDigits: i32, hasSub: bool): i32 {
  for (let i = 0; i < len; i++) {
    if (load<u8>(input + i) != 34) continue;
    let p = i + 1;
    if (!matchStringAt(input, len, p, prefix)) continue;
    p += prefix.length;
    if (!matchDigitsAt(input, len, p, index, digits)) continue;
    p += digits;
    if (!matchStringAt(input, len, p, mid)) continue;
    p += mid.length;
    if (hasSub) {
      if (!matchDigitsAt(input, len, p, subIndex, subDigits)) continue;
      p += subDigits;
    }
    if (p + 1 >= len || load<u8>(input + p) != 34 || load<u8>(input + p + 1) != 58) continue;
    return p + 2;
  }
  return -1;
}

function parseNumberAt(ptr: usize, len: i32, at: i32, min: i32, max: i32, missing: i32): i32 {
  if (at < 0 || at >= len) return missing;
  let p = at;
  let sign = 1;
  if (load<u8>(ptr + p) == 45) { sign = -1; p++; }
  let value = 0;
  let saw = false;
  while (p < len) {
    const c = load<u8>(ptr + p);
    if (c < 48 || c > 57) break;
    value = value * 10 + (<i32>c - 48);
    saw = true;
    p++;
  }
  if (!saw) return missing;
  value *= sign;
  if (value < min || value > max) return missing;
  return value;
}

function parseCharValueAt(ptr: usize, len: i32, at: i32): i32 {
  if (starts(ptr, len, at, 'end')) return 0;
  if (starts(ptr, len, at, 'space')) return 0x20;
  if (starts(ptr, len, at, 'dash')) return 0x2d;
  if (starts(ptr, len, at, 'dot')) return 0x2e;
  const c = load<u8>(ptr + at);
  if (c >= 65 && c <= 90) return <i32>c;
  return -1;
}

function matchStringAt(ptr: usize, len: i32, at: i32, s: string): bool {
  if (at < 0 || at + s.length > len) return false;
  for (let i = 0; i < s.length; i++) if (load<u8>(ptr + at + i) != s.charCodeAt(i)) return false;
  return true;
}

function matchDigitsAt(ptr: usize, len: i32, at: i32, value: i32, digits: i32): bool {
  if (at < 0 || at + digits > len) return false;
  let divisor = 1;
  for (let i = 1; i < digits; i++) divisor *= 10;
  for (let i = 0; i < digits; i++) {
    const digit = (value / divisor) % 10;
    if (load<u8>(ptr + at + i) != 48 + digit) return false;
    divisor /= 10;
  }
  return true;
}

function changedSep(): void { if (gChanged > 0) gPos = writeByte(gOut, gPos, 44); gChanged++; }
function changedSimpleString(name: string, value: string): void { changedSep(); gPos = writeByte(gOut, gPos, 34); gPos = write(gOut, gPos, name); gPos = write(gOut, gPos, '":"'); gPos = write(gOut, gPos, value); gPos = writeByte(gOut, gPos, 34); }
function changedSimpleBool(name: string, value: bool): void { changedSep(); gPos = writeByte(gOut, gPos, 34); gPos = write(gOut, gPos, name); gPos = write(gOut, gPos, '":'); gPos = writeBool(gOut, gPos, value); }
function changedSimpleNumber2(prefix: string, suffix: string, value: i32): void { changedSep(); gPos = writeByte(gOut, gPos, 34); gPos = write(gOut, gPos, prefix); gPos = write(gOut, gPos, suffix); gPos = write(gOut, gPos, '":'); gPos = writeInt(gOut, gPos, value); }
function changedSimpleWave(prefix: string, suffix: string, value: i32): void { changedSep(); gPos = writeByte(gOut, gPos, 34); gPos = write(gOut, gPos, prefix); gPos = write(gOut, gPos, suffix); gPos = write(gOut, gPos, '":"'); gPos = writeWave(gOut, gPos, value); gPos = writeByte(gOut, gPos, 34); }

function changedIndexedNumber(prefix: string, index: i32, digits: i32, mid: string, sub: i32, subDigits: i32, hasSub: bool, value: i32): void {
  changedSep();
  gPos = writeByte(gOut, gPos, 34); gPos = write(gOut, gPos, prefix); gPos = writeDigits(gOut, gPos, index, digits); gPos = write(gOut, gPos, mid);
  if (hasSub) gPos = writeDigits(gOut, gPos, sub, subDigits);
  gPos = write(gOut, gPos, '":'); gPos = writeInt(gOut, gPos, value);
}

function changedIndexedString(prefix: string, index: i32, digits: i32, mid: string, sub: i32, subDigits: i32, value: string): void {
  changedSep();
  gPos = writeByte(gOut, gPos, 34); gPos = write(gOut, gPos, prefix); gPos = writeDigits(gOut, gPos, index, digits); gPos = write(gOut, gPos, mid); gPos = writeDigits(gOut, gPos, sub, subDigits);
  gPos = write(gOut, gPos, '":"'); gPos = write(gOut, gPos, value); gPos = writeByte(gOut, gPos, 34);
}

function decodePayload(input: usize, inputLen: i32): i64 {
  const start = find(input, inputLen, '"payload":"');
  if (start < 0) return pack(0, 0);
  const b64Start = start + 11;
  let b64Len = 0;
  while (b64Start + b64Len < inputLen && load<u8>(input + b64Start + b64Len) != 34) b64Len++;
  const outLen = ((b64Len + 3) / 4) * 3 + 3;
  const out = rsm_alloc(outLen);
  let o = 0;
  let i = 0;
  while (i + 3 < b64Len) {
    const c0 = b64Val(load<u8>(input + b64Start + i));
    const c1 = b64Val(load<u8>(input + b64Start + i + 1));
    const c2 = b64Val(load<u8>(input + b64Start + i + 2));
    const c3 = b64Val(load<u8>(input + b64Start + i + 3));
    if (c0 < 0 || c1 < 0) break;
    store<u8>(<usize>out + o, <u8>((c0 << 2) | (c1 >> 4))); o++;
    if (c2 >= 0) { store<u8>(<usize>out + o, <u8>(((c1 & 15) << 4) | (c2 >> 2))); o++; }
    if (c2 >= 0 && c3 >= 0) { store<u8>(<usize>out + o, <u8>(((c2 & 3) << 6) | c3)); o++; }
    i += 4;
  }
  return pack(<usize>out, o);
}

function b64Val(c: u8): i32 {
  if (c >= 65 && c <= 90) return <i32>c - 65;
  if (c >= 97 && c <= 122) return <i32>c - 71;
  if (c >= 48 && c <= 57) return <i32>c + 4;
  if (c == 43) return 62;
  if (c == 47) return 63;
  if (c == 61) return -2;
  return -1;
}

function eq(ptr: usize, len: i32, s: string): bool {
  if (len != s.length) return false;
  for (let i = 0; i < len; i++) if (load<u8>(ptr + i) != s.charCodeAt(i)) return false;
  return true;
}

function starts(ptr: usize, len: i32, at: i32, s: string): bool {
  if (at < 0 || at + s.length > len) return false;
  for (let i = 0; i < s.length; i++) if (load<u8>(ptr + at + i) != s.charCodeAt(i)) return false;
  return true;
}

function find(ptr: usize, len: i32, needle: string): i32 {
  if (needle.length == 0 || len < needle.length) return -1;
  for (let i = 0; i <= len - needle.length; i++) {
    let ok = true;
    for (let j = 0; j < needle.length; j++) {
      if (load<u8>(ptr + i + j) != needle.charCodeAt(j)) { ok = false; break; }
    }
    if (ok) return i;
  }
  return -1;
}

function ensureMemory(end: usize): void {
  const need = <i32>((end + 65535) >> 16);
  const have = memory.size();
  if (need > have) memory.grow(need - have);
}

function allocOut(capacity: i32): usize { return <usize>rsm_alloc(capacity); }
function finishStatic(s: string): i64 { const out = allocOut(s.length); return pack(out, write(out, 0, s)); }
function pack(ptr: usize, len: i32): i64 { return (<i64>ptr << 32) | <i64>len; }
function writeByte(out: usize, pos: i32, c: i32): i32 { store<u8>(out + pos, <u8>c); return pos + 1; }
function write(out: usize, pos: i32, s: string): i32 { for (let i = 0; i < s.length; i++) store<u8>(out + pos + i, <u8>s.charCodeAt(i)); return pos + s.length; }
function writeBool(out: usize, pos: i32, v: bool): i32 { return write(out, pos, v ? 'true' : 'false'); }
function writeSound(out: usize, pos: i32, mode: i32): i32 { return write(out, pos, modeName(mode)); }
function writeWave(out: usize, pos: i32, mode: i32): i32 { if (mode == 1) return write(out, pos, 'calm10'); if (mode == 2) return write(out, pos, 'rough40'); if (mode == 3) return write(out, pos, 'random10to40'); return write(out, pos, 'courseDefault'); }
function charValueName(value: i32): string { if (value == 0x20) return 'space'; if (value == 0x2d) return 'dash'; if (value == 0x2e) return 'dot'; if (value >= 65 && value <= 90) return String.fromCharCode(value); return 'end'; }
function writeCharValue(out: usize, pos: i32, value: i32): i32 { return write(out, pos, charValueName(value)); }
function write2(out: usize, pos: i32, value: i32): i32 { return writeDigits(out, pos, value, 2); }
function write3(out: usize, pos: i32, value: i32): i32 { return writeDigits(out, pos, value, 3); }
function writeDigits(out: usize, pos: i32, value: i32, digits: i32): i32 {
  let divisor = 1;
  for (let i = 1; i < digits; i++) divisor *= 10;
  for (let i = 0; i < digits; i++) { const digit = (value / divisor) % 10; pos = writeByte(out, pos, 48 + digit); divisor /= 10; }
  return pos;
}
function writeInt(out: usize, pos: i32, value: i32): i32 {
  if (value < 0) { pos = writeByte(out, pos, 45); value = -value; }
  if (value == 0) return writeByte(out, pos, 48);
  let divisor = 1000000000;
  let started = false;
  while (divisor > 0) {
    const digit = value / divisor;
    if (digit > 0 || started) {
      pos = writeByte(out, pos, 48 + digit);
      value -= digit * divisor;
      started = true;
    }
    divisor /= 10;
  }
  return pos;
}
