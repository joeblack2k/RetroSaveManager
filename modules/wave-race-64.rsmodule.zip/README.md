# Wave Race 64 Game Support Module

This module validates and edits Wave Race 64 save data without backend Go changes.

Supported payloads:

- 512-byte native EEPROM window and 2048-byte canonical N64 EEPROM wrapper.
- 32768-byte canonical Controller Pak images containing a Wave Race 64 PFS note.

EEPROM validation requires the `TE` magic at bytes `0x00-0x01` and the big-endian checksum at `0x02-0x03`, calculated as the 16-bit sum of bytes `0x04-0x1FF`. EEPROM edits preserve unrelated bytes and rebuild that checksum.

Controller Pak validation requires a valid PFS id sector, a valid inode table, a Wave Race game code (`NWRJ`, `NWRE`, or `NWRP`), Nintendo publisher code, and at least two data pages for the game's 0x200-byte payload. Controller Pak edits preserve PFS notes, inode chains, and unrelated pak entries while updating selected bytes inside the Wave Race payload pages.

Editable EEPROM fields cover audio bits, championship/progress bytes, rider name character slots, per-difficulty condition settings, packed time-trial/course record bytes, 24-bit stunt score values, and the trailing packed record bytes. Packed records are intentionally exposed as structured bytes or 24-bit values rather than invented "max record" cheats.

Editable Controller Pak fields cover all 512 bytes of the proven PFS ghost payload; the Wave Race note index and page count are reported as parser evidence/semantic fields. The module does not invent semantics for the ghost stream beyond its documented PFS identity and size.
