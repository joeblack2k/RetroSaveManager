#![no_std]
#![allow(static_mut_refs)]

use core::panic::PanicInfo;
use core::ptr;
use core::slice;

const HEAP_SIZE: usize = 288 * 1024;
const OUTPUT_CAP: usize = 112 * 1024;
const CARD_SIZE: usize = 0x2000;
const SAVE_RAM_SIZE: usize = 0x10000;
const COMPOUND_SIZE: usize = 0x12000;
const MAX_PAYLOAD_SIZE: usize = COMPOUND_SIZE;
const BACKUP_MARKER_OFFSET: usize = 0x10;
const FREE_PLAY_OFFSET: usize = 0x42;
const SLOT_TABLE_OFFSET: usize = 0x124;
const SLOT_BOOK_DATE_OFFSET: usize = 0x144;
const BOOKKEEPING_SLOT_INDEX_OFFSET: usize = 0x122;
const SOFT_DIP_OFFSET: usize = 0x220;
const SOFT_DIP_SIZE: usize = 16;
const GAME_NAME_BLOCK_OFFSET: usize = 0x2A0;
const GAME_DATA_BLOCK_OFFSET: usize = 0x320;
const GAME_DATA_BLOCK_SIZE: usize = 0x1000;
const CARD_MAGIC_OFFSET: usize = 0x20;
const CARD_REGION_OFFSET: usize = 0x30;
const CARD_USERNAME_AVAILABLE_OFFSET: usize = 0x0f;
const CARD_USERNAME_OFFSET: usize = 0x10;
const CARD_DIRECTORY_OFFSET: usize = 0x40;
const CARD_DIRECTORY_ENTRIES: usize = 128;
const CARD_ENTRY_SIZE: usize = 4;
const GAME_NGH: u16 = 0x0082;

static mut HEAP: [u8; HEAP_SIZE] = [0; HEAP_SIZE];
static mut HEAP_OFFSET: usize = 8;
static mut PAYLOAD: [u8; MAX_PAYLOAD_SIZE] = [0; MAX_PAYLOAD_SIZE];

#[panic_handler]
fn panic(_: &PanicInfo) -> ! {
    loop {}
}

fn heap_base() -> usize {
    ptr::addr_of_mut!(HEAP) as *mut u8 as usize
}

#[no_mangle]
pub extern "C" fn rsm_alloc(len: i32) -> i32 {
    if len < 0 {
        return 0;
    }
    let len = len as usize;
    unsafe {
        let relative = (HEAP_OFFSET + 7) & !7;
        let Some(end) = relative.checked_add(len) else { return 0; };
        if end >= HEAP_SIZE {
            return 0;
        }
        HEAP_OFFSET = end;
        (heap_base() + relative) as i32
    }
}

#[no_mangle]
pub extern "C" fn rsm_call(command_ptr: i32, command_len: i32, input_ptr: i32, input_len: i32) -> u64 {
    let Some(command) = read_bytes(command_ptr, command_len) else {
        return write_unsupported(b"bad command pointer");
    };
    let input = read_bytes(input_ptr, input_len).unwrap_or(&[]);
    if command == b"capabilities" {
        write_capabilities()
    } else if command == b"parse" {
        write_parse(input)
    } else if command == b"readCheats" {
        write_read_cheats(input)
    } else if command == b"applyCheats" {
        write_apply_cheats(input)
    } else {
        write_unsupported(b"unsupported command")
    }
}

fn read_bytes(ptr: i32, len: i32) -> Option<&'static [u8]> {
    if ptr < 0 || len < 0 {
        return None;
    }
    let ptr = ptr as usize;
    let len = len as usize;
    let end = ptr.checked_add(len)?;
    let base = heap_base();
    if ptr < base || end > base + HEAP_SIZE {
        return None;
    }
    unsafe { Some(slice::from_raw_parts(ptr as *const u8, len)) }
}

struct Writer {
    ptr: usize,
    len: usize,
    cap: usize,
}

impl Writer {
    fn new(cap: usize) -> Option<Writer> {
        let ptr = rsm_alloc(cap as i32);
        if ptr <= 0 {
            return None;
        }
        Some(Writer { ptr: ptr as usize, len: 0, cap })
    }

    fn finish(self) -> u64 {
        ((self.ptr as u64) << 32) | (self.len as u64)
    }

    fn byte(&mut self, value: u8) {
        if self.len >= self.cap {
            return;
        }
        unsafe {
            ptr::write((self.ptr + self.len) as *mut u8, value);
        }
        self.len += 1;
    }

    fn bytes(&mut self, values: &[u8]) {
        for value in values {
            self.byte(*value);
        }
    }

    fn bool(&mut self, value: bool) {
        if value {
            self.bytes(b"true");
        } else {
            self.bytes(b"false");
        }
    }

    fn usize(&mut self, mut value: usize) {
        let mut tmp = [0u8; 20];
        let mut idx = tmp.len();
        if value == 0 {
            self.byte(b'0');
            return;
        }
        while value > 0 {
            idx -= 1;
            tmp[idx] = b'0' + (value % 10) as u8;
            value /= 10;
        }
        self.bytes(&tmp[idx..]);
    }

    fn hex_byte(&mut self, value: u8) {
        const HEX: &[u8; 16] = b"0123456789abcdef";
        self.byte(HEX[(value >> 4) as usize]);
        self.byte(HEX[(value & 0x0f) as usize]);
    }
}

struct Analysis {
    payload_len: usize,
    compound: bool,
    card_only: bool,
    slot_index: usize,
    block_id: usize,
    free_play: bool,
    free_play_raw: u8,
    soft_dip_non_padding: usize,
    game_data_non_padding: usize,
    game_name_non_padding: usize,
    bookkeeping_slot_index: u8,
    word_swapped: bool,
    card: Option<CardAnalysis>,
}

#[derive(Clone, Copy)]
struct CardAnalysis {
    interleaved: bool,
    region: u8,
    username_available: bool,
    username_non_padding: usize,
    used_entries: usize,
    double_dragon_entries: usize,
    first_entry_index: usize,
    first_sub_number: u8,
    first_fat_index: u8,
    first_title_non_padding: usize,
}

fn write_capabilities() -> u64 {
    let Some(mut w) = Writer::new(512) else { return 0; };
    w.bytes(b"{\"supported\":true,\"parserId\":\"neogeo-doubledr\",\"abiVersion\":\"rsm-wasm-json-v1\",\"commands\":[\"capabilities\",\"parse\",\"readCheats\",\"applyCheats\"],\"operations\":[\"moduleBoolean\",\"moduleReadOnly\"],\"editableFields\":1}");
    w.finish()
}

fn write_parse(input: &[u8]) -> u64 {
    let Some(payload_len) = decode_payload_from_json(input) else {
        return write_unsupported(b"expected base64 NeoGeo backup RAM or memory-card payload");
    };
    let Some(analysis) = analyze_payload(payload_len) else {
        return write_unsupported(b"NeoGeo marker or Double Dragon NGH evidence did not validate");
    };

    let Some(mut w) = Writer::new(8192) else { return 0; };
    if analysis.card_only {
        let Some(card) = analysis.card else {
            return write_unsupported(b"Double Dragon memory-card directory did not validate");
        };
        w.bytes(b"{\"supported\":true,\"parserLevel\":\"semantic\",\"parserId\":\"neogeo-doubledr\",\"validatedSystem\":\"neogeo\",\"validatedGameId\":\"neogeo/doubledr\",\"validatedGameTitle\":\"Double Dragon (Neo-Geo)\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[\"validated Neo Geo memory-card magic\",\"memory-card directory contains Double Dragon NGH 0x0082\",\"NeoGeoDev documents memory-card directory entries as sub-number, NGH word, and FAT index\"],\"warnings\":[\"Read-only card support: memory-card data/FAT edits are not exposed without game-specific integrity proof.\"],\"payloadSizeBytes\":");
        w.usize(analysis.payload_len);
        w.bytes(b",\"slotCount\":");
        w.usize(CARD_DIRECTORY_ENTRIES);
        w.bytes(b",\"activeSlotIndexes\":[");
        w.usize(card.first_entry_index);
        w.bytes(b"],\"semanticFields\":{\"saveKind\":\"neogeo-memory-card\",\"nghNumber\":\"0082\",\"mameGameNumber\":\"082\",\"memoryCardInterleaved\":");
        w.bool(card.interleaved);
        w.bytes(b",\"memoryCardRegion\":\"");
        write_card_region(&mut w, card.region);
        w.bytes(b"\",\"memoryCardUsernameAvailable\":");
        w.bool(card.username_available);
        w.bytes(b",\"memoryCardUsernameNonPadding\":");
        w.usize(card.username_non_padding);
        w.bytes(b",\"memoryCardDirectoryEntries\":");
        w.usize(CARD_DIRECTORY_ENTRIES);
        w.bytes(b",\"memoryCardUsedEntries\":");
        w.usize(card.used_entries);
        w.bytes(b",\"doubleDragonCardEntries\":");
        w.usize(card.double_dragon_entries);
        w.bytes(b",\"cardFirstDoubleDragonSubNumber\":");
        w.usize(card.first_sub_number as usize);
        w.bytes(b",\"cardFirstDoubleDragonFatIndex\":");
        w.usize(card.first_fat_index as usize);
        w.bytes(b",\"cardFirstDoubleDragonTitleNonPadding\":");
        w.usize(card.first_title_non_padding);
        w.bytes(b",\"readOnlyMemoryCard\":true,\"safeWritableFields\":0,\"editableFields\":0}}");
        return w.finish();
    }

    w.bytes(b"{\"supported\":true,\"parserLevel\":\"semantic\",\"parserId\":\"neogeo-doubledr\",\"validatedSystem\":\"neogeo\",\"validatedGameId\":\"neogeo/doubledr\",\"validatedGameTitle\":\"Double Dragon (Neo-Geo)\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[\"validated MVS backup RAM marker at 0x10\",\"slot table contains Double Dragon NGH 0x0082 (MAME NGM-082)\",\"NeoGeoDev documents MVS cabinet game-select byte at backup RAM offset 0x42\"");
    if analysis.compound {
        w.bytes(b",\"compound payload preserves trailing 8192-byte memory-card data\"");
    } else {
        w.bytes(b",\"raw 65536-byte MVS backup RAM payload\"");
    }
    if analysis.word_swapped {
        w.bytes(b",\"detected 16-bit byte-swapped backup RAM layout\"");
    }
    w.bytes(b"],\"warnings\":[");
    if analysis.free_play_raw > 1 {
        w.bytes(b"\"Free Play byte is outside the documented 0/1 range; non-zero is read as enabled.\"");
        w.bytes(b",");
    }
    w.bytes(b"\"Double Dragon soft-DIP, ranking, bookkeeping, and game-data blocks are exposed as read-only details until game-specific byte semantics are proven.\"],\"payloadSizeBytes\":");
    w.usize(analysis.payload_len);
    w.bytes(b",\"slotCount\":8,\"activeSlotIndexes\":[");
    w.usize(analysis.slot_index);
    w.bytes(b"],\"semanticFields\":{\"saveKind\":\"");
    if analysis.compound {
        w.bytes(b"neogeo-compound-saveram-card");
    } else {
        w.bytes(b"neogeo-mvs-backup-ram");
    }
    w.bytes(b"\",\"nghNumber\":\"0082\",\"mameGameNumber\":\"082\",\"wordSwapped\":");
    w.bool(analysis.word_swapped);
    w.bytes(b",\"mvsSlotIndex\":");
    w.usize(analysis.slot_index + 1);
    w.bytes(b",\"bramBlockIndex\":");
    w.usize(analysis.block_id);
    w.bytes(b",\"freePlay\":");
    w.bool(analysis.free_play);
    w.bytes(b",\"softDipByteCount\":");
    w.usize(SOFT_DIP_SIZE);
    w.bytes(b",\"softDipBytesHex\":\"");
    write_soft_dip_hex(&mut w, analysis.slot_index, analysis.word_swapped);
    w.bytes(b"\",\"softDipBytesNonPadding\":");
    w.usize(analysis.soft_dip_non_padding);
    w.bytes(b",\"softDipSafeWritableFields\":0,\"gameDataBlockIndex\":");
    w.usize(analysis.block_id);
    w.bytes(b",\"gameDataBlockOffset\":");
    w.usize(GAME_DATA_BLOCK_OFFSET + analysis.block_id * GAME_DATA_BLOCK_SIZE);
    w.bytes(b",\"gameDataBlockSizeBytes\":");
    w.usize(GAME_DATA_BLOCK_SIZE);
    w.bytes(b",\"gameDataBlockNonPaddingBytes\":");
    w.usize(analysis.game_data_non_padding);
    w.bytes(b",\"gameNameBlockNonPadding\":");
    w.usize(analysis.game_name_non_padding);
    w.bytes(b",\"bookkeepingSlotIndex\":");
    w.usize(analysis.bookkeeping_slot_index as usize);
    w.bytes(b",\"slotBookDateBcd\":\"");
    write_slot_book_date_hex(&mut w, analysis.slot_index, analysis.word_swapped);
    w.bytes(b"\",\"rankingDecoderState\":\"read-only-unmapped\"");
    if let Some(card) = analysis.card {
        w.bytes(b",\"memoryCardInterleaved\":");
        w.bool(card.interleaved);
        w.bytes(b",\"memoryCardUsedEntries\":");
        w.usize(card.used_entries);
        w.bytes(b",\"doubleDragonCardEntries\":");
        w.usize(card.double_dragon_entries);
        w.bytes(b",\"cardFirstDoubleDragonSubNumber\":");
        w.usize(card.first_sub_number as usize);
        w.bytes(b",\"cardFirstDoubleDragonFatIndex\":");
        w.usize(card.first_fat_index as usize);
    }
    w.bytes(b",\"safeWritableFields\":1,\"editableFields\":1}}");
    w.finish()
}

fn write_read_cheats(input: &[u8]) -> u64 {
    let Some(payload_len) = decode_payload_from_json(input) else {
        return write_unsupported(b"payload missing");
    };
    let Some(analysis) = analyze_payload(payload_len) else {
        return write_unsupported(b"unsupported Double Dragon save structure");
    };

    let Some(mut w) = Writer::new(4096) else { return 0; };
    if analysis.card_only {
        w.bytes(b"{\"supported\":true,\"gameId\":\"neogeo/doubledr\",\"systemSlug\":\"neogeo\",\"editorId\":\"neogeo-doubledr\",\"adapterId\":\"neogeo-doubledr\",\"packId\":\"neogeo--doubledr\",\"title\":\"Double Dragon (Neo-Geo)\",\"availableCount\":0,\"values\":{\"editableFields\":0,\"readOnlyMemoryCard\":true},\"sections\":[{\"id\":\"details\",\"title\":\"Details\",\"fields\":[]}],\"presets\":[]}");
        return w.finish();
    }
    w.bytes(b"{\"supported\":true,\"gameId\":\"neogeo/doubledr\",\"systemSlug\":\"neogeo\",\"editorId\":\"neogeo-doubledr\",\"adapterId\":\"neogeo-doubledr\",\"packId\":\"neogeo--doubledr\",\"title\":\"Double Dragon (Neo-Geo)\",\"availableCount\":1,\"values\":{\"freePlay\":");
    w.bool(analysis.free_play);
    w.bytes(b"},\"sections\":[{\"id\":\"cabinet\",\"title\":\"Cabinet\",\"fields\":[{\"id\":\"freePlay\",\"ref\":\"freePlay\",\"label\":\"Free Play\",\"description\":\"MVS backup RAM cabinet game-select setting at offset 0x42; 1 means free play and 0 means credit required.\",\"type\":\"boolean\",\"op\":{\"kind\":\"moduleBoolean\",\"field\":\"freePlay\"}}]}],\"presets\":[{\"id\":\"enableFreePlay\",\"label\":\"Enable Free Play\",\"updates\":{\"freePlay\":true}},{\"id\":\"disableFreePlay\",\"label\":\"Disable Free Play\",\"updates\":{\"freePlay\":false}}]}");
    w.finish()
}

fn write_apply_cheats(input: &[u8]) -> u64 {
    let Some(payload_len) = decode_payload_from_json(input) else {
        return write_apply_error(b"payload missing");
    };
    let Some(analysis) = analyze_payload(payload_len) else {
        return write_apply_error(b"unsupported Double Dragon save structure");
    };

    let update = json_object_field(input, b"updates").and_then(|(start, len)| {
        json_bool_field(&input[start..start + len], b"freePlay")
    });

    let Some(mut w) = Writer::new(OUTPUT_CAP) else { return 0; };
    if analysis.card_only {
        w.bytes(b"{\"payload\":\"");
        write_base64_payload(&mut w, payload_len);
        w.bytes(b"\",\"changed\":{},\"integritySteps\":[\"read-only Neo Geo memory-card support: original payload returned unchanged because no safe card-data write fields are proven\"]}");
        return w.finish();
    }
    w.bytes(b"{\"payload\":\"");
    if let Some(value) = update {
        write_payload_byte(FREE_PLAY_OFFSET, if value { 1 } else { 0 }, analysis.word_swapped);
    }
    write_base64_payload(&mut w, payload_len);
    w.bytes(b"\",\"changed\":{");
    if let Some(value) = update {
        w.bytes(b"\"freePlay\":");
        w.bool(value);
    }
    w.bytes(b"},\"integritySteps\":[\"");
    if update.is_some() {
        w.bytes(b"updated documented MVS backup RAM cabinet game-select byte at offset 0x42; no global backup RAM checksum is defined");
    } else {
        w.bytes(b"no Double Dragon cabinet updates requested");
    }
    w.bytes(b"\"]}");
    w.finish()
}

fn write_unsupported(message: &[u8]) -> u64 {
    let Some(mut w) = Writer::new(512) else { return 0; };
    w.bytes(b"{\"supported\":false,\"warnings\":[\"");
    w.bytes(message);
    w.bytes(b"\"]}");
    w.finish()
}

fn write_apply_error(message: &[u8]) -> u64 {
    let Some(mut w) = Writer::new(512) else { return 0; };
    w.bytes(b"{\"payload\":\"\",\"changed\":{},\"integritySteps\":[\"");
    w.bytes(message);
    w.bytes(b"\"]}");
    w.finish()
}

fn analyze_payload(payload_len: usize) -> Option<Analysis> {
    if payload_len == CARD_SIZE {
        let card = analyze_card(0)?;
        return Some(Analysis {
            payload_len,
            compound: false,
            card_only: true,
            slot_index: 0,
            block_id: 0,
            free_play: false,
            free_play_raw: 0,
            soft_dip_non_padding: 0,
            game_data_non_padding: 0,
            game_name_non_padding: 0,
            bookkeeping_slot_index: 0,
            word_swapped: false,
            card: Some(card),
        });
    }
    if payload_len != SAVE_RAM_SIZE && payload_len != COMPOUND_SIZE {
        return None;
    }
    let word_swapped = backup_marker_word_swapped()?;
    let (slot_index, block_id) = find_game_slot(word_swapped)?;
    let free_play_raw = payload_byte_at(FREE_PLAY_OFFSET, word_swapped);
    let soft_base = SOFT_DIP_OFFSET + slot_index * 16;
    let name_base = GAME_NAME_BLOCK_OFFSET + block_id * 16;
    let data_base = GAME_DATA_BLOCK_OFFSET + block_id * GAME_DATA_BLOCK_SIZE;
    Some(Analysis {
        payload_len,
        compound: payload_len == COMPOUND_SIZE,
        card_only: false,
        slot_index,
        block_id,
        free_play: free_play_raw != 0,
        free_play_raw,
        soft_dip_non_padding: count_non_padding(soft_base, SOFT_DIP_SIZE, word_swapped),
        game_data_non_padding: count_non_padding(data_base, GAME_DATA_BLOCK_SIZE, word_swapped),
        game_name_non_padding: count_non_padding(name_base, 16, word_swapped),
        bookkeeping_slot_index: payload_byte_at(BOOKKEEPING_SLOT_INDEX_OFFSET, word_swapped),
        word_swapped,
        card: if payload_len == COMPOUND_SIZE { analyze_card(SAVE_RAM_SIZE) } else { None },
    })
}

fn backup_marker_word_swapped() -> Option<bool> {
    if marker_matches(false) {
        return Some(false);
    }
    if marker_matches(true) {
        return Some(true);
    }
    None
}

fn marker_matches(word_swapped: bool) -> bool {
    marker_candidate_matches(b"BACKUP RAM OK!", word_swapped) || marker_candidate_matches(b"BACKUP RAM OK !", word_swapped)
}

fn marker_candidate_matches(marker: &[u8], word_swapped: bool) -> bool {
    for i in 0..marker.len() {
        if payload_byte_at(BACKUP_MARKER_OFFSET + i, word_swapped) != marker[i] {
            return false;
        }
    }
    true
}

fn find_game_slot(word_swapped: bool) -> Option<(usize, usize)> {
    for slot in 0..8 {
        let off = SLOT_TABLE_OFFSET + slot * 4;
        let ngh = read_be16(off, word_swapped);
        let block = read_be16(off + 2, word_swapped);
        if ngh == GAME_NGH && block < 8 {
            return Some((slot, block as usize));
        }
    }
    None
}

fn read_be16(offset: usize, word_swapped: bool) -> u16 {
    ((payload_byte_at(offset, word_swapped) as u16) << 8) | payload_byte_at(offset + 1, word_swapped) as u16
}

fn byte_at(offset: usize) -> u8 {
    unsafe { PAYLOAD[offset] }
}

fn payload_byte_at(offset: usize, word_swapped: bool) -> u8 {
    if word_swapped {
        byte_at(offset ^ 1)
    } else {
        byte_at(offset)
    }
}

fn write_payload_byte(offset: usize, value: u8, word_swapped: bool) {
    let physical = if word_swapped { offset ^ 1 } else { offset };
    unsafe {
        PAYLOAD[physical] = value;
    }
}

fn count_non_padding(offset: usize, len: usize, word_swapped: bool) -> usize {
    let mut count = 0usize;
    for i in 0..len {
        let b = payload_byte_at(offset + i, word_swapped);
        if b != 0 && b != 0xff && b != b' ' {
            count += 1;
        }
    }
    count
}

fn write_soft_dip_hex(w: &mut Writer, slot_index: usize, word_swapped: bool) {
    let offset = SOFT_DIP_OFFSET + slot_index * SOFT_DIP_SIZE;
    for i in 0..SOFT_DIP_SIZE {
        w.hex_byte(payload_byte_at(offset + i, word_swapped));
    }
}

fn write_slot_book_date_hex(w: &mut Writer, slot_index: usize, word_swapped: bool) {
    let offset = SLOT_BOOK_DATE_OFFSET + slot_index * 4;
    for i in 0..4 {
        w.hex_byte(payload_byte_at(offset + i, word_swapped));
    }
}

fn write_card_region(w: &mut Writer, region: u8) {
    match region {
        0 => w.bytes(b"Japan"),
        1 => w.bytes(b"USA"),
        2 => w.bytes(b"Europe"),
        _ => w.bytes(b"Unknown"),
    }
}

fn analyze_card(base: usize) -> Option<CardAnalysis> {
    if base.checked_add(CARD_SIZE)? > MAX_PAYLOAD_SIZE {
        return None;
    }
    let even_spaced = if card_magic_matches(base, false) {
        false
    } else if card_magic_matches(base, true) {
        true
    } else {
        return None;
    };

    let mut used_entries = 0usize;
    let mut double_dragon_entries = 0usize;
    let mut first_entry_index = 0usize;
    let mut first_sub_number = 0u8;
    let mut first_fat_index = 0u8;
    for entry in 0..CARD_DIRECTORY_ENTRIES {
        let sub = card_directory_byte(base, entry, 0, even_spaced)?;
        if sub == 0xff {
            continue;
        }
        let ngh = ((card_directory_byte(base, entry, 1, even_spaced)? as u16) << 8)
            | card_directory_byte(base, entry, 2, even_spaced)? as u16;
        let fat = card_directory_byte(base, entry, 3, even_spaced)?;
        if ngh != 0 && ngh != 0xffff {
            used_entries += 1;
        }
        if ngh == GAME_NGH {
            if double_dragon_entries == 0 {
                first_entry_index = entry;
                first_sub_number = sub;
                first_fat_index = fat;
            }
            double_dragon_entries += 1;
        }
    }
    if double_dragon_entries == 0 {
        return None;
    }

    Some(CardAnalysis {
        interleaved: even_spaced,
        region: card_header_byte(base, CARD_REGION_OFFSET, even_spaced)?,
        username_available: card_header_byte(base, CARD_USERNAME_AVAILABLE_OFFSET, even_spaced)? != 0,
        username_non_padding: count_card_header_non_padding(base, CARD_USERNAME_OFFSET, 16, even_spaced),
        used_entries,
        double_dragon_entries,
        first_entry_index,
        first_sub_number,
        first_fat_index,
        first_title_non_padding: count_card_data_title_non_padding(base, first_fat_index, even_spaced),
    })
}

fn card_magic_matches(base: usize, even_spaced: bool) -> bool {
    let marker = b"NEO-GEO";
    for i in 0..marker.len() {
        let step = if even_spaced { 2 } else { 1 };
        let Some(physical) = base
            .checked_add(CARD_MAGIC_OFFSET)
            .and_then(|offset| offset.checked_add(i * step))
        else {
            return false;
        };
        if physical >= base + CARD_SIZE || physical >= MAX_PAYLOAD_SIZE {
            return false;
        }
        let value = byte_at(physical);
        if value != marker[i] {
            return false;
        }
    }
    true
}

fn card_header_byte(base: usize, logical_offset: usize, even_spaced: bool) -> Option<u8> {
    let _ = even_spaced;
    let physical = base.checked_add(logical_offset)?;
    if physical >= base + CARD_SIZE || physical >= MAX_PAYLOAD_SIZE {
        return None;
    }
    Some(byte_at(physical))
}

fn card_directory_byte(base: usize, entry: usize, field: usize, even_spaced: bool) -> Option<u8> {
    if entry >= CARD_DIRECTORY_ENTRIES || field >= CARD_ENTRY_SIZE {
        return None;
    }
    let stride = if even_spaced { CARD_ENTRY_SIZE * 2 } else { CARD_ENTRY_SIZE };
    let field_offset = if even_spaced { field * 2 } else { field };
    let offset = CARD_DIRECTORY_OFFSET
        .checked_add(entry.checked_mul(stride)?)?
        .checked_add(field_offset)?;
    let physical = base.checked_add(offset)?;
    if physical >= base + CARD_SIZE || physical >= MAX_PAYLOAD_SIZE {
        return None;
    }
    Some(byte_at(physical))
}

fn count_card_header_non_padding(base: usize, logical_offset: usize, len: usize, even_spaced: bool) -> usize {
    let mut count = 0usize;
    for i in 0..len {
        let offset = logical_offset + if even_spaced { i * 2 } else { i };
        let Some(value) = card_header_byte(base, offset, even_spaced) else {
            break;
        };
        if value != 0 && value != 0xff && value != b' ' {
            count += 1;
        }
    }
    count
}

fn count_card_data_title_non_padding(base: usize, fat_index: u8, even_spaced: bool) -> usize {
    let block_base = (fat_index as usize) * 64;
    let mut count = 0usize;
    for i in 0..20 {
        let offset = if even_spaced {
            block_base + i * 2
        } else {
            block_base + i
        };
        let Some(physical) = base.checked_add(offset) else {
            break;
        };
        if physical >= base + CARD_SIZE || physical >= MAX_PAYLOAD_SIZE {
            break;
        }
        let value = byte_at(physical);
        if value != 0 && value != 0xff && value != b' ' {
            count += 1;
        }
    }
    count
}

fn decode_payload_from_json(input: &[u8]) -> Option<usize> {
    let (start, len) = json_string_field(input, b"payload")?;
    decode_base64_to_payload(&input[start..start + len])
}

fn decode_base64_to_payload(input: &[u8]) -> Option<usize> {
    let mut out = 0usize;
    let mut buf = 0u32;
    let mut bits = 0usize;
    for &b in input {
        if b == b'=' {
            break;
        }
        let value = base64_value(b)?;
        buf = (buf << 6) | value as u32;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            if out >= MAX_PAYLOAD_SIZE {
                return None;
            }
            unsafe {
                PAYLOAD[out] = ((buf >> bits) & 0xff) as u8;
            }
            out += 1;
        }
    }
    if out == CARD_SIZE || out == SAVE_RAM_SIZE || out == COMPOUND_SIZE {
        Some(out)
    } else {
        None
    }
}

fn base64_value(b: u8) -> Option<u8> {
    match b {
        b'A'..=b'Z' => Some(b - b'A'),
        b'a'..=b'z' => Some(b - b'a' + 26),
        b'0'..=b'9' => Some(b - b'0' + 52),
        b'+' => Some(62),
        b'/' => Some(63),
        b'\n' | b'\r' | b'\t' | b' ' => Some(0),
        _ => None,
    }
}

fn write_base64_payload(w: &mut Writer, len: usize) {
    const TABLE: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut i = 0usize;
    while i + 3 <= len {
        let n = ((byte_at(i) as u32) << 16) | ((byte_at(i + 1) as u32) << 8) | byte_at(i + 2) as u32;
        w.byte(TABLE[((n >> 18) & 0x3f) as usize]);
        w.byte(TABLE[((n >> 12) & 0x3f) as usize]);
        w.byte(TABLE[((n >> 6) & 0x3f) as usize]);
        w.byte(TABLE[(n & 0x3f) as usize]);
        i += 3;
    }
    let remaining = len - i;
    if remaining == 1 {
        let n = (byte_at(i) as u32) << 16;
        w.byte(TABLE[((n >> 18) & 0x3f) as usize]);
        w.byte(TABLE[((n >> 12) & 0x3f) as usize]);
        w.byte(b'=');
        w.byte(b'=');
    } else if remaining == 2 {
        let n = ((byte_at(i) as u32) << 16) | ((byte_at(i + 1) as u32) << 8);
        w.byte(TABLE[((n >> 18) & 0x3f) as usize]);
        w.byte(TABLE[((n >> 12) & 0x3f) as usize]);
        w.byte(TABLE[((n >> 6) & 0x3f) as usize]);
        w.byte(b'=');
    }
}

fn json_string_field(input: &[u8], field: &[u8]) -> Option<(usize, usize)> {
    let key_pos = find_json_key(input, field)?;
    let mut idx = skip_ws(input, key_pos + field.len() + 2);
    if idx >= input.len() || input[idx] != b':' {
        return None;
    }
    idx = skip_ws(input, idx + 1);
    if idx >= input.len() || input[idx] != b'"' {
        return None;
    }
    let start = idx + 1;
    idx = start;
    while idx < input.len() {
        if input[idx] == b'\\' {
            idx += 2;
            continue;
        }
        if input[idx] == b'"' {
            return Some((start, idx - start));
        }
        idx += 1;
    }
    None
}

fn json_object_field(input: &[u8], field: &[u8]) -> Option<(usize, usize)> {
    let key_pos = find_json_key(input, field)?;
    let mut idx = skip_ws(input, key_pos + field.len() + 2);
    if idx >= input.len() || input[idx] != b':' {
        return None;
    }
    idx = skip_ws(input, idx + 1);
    if idx >= input.len() || input[idx] != b'{' {
        return None;
    }
    let start = idx;
    let mut depth = 0i32;
    let mut in_string = false;
    while idx < input.len() {
        let b = input[idx];
        if in_string {
            if b == b'\\' {
                idx += 2;
                continue;
            }
            if b == b'"' {
                in_string = false;
            }
            idx += 1;
            continue;
        }
        if b == b'"' {
            in_string = true;
        } else if b == b'{' {
            depth += 1;
        } else if b == b'}' {
            depth -= 1;
            if depth == 0 {
                return Some((start, idx + 1 - start));
            }
        }
        idx += 1;
    }
    None
}

fn json_bool_field(input: &[u8], field: &[u8]) -> Option<bool> {
    let key_pos = find_json_key(input, field)?;
    let mut idx = skip_ws(input, key_pos + field.len() + 2);
    if idx >= input.len() || input[idx] != b':' {
        return None;
    }
    idx = skip_ws(input, idx + 1);
    if starts_with(&input[idx..], b"true") {
        Some(true)
    } else if starts_with(&input[idx..], b"false") {
        Some(false)
    } else {
        None
    }
}

fn find_json_key(input: &[u8], field: &[u8]) -> Option<usize> {
    if field.len() + 2 > 64 {
        return None;
    }
    let mut key = [0u8; 64];
    key[0] = b'"';
    for i in 0..field.len() {
        key[i + 1] = field[i];
    }
    key[field.len() + 1] = b'"';
    find_bytes(input, &key[..field.len() + 2])
}

fn find_bytes(input: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() || input.len() < needle.len() {
        return None;
    }
    let max = input.len() - needle.len();
    for i in 0..=max {
        let mut ok = true;
        for j in 0..needle.len() {
            if input[i + j] != needle[j] {
                ok = false;
                break;
            }
        }
        if ok {
            return Some(i);
        }
    }
    None
}

fn skip_ws(input: &[u8], mut idx: usize) -> usize {
    while idx < input.len() {
        let b = input[idx];
        if b != b' ' && b != b'\n' && b != b'\r' && b != b'\t' {
            break;
        }
        idx += 1;
    }
    idx
}

fn starts_with(input: &[u8], prefix: &[u8]) -> bool {
    if input.len() < prefix.len() {
        return false;
    }
    for i in 0..prefix.len() {
        if input[i] != prefix[i] {
            return false;
        }
    }
    true
}
