# NeoGeo - Double Dragon Module

This module supports Double Dragon MVS backup-RAM saves for RetroSaveManager.

Runtime files:

- `parser.wasm`: sandboxed WASM parser/editor using the `rsm-wasm-json-v1` ABI.
- `cheats/doubledr.yaml`: declarative cheat pack for the WASM editor.
- `src/*`: review source only; the backend never compiles or runs it.

## Evidence

- MAME's NeoGeo driver identifies the ROM set as `doubledr`, `Double Dragon (Neo-Geo)`, `NGM-082`/`NGH-082`, and marks it with `MACHINE_SUPPORTS_SAVE`.
- NeoGeoDev documents MVS backup RAM as a 64KiB region at `$D00000-$D0FFFF`, including the marker at `$D00010`, the slot NGH/block table at `$D00124`, the per-game soft-DIP area, and the cabinet setting byte at backup RAM offset `0x42`.
- NeoGeoDev documents the 68k program header NGH field as BCD. The MVS backup RAM slot table stores Double Dragon as NGH `0x0082`, matching MAME's `NGM-082` and `NGH-082` notes.
- NeoGeoDev documents memory-card directory entries as save sub-number, NGH word, and FAT index. The module uses that structure for read-only card-only validation when a directory entry contains NGH `0x0082`.
- MiSTer/NeoGeo compound saves may store backup RAM as 16-bit byte-swapped words. The module detects both direct and byte-swapped marker layouts and writes edits back in the original layout.

## Supported Payloads

- `8192` bytes: raw Neo Geo memory-card image, read-only, validated by memory-card magic plus a Double Dragon NGH directory entry.
- `65536` bytes: raw MVS backup RAM.
- `73728` bytes: RetroSaveManager NeoGeo compound layout, with the first `65536` bytes treated as backup RAM and the trailing `8192` bytes preserved unchanged.
- Formats accepted by the module matcher: `sav`, `srm`, `ram`, and backend-normalized `sram`.

For backup RAM, the parser returns `supported: true` only when the backup RAM marker is present (`BACKUP RAM OK!` or the common spaced `BACKUP RAM OK !`) and one MVS slot table entry contains NGH `0x0082` with a valid backup-RAM block id.

For card-only saves, the parser returns read-only support only when Neo Geo memory-card magic is present and the directory contains a Double Dragon NGH `0x0082` entry.

## Editable Field

- `freePlay`: boolean MVS cabinet game-select setting at backup RAM offset `0x42`.

No checksum is rebuilt because the documented MVS backup RAM structure does not define a global checksum for this cabinet setting.

## Read-Only Details

- 16-byte soft-DIP storage block for the validated MVS slot: exposed as raw detail bytes and occupancy only.
- Double Dragon backup-RAM game-data block index, offset, size, and non-padding byte count.
- Slot bookkeeping date bytes and current bookkeeping slot index.
- Memory-card directory details for card-only saves or compound saves with a valid card tail: used entry count, Double Dragon entry count, sub-number, FAT index, and region.

## Not Supported

- Game-specific soft-DIP writes such as difficulty, time, lives, continue settings, or bonus settings; the save stores the values, but the byte-to-label mapping and safe bounds were not proven from the Double Dragon program header.
- High-score, ranking, or bookkeeping edits; the module exposes block occupancy/details only.
- Memory-card data editing; card-only support is read-only.
- Raw offset writes, arbitrary byte edits, trainer codes, or filename-only matching.
