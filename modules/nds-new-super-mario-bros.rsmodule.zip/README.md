# New Super Mario Bros. Game Support Module

This module supports raw 8192-byte Nintendo DS backup saves for New Super Mario Bros.

Runtime validation requires the known `Mario2d` save-block signature and valid NSMBDS 16-bit checksums across both 0x1000-byte save banks. Each bank contains a header block, three save-file blocks, and a footer block. The module recalculates all ten checksums after edits.

Supported editable fields are limited to the values proven by public save-editor source:

- Save File 1, 2, and 3 selector.
- Lives, coins, total star coins, and score as little-endian 32-bit counters with the same bounds used by the public editor UI.
- Current power-up values: Small, Super, Fire, Mini, and Blue Shell.
- Reserve item values: Nothing, Super Mushroom, Fire Flower, Blue Shell, Mini Mushroom, and Mega Mushroom.
- Bottom-screen background values 1 through 5.

Known limitations:

- World and level unlock bulk writes are intentionally not exposed. The public editor labels the feature, but the individual bit semantics and per-level mapping were not proven.
- The module does not expose raw offsets, arbitrary bitmasks, unknown bytes, or RAM/action-replay style codes.
- DeSmuME native `.dsv` files are supported only when the payload is the raw 8192-byte backup memory, without appended emulator metadata.

Research sources:

- newluigidev, "New-Super-Mario-Bros-Save-Editor", including `Form1.cs` checksum routine, block layout, field offsets, and UI bounds.
- NSMBHD thread "Save Editor Tool", which links the public editor and credits RoadrunnerWMC for save-file reverse engineering documentation.
- RetroSaveManager's existing Nintendo DS structural validator, which recognizes 8192-byte NSMBDS saves by repeated `Mario2d` block signatures.

Build note:

- `parser.wasm` was built from `src/parser.c` with `zig cc` for `wasm32-freestanding`, no entry point, exported memory, and a 1 MiB initial memory.
