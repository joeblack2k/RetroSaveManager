#include <stdbool.h>
#include <stdint.h>

extern unsigned char __heap_base;

#define NSMB_SAVE_SIZE 8192u
#define NSMB_BANK_SIZE 0x1000u
#define NSMB_BLOCK_COUNT 5u
#define NSMB_FILE_COUNT 3u
#define OUTPUT_CAP 65536u

static const uint32_t block_offsets[NSMB_BLOCK_COUNT] = {0x000u, 0x100u, 0x380u, 0x600u, 0x880u};
static const uint32_t block_lengths[NSMB_BLOCK_COUNT] = {0x0F4u, 0x248u, 0x248u, 0x248u, 0x014u};
static const uint32_t file_offsets[NSMB_FILE_COUNT] = {0x100u, 0x380u, 0x600u};

static uint32_t heap_ptr = 0;

static void *rsm_bump_alloc(uint32_t len) {
    if (heap_ptr == 0) {
        heap_ptr = (uint32_t)(uintptr_t)&__heap_base;
    }
    heap_ptr = (heap_ptr + 7u) & ~7u;
    void *ptr = (void *)(uintptr_t)heap_ptr;
    heap_ptr += (len + 7u) & ~7u;
    return ptr;
}

__attribute__((export_name("rsm_alloc")))
int32_t rsm_alloc(int32_t len) {
    if (len <= 0) {
        return 0;
    }
    return (int32_t)(uintptr_t)rsm_bump_alloc((uint32_t)len);
}

typedef struct {
    char *data;
    uint32_t len;
    uint32_t cap;
} builder;

typedef struct {
    const uint8_t *ptr;
    uint32_t len;
} slice;

typedef struct {
    uint32_t lives;
    uint32_t coins;
    uint32_t score;
    uint32_t star_coins;
    uint8_t powerup;
    uint8_t reserve_item;
    uint8_t background;
} file_values;

typedef struct {
    bool valid;
    uint32_t signature_count;
    uint32_t valid_banks;
    file_values files[NSMB_FILE_COUNT];
} save_analysis;

static void b_init(builder *b, uint32_t cap) {
    b->data = (char *)rsm_bump_alloc(cap);
    b->len = 0;
    b->cap = cap;
}

static void b_char(builder *b, char c) {
    if (b->len < b->cap) {
        b->data[b->len++] = c;
    }
}

static uint32_t c_len(const char *s) {
    uint32_t n = 0;
    while (s[n] != 0) {
        n++;
    }
    return n;
}

static void b_strn(builder *b, const char *s, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) {
        b_char(b, s[i]);
    }
}

static void b_str(builder *b, const char *s) {
    b_strn(b, s, c_len(s));
}

static void b_u32(builder *b, uint32_t value) {
    char tmp[12];
    uint32_t n = 0;
    if (value == 0) {
        b_char(b, '0');
        return;
    }
    while (value > 0 && n < sizeof(tmp)) {
        tmp[n++] = (char)('0' + (value % 10u));
        value /= 10u;
    }
    while (n > 0) {
        b_char(b, tmp[--n]);
    }
}

static void b_bool(builder *b, bool value) {
    b_str(b, value ? "true" : "false");
}

static uint64_t finish(builder *b) {
    return ((uint64_t)(uint32_t)(uintptr_t)b->data << 32) | (uint64_t)b->len;
}

static bool bytes_eq(const uint8_t *a, const char *b, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) {
        if (a[i] != (uint8_t)b[i]) {
            return false;
        }
    }
    return true;
}

static bool slice_eq(slice s, const char *text) {
    uint32_t n = c_len(text);
    if (s.len != n) {
        return false;
    }
    for (uint32_t i = 0; i < n; i++) {
        if (s.ptr[i] != (uint8_t)text[i]) {
            return false;
        }
    }
    return true;
}

static int32_t find_bytes(const uint8_t *input, uint32_t len, const char *needle, uint32_t needle_len) {
    if (needle_len == 0 || len < needle_len) {
        return -1;
    }
    for (uint32_t i = 0; i <= len - needle_len; i++) {
        bool ok = true;
        for (uint32_t j = 0; j < needle_len; j++) {
            if (input[i + j] != (uint8_t)needle[j]) {
                ok = false;
                break;
            }
        }
        if (ok) {
            return (int32_t)i;
        }
    }
    return -1;
}

static uint32_t skip_ws(const uint8_t *input, uint32_t len, uint32_t idx) {
    while (idx < len) {
        uint8_t c = input[idx];
        if (c != ' ' && c != '\n' && c != '\r' && c != '\t') {
            break;
        }
        idx++;
    }
    return idx;
}

static bool json_string_raw(const uint8_t *input, uint32_t len, const char *field, slice *out) {
    char key[96];
    uint32_t field_len = c_len(field);
    if (field_len + 2 >= sizeof(key)) {
        return false;
    }
    key[0] = '"';
    for (uint32_t i = 0; i < field_len; i++) {
        key[i + 1] = field[i];
    }
    key[field_len + 1] = '"';
    key[field_len + 2] = 0;
    int32_t found = find_bytes(input, len, key, field_len + 2);
    if (found < 0) {
        return false;
    }
    uint32_t idx = skip_ws(input, len, (uint32_t)found + field_len + 2);
    if (idx >= len || input[idx] != ':') {
        return false;
    }
    idx = skip_ws(input, len, idx + 1);
    if (idx >= len || input[idx] != '"') {
        return false;
    }
    uint32_t start = idx + 1;
    idx = start;
    while (idx < len) {
        if (input[idx] == '\\') {
            idx += 2;
            continue;
        }
        if (input[idx] == '"') {
            out->ptr = input + start;
            out->len = idx - start;
            return true;
        }
        idx++;
    }
    return false;
}

static bool json_object_raw(const uint8_t *input, uint32_t len, const char *field, slice *out) {
    char key[96];
    uint32_t field_len = c_len(field);
    if (field_len + 2 >= sizeof(key)) {
        return false;
    }
    key[0] = '"';
    for (uint32_t i = 0; i < field_len; i++) {
        key[i + 1] = field[i];
    }
    key[field_len + 1] = '"';
    key[field_len + 2] = 0;
    int32_t found = find_bytes(input, len, key, field_len + 2);
    if (found < 0) {
        return false;
    }
    uint32_t idx = skip_ws(input, len, (uint32_t)found + field_len + 2);
    if (idx >= len || input[idx] != ':') {
        return false;
    }
    idx = skip_ws(input, len, idx + 1);
    if (idx >= len || input[idx] != '{') {
        return false;
    }
    uint32_t start = idx;
    int32_t depth = 0;
    bool in_string = false;
    while (idx < len) {
        uint8_t c = input[idx];
        if (in_string) {
            if (c == '\\') {
                idx += 2;
                continue;
            }
            if (c == '"') {
                in_string = false;
            }
            idx++;
            continue;
        }
        if (c == '"') {
            in_string = true;
        } else if (c == '{') {
            depth++;
        } else if (c == '}') {
            depth--;
            if (depth == 0) {
                out->ptr = input + start;
                out->len = idx - start + 1;
                return true;
            }
        }
        idx++;
    }
    return false;
}

static bool json_int_raw(const uint8_t *input, uint32_t len, const char *field, int32_t *out) {
    char key[96];
    uint32_t field_len = c_len(field);
    if (field_len + 2 >= sizeof(key)) {
        return false;
    }
    key[0] = '"';
    for (uint32_t i = 0; i < field_len; i++) {
        key[i + 1] = field[i];
    }
    key[field_len + 1] = '"';
    key[field_len + 2] = 0;
    int32_t found = find_bytes(input, len, key, field_len + 2);
    if (found < 0) {
        return false;
    }
    uint32_t idx = skip_ws(input, len, (uint32_t)found + field_len + 2);
    if (idx >= len || input[idx] != ':') {
        return false;
    }
    idx = skip_ws(input, len, idx + 1);
    bool neg = false;
    if (idx < len && input[idx] == '-') {
        neg = true;
        idx++;
    }
    if (idx >= len || input[idx] < '0' || input[idx] > '9') {
        return false;
    }
    int32_t value = 0;
    while (idx < len && input[idx] >= '0' && input[idx] <= '9') {
        value = value * 10 + (int32_t)(input[idx] - '0');
        idx++;
    }
    *out = neg ? -value : value;
    return true;
}

static int b64_value(uint8_t c) {
    if (c >= 'A' && c <= 'Z') {
        return (int)(c - 'A');
    }
    if (c >= 'a' && c <= 'z') {
        return (int)(c - 'a') + 26;
    }
    if (c >= '0' && c <= '9') {
        return (int)(c - '0') + 52;
    }
    if (c == '+') {
        return 62;
    }
    if (c == '/') {
        return 63;
    }
    if (c == '=') {
        return -2;
    }
    return -1;
}

static bool decode_base64(slice encoded, uint8_t **out, uint32_t *out_len) {
    uint32_t cap = (encoded.len / 4u + 1u) * 3u;
    uint8_t *buf = (uint8_t *)rsm_bump_alloc(cap);
    uint32_t len = 0;
    uint32_t idx = 0;
    while (idx < encoded.len) {
        int vals[4];
        uint32_t got = 0;
        while (idx < encoded.len && got < 4) {
            int v = b64_value(encoded.ptr[idx++]);
            if (v == -1) {
                continue;
            }
            vals[got++] = v;
        }
        if (got == 0) {
            break;
        }
        if (got != 4) {
            return false;
        }
        if (vals[0] < 0 || vals[1] < 0) {
            return false;
        }
        uint32_t n = ((uint32_t)vals[0] << 18) | ((uint32_t)vals[1] << 12);
        if (vals[2] >= 0) {
            n |= (uint32_t)vals[2] << 6;
        }
        if (vals[3] >= 0) {
            n |= (uint32_t)vals[3];
        }
        if (len < cap) {
            buf[len++] = (uint8_t)((n >> 16) & 0xffu);
        }
        if (vals[2] != -2 && len < cap) {
            buf[len++] = (uint8_t)((n >> 8) & 0xffu);
        }
        if (vals[3] != -2 && len < cap) {
            buf[len++] = (uint8_t)(n & 0xffu);
        }
    }
    *out = buf;
    *out_len = len;
    return true;
}

static void write_base64(builder *b, const uint8_t *bytes, uint32_t len) {
    static const char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    uint32_t i = 0;
    while (i + 3u <= len) {
        uint32_t n = ((uint32_t)bytes[i] << 16) | ((uint32_t)bytes[i + 1u] << 8) | bytes[i + 2u];
        b_char(b, table[(n >> 18) & 0x3fu]);
        b_char(b, table[(n >> 12) & 0x3fu]);
        b_char(b, table[(n >> 6) & 0x3fu]);
        b_char(b, table[n & 0x3fu]);
        i += 3u;
    }
    if (i < len) {
        uint32_t n = (uint32_t)bytes[i] << 16;
        bool have2 = i + 1u < len;
        if (have2) {
            n |= (uint32_t)bytes[i + 1u] << 8;
        }
        b_char(b, table[(n >> 18) & 0x3fu]);
        b_char(b, table[(n >> 12) & 0x3fu]);
        if (have2) {
            b_char(b, table[(n >> 6) & 0x3fu]);
        } else {
            b_char(b, '=');
        }
        b_char(b, '=');
    }
}

static uint16_t read_le16(const uint8_t *p) {
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static uint32_t read_le32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void write_le16(uint8_t *p, uint16_t value) {
    p[0] = (uint8_t)(value & 0xffu);
    p[1] = (uint8_t)(value >> 8);
}

static void write_le32(uint8_t *p, uint32_t value) {
    p[0] = (uint8_t)(value & 0xffu);
    p[1] = (uint8_t)((value >> 8) & 0xffu);
    p[2] = (uint8_t)((value >> 16) & 0xffu);
    p[3] = (uint8_t)((value >> 24) & 0xffu);
}

static uint16_t nsmb_checksum(const uint8_t *data, uint32_t data_size, uint32_t pos) {
    uint16_t checksum = 654u;
    for (uint32_t i = 0; i < data_size; i++) {
        uint16_t rotated = (uint16_t)(((uint32_t)checksum << 1u) & 0xfffeu);
        rotated = (uint16_t)(rotated | ((checksum >> 15u) & 1u));
        checksum = (uint16_t)(data[pos + i] ^ rotated);
    }
    return checksum;
}

static bool has_signature(const uint8_t *payload, uint32_t len, uint32_t offset) {
    return offset + 9u <= len && bytes_eq(payload + offset + 2u, "Mario2d", 7u);
}

static bool verify_block(const uint8_t *payload, uint32_t len, uint32_t offset, uint32_t data_len) {
    if (offset + 10u + data_len > len || !has_signature(payload, len, offset)) {
        return false;
    }
    return read_le16(payload + offset) == nsmb_checksum(payload, data_len, offset + 10u);
}

static uint32_t count_signatures(const uint8_t *payload, uint32_t len) {
    uint32_t count = 0;
    for (uint32_t i = 0; i + 7u <= len; i++) {
        if (bytes_eq(payload + i, "Mario2d", 7u)) {
            count++;
        }
    }
    return count;
}

static bool bank_valid(const uint8_t *payload, uint32_t len, uint32_t bank) {
    for (uint32_t i = 0; i < NSMB_BLOCK_COUNT; i++) {
        if (!verify_block(payload, len, bank + block_offsets[i], block_lengths[i])) {
            return false;
        }
    }
    return true;
}

static void recalc_checksums(uint8_t *payload) {
    for (uint32_t bank = 0; bank <= NSMB_BANK_SIZE; bank += NSMB_BANK_SIZE) {
        for (uint32_t i = 0; i < NSMB_BLOCK_COUNT; i++) {
            uint32_t pos = bank + block_offsets[i];
            write_le16(payload + pos, nsmb_checksum(payload, block_lengths[i], pos + 10u));
        }
    }
}

static file_values read_file_values(const uint8_t *payload, uint32_t bank, uint32_t file_index) {
    uint32_t base = bank + file_offsets[file_index];
    file_values values;
    values.lives = read_le32(payload + base + 0x16u);
    values.coins = read_le32(payload + base + 0x1au);
    values.score = read_le32(payload + base + 0x1eu);
    values.star_coins = read_le32(payload + base + 0x22u);
    values.powerup = payload[base + 0x3au];
    values.background = payload[base + 0x42u];
    values.reserve_item = payload[base + 0x66u];
    return values;
}

static save_analysis analyze_save(const uint8_t *payload, uint32_t len) {
    save_analysis a;
    a.valid = false;
    a.signature_count = count_signatures(payload, len);
    a.valid_banks = 0;
    for (uint32_t i = 0; i < NSMB_FILE_COUNT; i++) {
        a.files[i].lives = 0;
        a.files[i].coins = 0;
        a.files[i].score = 0;
        a.files[i].star_coins = 0;
        a.files[i].powerup = 0;
        a.files[i].reserve_item = 0;
        a.files[i].background = 0;
    }
    if (len != NSMB_SAVE_SIZE || a.signature_count < 6u) {
        return a;
    }
    for (uint32_t i = 0; i < NSMB_FILE_COUNT; i++) {
        a.files[i] = read_file_values(payload, 0, i);
    }
    if (bank_valid(payload, len, 0)) {
        a.valid_banks++;
    }
    if (bank_valid(payload, len, NSMB_BANK_SIZE)) {
        a.valid_banks++;
    }
    a.valid = a.valid_banks == 2u;
    return a;
}

static uint64_t unsupported(const char *message) {
    builder b;
    b_init(&b, 256);
    b_str(&b, "{\"supported\":false,\"error\":\"");
    b_str(&b, message);
    b_str(&b, "\"}");
    return finish(&b);
}

static bool payload_from_request(const uint8_t *input, uint32_t input_len, uint8_t **payload, uint32_t *payload_len) {
    slice encoded;
    if (!json_string_raw(input, input_len, "payload", &encoded)) {
        return false;
    }
    return decode_base64(encoded, payload, payload_len);
}

static const char *powerup_id(uint8_t value) {
    switch (value) {
    case 0: return "small";
    case 1: return "super";
    case 2: return "fire";
    case 4: return "mini";
    case 5: return "blueShell";
    default: return "";
    }
}

static bool powerup_value(slice id, uint8_t *value) {
    if (slice_eq(id, "small")) { *value = 0; return true; }
    if (slice_eq(id, "super")) { *value = 1; return true; }
    if (slice_eq(id, "fire")) { *value = 2; return true; }
    if (slice_eq(id, "mini")) { *value = 4; return true; }
    if (slice_eq(id, "blueShell")) { *value = 5; return true; }
    return false;
}

static const char *reserve_id(uint8_t value) {
    switch (value) {
    case 0: return "none";
    case 1: return "superMushroom";
    case 2: return "fireFlower";
    case 3: return "blueShell";
    case 4: return "miniMushroom";
    case 5: return "megaMushroom";
    default: return "";
    }
}

static bool reserve_value(slice id, uint8_t *value) {
    if (slice_eq(id, "none")) { *value = 0; return true; }
    if (slice_eq(id, "superMushroom")) { *value = 1; return true; }
    if (slice_eq(id, "fireFlower")) { *value = 2; return true; }
    if (slice_eq(id, "blueShell")) { *value = 3; return true; }
    if (slice_eq(id, "miniMushroom")) { *value = 4; return true; }
    if (slice_eq(id, "megaMushroom")) { *value = 5; return true; }
    return false;
}

static const char *background_id(uint8_t value) {
    switch (value) {
    case 0: return "bg1";
    case 1: return "bg2";
    case 2: return "bg3";
    case 3: return "bg4";
    case 4: return "bg5";
    default: return "";
    }
}

static bool background_value(slice id, uint8_t *value) {
    if (slice_eq(id, "bg1")) { *value = 0; return true; }
    if (slice_eq(id, "bg2")) { *value = 1; return true; }
    if (slice_eq(id, "bg3")) { *value = 2; return true; }
    if (slice_eq(id, "bg4")) { *value = 3; return true; }
    if (slice_eq(id, "bg5")) { *value = 4; return true; }
    return false;
}

static void write_file_values_json(builder *b, file_values v) {
    b_str(b, "{\"lives\":");
    b_u32(b, v.lives);
    b_str(b, ",\"coins\":");
    b_u32(b, v.coins);
    b_str(b, ",\"starCoins\":");
    b_u32(b, v.star_coins);
    b_str(b, ",\"score\":");
    b_u32(b, v.score);
    const char *power = powerup_id(v.powerup);
    if (power[0] != 0) {
        b_str(b, ",\"currentPowerup\":\"");
        b_str(b, power);
        b_char(b, '"');
    }
    const char *reserve = reserve_id(v.reserve_item);
    if (reserve[0] != 0) {
        b_str(b, ",\"reserveItem\":\"");
        b_str(b, reserve);
        b_char(b, '"');
    }
    const char *bg = background_id(v.background);
    if (bg[0] != 0) {
        b_str(b, ",\"bottomScreenBackground\":\"");
        b_str(b, bg);
        b_char(b, '"');
    }
    b_char(b, '}');
}

static uint64_t write_capabilities(void) {
    builder b;
    b_init(&b, 512);
    b_str(&b, "{\"supported\":true,\"capabilities\":{\"abiVersion\":\"rsm-wasm-json-v1\",\"commands\":[\"capabilities\",\"parse\",\"readCheats\",\"applyCheats\"],\"operations\":[\"moduleNumber\",\"moduleEnum\"],\"editableFields\":7}}");
    return finish(&b);
}

static uint64_t write_parse(const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0;
    uint32_t payload_len = 0;
    if (!payload_from_request(input, input_len, &payload, &payload_len)) {
        return unsupported("payload missing or not base64");
    }
    save_analysis a = analyze_save(payload, payload_len);
    if (!a.valid) {
        return unsupported("expected 8192-byte NSMBDS save with valid Mario2d blocks and checksums in both banks");
    }

    builder b;
    b_init(&b, OUTPUT_CAP);
    b_str(&b, "{\"supported\":true,\"parserLevel\":\"semantic\",\"parserId\":\"nds-new-super-mario-bros\",\"validatedSystem\":\"nds\",\"validatedGameId\":\"nds/new-super-mario-bros\",\"validatedGameTitle\":\"New Super Mario Bros.\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[\"validated 8192-byte Nintendo DS backup save\",\"validated repeated Mario2d save-block signatures\",\"validated NSMBDS 16-bit checksums across two 0x1000-byte banks\"],\"payloadSizeBytes\":8192,\"slotCount\":3,\"activeSlotIndexes\":[0,1,2],\"checksumValid\":true,\"semanticFields\":{\"signature\":\"Mario2d\",\"signatureCount\":");
    b_u32(&b, a.signature_count);
    b_str(&b, ",\"validBanks\":");
    b_u32(&b, a.valid_banks);
    b_str(&b, ",\"bankSize\":4096,\"saveFileBlocks\":3,\"editableFields\":7,\"fileALives\":");
    b_u32(&b, a.files[0].lives);
    b_str(&b, ",\"fileBLives\":");
    b_u32(&b, a.files[1].lives);
    b_str(&b, ",\"fileCLives\":");
    b_u32(&b, a.files[2].lives);
    b_str(&b, "}}");
    return finish(&b);
}

static uint64_t write_read_cheats(const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0;
    uint32_t payload_len = 0;
    if (!payload_from_request(input, input_len, &payload, &payload_len)) {
        return unsupported("payload missing or not base64");
    }
    save_analysis a = analyze_save(payload, payload_len);
    if (!a.valid) {
        return unsupported("NSMBDS checksums are not valid");
    }
    builder b;
    b_init(&b, OUTPUT_CAP);
    b_str(&b, "{\"supported\":true,\"gameId\":\"nds/new-super-mario-bros\",\"systemSlug\":\"nds\",\"editorId\":\"nds-new-super-mario-bros\",\"adapterId\":\"nds-new-super-mario-bros\",\"packId\":\"nds--new-super-mario-bros\",\"title\":\"New Super Mario Bros.\",\"availableCount\":7,\"slotValues\":{\"A\":");
    write_file_values_json(&b, a.files[0]);
    b_str(&b, ",\"B\":");
    write_file_values_json(&b, a.files[1]);
    b_str(&b, ",\"C\":");
    write_file_values_json(&b, a.files[2]);
    b_str(&b, "}}");
    return finish(&b);
}

static uint32_t slot_index_from_request(const uint8_t *input, uint32_t input_len) {
    slice slot;
    if (!json_string_raw(input, input_len, "slotId", &slot)) {
        return 0;
    }
    if (slice_eq(slot, "B")) {
        return 1;
    }
    if (slice_eq(slot, "C")) {
        return 2;
    }
    return 0;
}

static void copy_bytes(uint8_t *dst, const uint8_t *src, uint32_t len) {
    for (uint32_t i = 0; i < len; i++) {
        dst[i] = src[i];
    }
}

static void write_changed_prefix(builder *b, bool *wrote, const char *field) {
    if (*wrote) {
        b_char(b, ',');
    }
    b_char(b, '"');
    b_str(b, field);
    b_str(b, "\":");
    *wrote = true;
}

static uint64_t write_apply_cheats(const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0;
    uint32_t payload_len = 0;
    if (!payload_from_request(input, input_len, &payload, &payload_len)) {
        return unsupported("payload missing or not base64");
    }
    save_analysis a = analyze_save(payload, payload_len);
    if (!a.valid) {
        return unsupported("NSMBDS checksums are not valid");
    }
    uint8_t *updated = (uint8_t *)rsm_bump_alloc(payload_len);
    copy_bytes(updated, payload, payload_len);

    slice updates;
    if (!json_object_raw(input, input_len, "updates", &updates)) {
        return unsupported("updates missing");
    }
    uint32_t slot_index = slot_index_from_request(input, input_len);
    uint32_t rel = file_offsets[slot_index];
    bool changed = false;
    bool wrote_changed = false;
    builder changed_json;
    b_init(&changed_json, 2048);
    b_char(&changed_json, '{');

    int32_t int_value = 0;
    if (json_int_raw(updates.ptr, updates.len, "lives", &int_value) && int_value >= 0 && int_value <= 99) {
        for (uint32_t bank = 0; bank <= NSMB_BANK_SIZE; bank += NSMB_BANK_SIZE) {
            write_le32(updated + bank + rel + 0x16u, (uint32_t)int_value);
        }
        write_changed_prefix(&changed_json, &wrote_changed, "lives");
        b_u32(&changed_json, (uint32_t)int_value);
        changed = true;
    }
    if (json_int_raw(updates.ptr, updates.len, "coins", &int_value) && int_value >= 0 && int_value <= 99) {
        for (uint32_t bank = 0; bank <= NSMB_BANK_SIZE; bank += NSMB_BANK_SIZE) {
            write_le32(updated + bank + rel + 0x1au, (uint32_t)int_value);
        }
        write_changed_prefix(&changed_json, &wrote_changed, "coins");
        b_u32(&changed_json, (uint32_t)int_value);
        changed = true;
    }
    if (json_int_raw(updates.ptr, updates.len, "starCoins", &int_value) && int_value >= 0 && int_value <= 240) {
        for (uint32_t bank = 0; bank <= NSMB_BANK_SIZE; bank += NSMB_BANK_SIZE) {
            write_le32(updated + bank + rel + 0x22u, (uint32_t)int_value);
        }
        write_changed_prefix(&changed_json, &wrote_changed, "starCoins");
        b_u32(&changed_json, (uint32_t)int_value);
        changed = true;
    }
    if (json_int_raw(updates.ptr, updates.len, "score", &int_value) && int_value >= 0 && int_value <= 9999950) {
        for (uint32_t bank = 0; bank <= NSMB_BANK_SIZE; bank += NSMB_BANK_SIZE) {
            write_le32(updated + bank + rel + 0x1eu, (uint32_t)int_value);
        }
        write_changed_prefix(&changed_json, &wrote_changed, "score");
        b_u32(&changed_json, (uint32_t)int_value);
        changed = true;
    }
    slice text;
    uint8_t byte_value = 0;
    if (json_string_raw(updates.ptr, updates.len, "currentPowerup", &text) && powerup_value(text, &byte_value)) {
        for (uint32_t bank = 0; bank <= NSMB_BANK_SIZE; bank += NSMB_BANK_SIZE) {
            updated[bank + rel + 0x3au] = byte_value;
        }
        write_changed_prefix(&changed_json, &wrote_changed, "currentPowerup");
        b_char(&changed_json, '"');
        b_strn(&changed_json, (const char *)text.ptr, text.len);
        b_char(&changed_json, '"');
        changed = true;
    }
    if (json_string_raw(updates.ptr, updates.len, "reserveItem", &text) && reserve_value(text, &byte_value)) {
        for (uint32_t bank = 0; bank <= NSMB_BANK_SIZE; bank += NSMB_BANK_SIZE) {
            updated[bank + rel + 0x66u] = byte_value;
        }
        write_changed_prefix(&changed_json, &wrote_changed, "reserveItem");
        b_char(&changed_json, '"');
        b_strn(&changed_json, (const char *)text.ptr, text.len);
        b_char(&changed_json, '"');
        changed = true;
    }
    if (json_string_raw(updates.ptr, updates.len, "bottomScreenBackground", &text) && background_value(text, &byte_value)) {
        for (uint32_t bank = 0; bank <= NSMB_BANK_SIZE; bank += NSMB_BANK_SIZE) {
            updated[bank + rel + 0x42u] = byte_value;
        }
        write_changed_prefix(&changed_json, &wrote_changed, "bottomScreenBackground");
        b_char(&changed_json, '"');
        b_strn(&changed_json, (const char *)text.ptr, text.len);
        b_char(&changed_json, '"');
        changed = true;
    }
    b_char(&changed_json, '}');
    if (changed) {
        recalc_checksums(updated);
    }

    builder b;
    b_init(&b, OUTPUT_CAP);
    b_str(&b, "{\"payload\":\"");
    write_base64(&b, updated, payload_len);
    b_str(&b, "\",\"changed\":");
    b_strn(&b, changed_json.data, changed_json.len);
    b_str(&b, ",\"integritySteps\":[\"patched selected NSMBDS save file in both 0x1000-byte banks\",\"recalculated all NSMBDS header, save-file, and footer checksums\"]}");
    return finish(&b);
}

__attribute__((export_name("rsm_call")))
uint64_t rsm_call(int32_t command_ptr, int32_t command_len, int32_t input_ptr, int32_t input_len) {
    if (command_ptr <= 0 || command_len <= 0 || input_ptr < 0 || input_len < 0) {
        return unsupported("bad ABI pointers");
    }
    slice command = {(const uint8_t *)(uintptr_t)command_ptr, (uint32_t)command_len};
    const uint8_t *input = (const uint8_t *)(uintptr_t)input_ptr;
    uint32_t len = (uint32_t)input_len;
    if (slice_eq(command, "capabilities")) {
        return write_capabilities();
    }
    if (slice_eq(command, "parse")) {
        return write_parse(input, len);
    }
    if (slice_eq(command, "readCheats")) {
        return write_read_cheats(input, len);
    }
    if (slice_eq(command, "applyCheats")) {
        return write_apply_cheats(input, len);
    }
    return unsupported("unsupported command");
}
