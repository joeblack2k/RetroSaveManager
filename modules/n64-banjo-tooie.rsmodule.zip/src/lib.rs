#![no_std]

use core::panic::PanicInfo;
use core::ptr;
use core::slice;

#[cfg(feature = "tooie")]
const IS_TOOIE: bool = true;
#[cfg(not(feature = "tooie"))]
const IS_TOOIE: bool = false;

#[cfg(feature = "tooie")]
const GAME_ID: &[u8] = b"n64/banjo-tooie";
#[cfg(not(feature = "tooie"))]
const GAME_ID: &[u8] = b"n64/banjo-kazooie";

#[cfg(feature = "tooie")]
const GAME_TITLE: &[u8] = b"Banjo-Tooie";
#[cfg(not(feature = "tooie"))]
const GAME_TITLE: &[u8] = b"Banjo-Kazooie";

#[cfg(feature = "tooie")]
const PARSER_ID: &[u8] = b"bt-eeprom-wasm";
#[cfg(not(feature = "tooie"))]
const PARSER_ID: &[u8] = b"bk-eeprom-wasm";

const HEAP_SIZE: usize = 2 * 1024 * 1024;
const OUTPUT_CAP: usize = 384 * 1024;
const EEPROM_WINDOW: usize = 0x800;
const RA_SRM_SIZE: usize = 0x48800;
const NO_OFFSET: usize = usize::MAX;

#[derive(Clone, Copy)]
struct FlagSpec {
    id: &'static [u8],
    offset: u16,
    bit: u8,
    usa_shift: bool,
    extra: bool,
}

struct BitmaskField {
    key: &'static [u8],
    flags: &'static [FlagSpec],
}

include!("generated.rs");

static mut HEAP: [u8; HEAP_SIZE] = [0; HEAP_SIZE];
static mut HEAP_OFFSET: usize = 8;
static mut PAYLOAD: [u8; EEPROM_WINDOW] = [0; EEPROM_WINDOW];

#[panic_handler]
fn panic(_: &PanicInfo) -> ! {
    loop {}
}

fn heap_base() -> usize {
    ptr::addr_of_mut!(HEAP) as *mut u8 as usize
}

#[no_mangle]
pub extern "C" fn rsm_alloc(len: i32) -> i32 {
    if len < 0 {
        return 0;
    }
    let len = len as usize;
    unsafe {
        let relative = (HEAP_OFFSET + 7) & !7;
        let Some(end) = relative.checked_add(len) else {
            return 0;
        };
        if end >= HEAP_SIZE {
            return 0;
        }
        HEAP_OFFSET = end;
        (heap_base() + relative) as i32
    }
}

#[no_mangle]
pub extern "C" fn rsm_call(command_ptr: i32, command_len: i32, input_ptr: i32, input_len: i32) -> u64 {
    let Some(command) = read_bytes(command_ptr, command_len) else {
        return write_unsupported(b"bad command pointer");
    };
    let input = read_bytes(input_ptr, input_len).unwrap_or(&[]);
    if command == b"capabilities" {
        write_capabilities()
    } else if command == b"parse" {
        write_parse(input)
    } else if command == b"readCheats" {
        write_read_cheats(input)
    } else if command == b"applyCheats" {
        write_apply_cheats(input)
    } else {
        write_unsupported(b"unsupported command")
    }
}

fn read_bytes(ptr: i32, len: i32) -> Option<&'static [u8]> {
    if ptr < 0 || len < 0 {
        return None;
    }
    let ptr = ptr as usize;
    let len = len as usize;
    let end = ptr.checked_add(len)?;
    let base = heap_base();
    if ptr < base || end > base + HEAP_SIZE {
        return None;
    }
    unsafe { Some(slice::from_raw_parts(ptr as *const u8, len)) }
}

struct Writer {
    ptr: usize,
    len: usize,
    cap: usize,
}

impl Writer {
    fn new(cap: usize) -> Option<Writer> {
        let ptr = rsm_alloc(cap as i32);
        if ptr <= 0 {
            return None;
        }
        Some(Writer { ptr: ptr as usize, len: 0, cap })
    }

    fn finish(self) -> u64 {
        ((self.ptr as u64) << 32) | (self.len as u64)
    }

    fn byte(&mut self, value: u8) {
        if self.len >= self.cap {
            return;
        }
        unsafe {
            ptr::write((self.ptr + self.len) as *mut u8, value);
        }
        self.len += 1;
    }

    fn bytes(&mut self, values: &[u8]) {
        for value in values {
            self.byte(*value);
        }
    }

    fn bool(&mut self, value: bool) {
        self.bytes(if value { b"true" } else { b"false" });
    }

    fn usize(&mut self, mut value: usize) {
        let mut tmp = [0u8; 20];
        let mut idx = tmp.len();
        if value == 0 {
            self.byte(b'0');
            return;
        }
        while value > 0 {
            idx -= 1;
            tmp[idx] = b'0' + (value % 10) as u8;
            value /= 10;
        }
        self.bytes(&tmp[idx..]);
    }

    fn hex_u32_string(&mut self, value: u32) {
        self.byte(b'"');
        self.bytes(b"0x");
        for shift in (0..8).rev() {
            self.byte(hex_nibble(((value >> (shift * 4)) & 0xf) as u8));
        }
        self.byte(b'"');
    }

    fn hex_u64_string(&mut self, value: u64) {
        self.byte(b'"');
        self.bytes(b"0x");
        for shift in (0..16).rev() {
            self.byte(hex_nibble(((value >> (shift * 4)) & 0xf) as u8));
        }
        self.byte(b'"');
    }
}

fn hex_nibble(value: u8) -> u8 {
    if value < 10 { b'0' + value } else { b'a' + (value - 10) }
}

fn write_capabilities() -> u64 {
    let Some(mut w) = Writer::new(512) else { return 0; };
    w.bytes(b"{\"supported\":true,\"parserId\":\"");
    w.bytes(PARSER_ID);
    w.bytes(b"\",\"abiVersion\":\"rsm-wasm-json-v1\",\"capabilities\":{\"commands\":[\"capabilities\",\"parse\",\"readCheats\",\"applyCheats\"],\"nativeEEPROMWrites\":true,\"retroArchSRMReads\":true}}");
    w.finish()
}

fn write_unsupported(message: &[u8]) -> u64 {
    let Some(mut w) = Writer::new(512) else { return 0; };
    w.bytes(b"{\"supported\":false,\"warnings\":[\"");
    w.bytes(message);
    w.bytes(b"\"]}");
    w.finish()
}

fn write_parse(input: &[u8]) -> u64 {
    let Some(analysis) = analyze_input(input) else {
        return write_unsupported(if IS_TOOIE { b"expected Banjo-Tooie EEPROM with KHJC slot and valid Rare checksum" } else { b"expected Banjo-Kazooie EEPROM/global data with valid Rare checksum" });
    };
    if !analysis.supported {
        return write_unsupported(if IS_TOOIE { b"Banjo-Tooie slot checksums did not validate" } else { b"Banjo-Kazooie checksums did not validate" });
    }
    let Some(mut w) = Writer::new(OUTPUT_CAP) else { return 0; };
    w.bytes(b"{\"supported\":true,\"parserLevel\":\"semantic\",\"parserId\":\"");
    w.bytes(PARSER_ID);
    w.bytes(b"\",\"validatedSystem\":\"n64\",\"validatedGameId\":\"");
    w.bytes(GAME_ID);
    w.bytes(b"\",\"validatedGameTitle\":\"");
    w.bytes(GAME_TITLE);
    w.bytes(b"\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[");
    if IS_TOOIE {
        w.bytes(b"\"validated 2048-byte 16Kbit EEPROM window\",\"validated KHJC slot magic\",\"validated 64-bit Rare checksum over each active 0x1b8-byte slot body\",\"BT USA region bit shifting follows Game Tools Collection utils.ts\",\"field offsets cross-checked against Game Tools Collection Banjo-Tooie template\"");
    } else {
        w.bytes(b"\"validated Banjo-Kazooie 0x200-byte save data inside EEPROM window\",\"validated 32-bit Rare checksum for active 0x78-byte slots or global Stop n Swop data\",\"field offsets cross-checked against BKSaveEditor and Game Tools Collection\"");
    }
    w.bytes(b"],\"warnings\":[");
    if analysis.total_len == RA_SRM_SIZE {
        w.bytes(b"\"RetroArch 0x48800 SRM containers are parsed read-only; cheat writes are limited to native EEPROM windows.\"");
    }
    w.bytes(b"],\"payloadSizeBytes\":");
    w.usize(analysis.total_len);
    w.bytes(b",\"slotCount\":");
    w.usize(analysis.slot_count);
    w.bytes(b",\"activeSlotIndexes\":[");
    let mut wrote = false;
    for idx in 0..3 {
        if analysis.slot_offsets[idx] != usize::MAX {
            if wrote {
                w.byte(b',');
            }
            w.usize(idx + 1);
            wrote = true;
        }
    }
    w.bytes(b"],\"checksumValid\":true,\"semanticFields\":{");
    w.bytes(if IS_TOOIE { b"\"saveModel\":\"eeprom-16k-khjc-slots\"" } else { b"\"saveModel\":\"eeprom-4k-bk-slots-global-sns\"" });
    w.bytes(b",\"nativeEEPROMWriteSupported\":");
    w.bool(analysis.total_len != RA_SRM_SIZE);
    w.bytes(b",\"validSlotCount\":");
    w.usize(analysis.slot_count);
    if !IS_TOOIE {
        w.bytes(b",\"globalChecksumValid\":");
        w.bool(analysis.global_valid);
    } else {
        w.bytes(b",\"extraReplaySettingsChecksumValid\":");
        w.bool(analysis.extra_offset != NO_OFFSET);
    }
    for idx in 0..3 {
        w.bytes(b",\"slot");
        w.byte(b'A' + idx as u8);
        w.bytes(b"Valid\":");
        w.bool(analysis.slot_offsets[idx] != usize::MAX);
        if analysis.slot_offsets[idx] != usize::MAX {
            w.bytes(b",\"slot");
            w.byte(b'A' + idx as u8);
            w.bytes(b"Checksum\":");
            if IS_TOOIE {
                w.hex_u64_string(read_be_u64(payload_ref(), analysis.slot_offsets[idx] + 0x1b8));
            } else {
                w.hex_u32_string(read_be_u32(payload_ref(), analysis.slot_offsets[idx] + 0x74));
            }
        }
    }
    w.bytes(b"}}");
    w.finish()
}

fn write_read_cheats(input: &[u8]) -> u64 {
    let Some(analysis) = analyze_input(input) else {
        return write_unsupported(b"payload missing or unsupported");
    };
    if analysis.slot_count == 0 {
        return write_unsupported(b"no active save slot with a valid checksum");
    }
    let Some(mut w) = Writer::new(OUTPUT_CAP) else { return 0; };
    w.bytes(b"{\"supported\":true,\"values\":");
    let first = first_slot(&analysis).unwrap_or(0);
    write_values(&mut w, first, &analysis, input);
    w.bytes(b",\"slotValues\":{");
    let mut wrote = false;
    for idx in 0..3 {
        let off = analysis.slot_offsets[idx];
        if off == usize::MAX {
            continue;
        }
        if wrote {
            w.byte(b',');
        }
        w.byte(b'"');
        w.byte(b'A' + idx as u8);
        w.bytes(b"\":");
        write_values(&mut w, off, &analysis, input);
        wrote = true;
    }
    w.bytes(b"}}");
    w.finish()
}

fn write_apply_cheats(input: &[u8]) -> u64 {
    let Some(analysis) = analyze_input(input) else {
        return write_apply_error(b"unsupported payload");
    };
    if analysis.total_len == RA_SRM_SIZE {
        return write_apply_error(b"RetroArch SRM containers are read-only in this module; export a native .eep window to edit");
    }
    let slot_id = json_string_field(input, b"slotId")
        .and_then(|(start, len)| input.get(start).copied().filter(|_| len > 0))
        .unwrap_or(b'A');
    let slot_index = match slot_id {
        b'A' | b'a' | b'1' => 0,
        b'B' | b'b' | b'2' => 1,
        b'C' | b'c' | b'3' => 2,
        _ => 0,
    };
    let off = if analysis.slot_offsets[slot_index] != NO_OFFSET {
        analysis.slot_offsets[slot_index]
    } else {
        first_slot(&analysis).unwrap_or(NO_OFFSET)
    };

    let updates = updates_start(input).unwrap_or(0);
    if IS_TOOIE {
        if off == NO_OFFSET {
            return write_apply_error(b"requested Banjo-Tooie slot is not active");
        }
        let usa = bt_region_is_usa(input);
        apply_tooie_slot_numbers(input, updates, off);
        apply_bitmask_fields(input, updates, off, BT_SLOT_BITMASK_FIELDS, usa);
        let sum = rare_checksum_64(payload_ref(), off, off + 0x1b8);
        write_be_u64(off + 0x1b8, sum);
        if analysis.extra_offset != NO_OFFSET {
            apply_tooie_extra_numbers(input, updates, analysis.extra_offset, usa);
            apply_bitmask_fields(input, updates, analysis.extra_offset, BT_EXTRA_BITMASK_FIELDS, usa);
            let extra_sum = rare_checksum_64(payload_ref(), analysis.extra_offset, analysis.extra_offset + 0x78);
            write_be_u64(analysis.extra_offset + 0x78, extra_sum);
        }
    } else {
        if off != NO_OFFSET {
            apply_kazooie_slot_numbers(input, updates, off);
            apply_bitmask_fields(input, updates, off, BK_SLOT_BITMASK_FIELDS, false);
            let sum = bk_checksum_32(payload_ref(), off, off + 0x74);
            write_be_u32(off + 0x74, sum);
        }
        if analysis.global_valid {
            apply_bitmask_fields(input, updates, 0, BK_GLOBAL_BITMASK_FIELDS, false);
            let global_sum = bk_checksum_32(payload_ref(), 0x1e0, 0x1fc);
            write_be_u32(0x1fc, global_sum);
        }
    }

    let native_len = if analysis.total_len == 512 { 512 } else { 2048 };
    let Some(mut w) = Writer::new(8192) else { return 0; };
    w.bytes(b"{\"payload\":\"");
    write_base64(&mut w, payload_ref_range(native_len));
    w.bytes(b"\",\"changed\":{\"slotId\":\"");
    w.byte(b'A' + slot_index as u8);
    w.bytes(b"\"},\"integritySteps\":[\"");
    w.bytes(if IS_TOOIE { b"rebuilt Banjo-Tooie 64-bit Rare slot/replay checksums as needed" } else { b"rebuilt Banjo-Kazooie 32-bit Rare slot/global checksums as needed" });
    w.bytes(b"\"]}");
    w.finish()
}

fn write_apply_error(message: &[u8]) -> u64 {
    let Some(mut w) = Writer::new(512) else { return 0; };
    w.bytes(b"{\"changed\":{},\"integritySteps\":[\"");
    w.bytes(message);
    w.bytes(b"\"]}");
    w.finish()
}

#[derive(Clone, Copy)]
struct Analysis {
    total_len: usize,
    slot_count: usize,
    slot_offsets: [usize; 3],
    extra_offset: usize,
    global_valid: bool,
    supported: bool,
}

fn analyze_input(input: &[u8]) -> Option<Analysis> {
    let (start, len) = json_string_field(input, b"payload")?;
    let encoded = &input[start..start + len];
    let total_len = decoded_base64_len(encoded)?;
    if total_len != 512 && total_len != 2048 && total_len != RA_SRM_SIZE {
        return None;
    }
    let decode_len = if total_len == 512 { 512 } else { 2048 };
    decode_base64_prefix(encoded, decode_len)?;
    if IS_TOOIE {
        Some(analyze_tooie(total_len))
    } else {
        Some(analyze_kazooie(total_len))
    }
}

fn analyze_kazooie(total_len: usize) -> Analysis {
    let payload = payload_ref();
    let mut slots = [usize::MAX; 3];
    let mut count = 0usize;
    for i in 0..4 {
        let off = i * 0x78;
        let magic = payload[off];
        let raw_index = payload[off + 1];
        let display = if raw_index == 2 { 3 } else if raw_index == 3 { 2 } else { raw_index };
        if magic != 0x11 || display < 1 || display > 3 {
            continue;
        }
        let stored = read_be_u32(payload, off + 0x74);
        let calc = bk_checksum_32(payload, off, off + 0x74);
        if stored == calc {
            let idx = (display - 1) as usize;
            if slots[idx] == usize::MAX {
                count += 1;
            }
            slots[idx] = off;
        }
    }
    let global_valid = read_be_u32(payload, 0x1fc) == bk_checksum_32(payload, 0x1e0, 0x1fc);
    Analysis { total_len, slot_count: count, slot_offsets: slots, extra_offset: NO_OFFSET, global_valid, supported: count > 0 || global_valid }
}

fn analyze_tooie(total_len: usize) -> Analysis {
    let payload = payload_ref();
    let mut slots = [usize::MAX; 3];
    let mut count = 0usize;
    for i in 0..4 {
        let off = 0x100 + i * 0x1c0;
        if &payload[off..off + 4] != b"KHJC" {
            continue;
        }
        let display = payload[off + 0x0a];
        if display < 1 || display > 3 {
            continue;
        }
        let stored = read_be_u64(payload, off + 0x1b8);
        let calc = rare_checksum_64(payload, off, off + 0x1b8);
        if stored == calc {
            let idx = (display - 1) as usize;
            if slots[idx] == usize::MAX {
                count += 1;
            }
            slots[idx] = off;
        }
    }
    let extra_offset = tooie_extra_offset(payload);
    Analysis { total_len, slot_count: count, slot_offsets: slots, extra_offset, global_valid: false, supported: count > 0 }
}

fn tooie_extra_offset(payload: &[u8]) -> usize {
    let candidates = [0usize, 0x80usize];
    for off in candidates {
        if read_be_u32(payload, off) == 0 {
            continue;
        }
        let stored = read_be_u64(payload, off + 0x78);
        let calc = rare_checksum_64(payload, off, off + 0x78);
        if stored == calc {
            return off;
        }
    }
    NO_OFFSET
}

fn first_slot(analysis: &Analysis) -> Option<usize> {
    for off in analysis.slot_offsets {
        if off != usize::MAX {
            return Some(off);
        }
    }
    None
}

fn write_values(w: &mut Writer, off: usize, analysis: &Analysis, input: &[u8]) {
    let payload = payload_ref();
    w.byte(b'{');
    let mut wrote = false;
    if IS_TOOIE {
        let usa = bt_region_is_usa(input);
        write_bool_field_auto(w, b"usaRegionShiftActive", usa, &mut wrote);
        write_num_field_auto(w, b"totalPlaytimeSeconds", tooie_total_playtime(payload, off), &mut wrote);
        write_num_field_auto(w, b"totalJiggiesCollected", tooie_total_jiggies(payload, off, usa), &mut wrote);
        write_num_field_auto(w, b"totalNotesValue", tooie_total_notes(payload, off, usa), &mut wrote);
        write_tooie_slot_values(w, payload, off, &mut wrote);
        for field in BT_SLOT_BITMASK_FIELDS {
            write_bitmask_field(w, field.key, field.flags, off, usa, &mut wrote);
        }
        if analysis.extra_offset != NO_OFFSET {
            write_tooie_extra_values(w, payload, analysis.extra_offset, usa, &mut wrote);
            for field in BT_EXTRA_BITMASK_FIELDS {
                write_bitmask_field(w, field.key, field.flags, analysis.extra_offset, usa, &mut wrote);
            }
        }
    } else {
        write_num_field_auto(w, b"totalPlaytimeSeconds", kazooie_total_playtime(payload, off), &mut wrote);
        write_num_field_auto(w, b"totalJiggiesCollected", bit_count_range(payload, off + 0x02, 13), &mut wrote);
        write_num_field_auto(w, b"totalNotesValue", kazooie_total_notes(payload, off), &mut wrote);
        write_kazooie_slot_values(w, payload, off, &mut wrote);
        for field in BK_SLOT_BITMASK_FIELDS {
            write_bitmask_field(w, field.key, field.flags, off, false, &mut wrote);
        }
        if analysis.global_valid {
            for field in BK_GLOBAL_BITMASK_FIELDS {
                write_bitmask_field(w, field.key, field.flags, 0, false, &mut wrote);
            }
        }
    }
    w.byte(b'}');
}

fn write_kazooie_slot_values(w: &mut Writer, payload: &[u8], off: usize, wrote: &mut bool) {
    write_num_field_auto(w, b"jiggiesHeld", payload[off + 0x69] as usize, wrote);
    write_num_field_auto(w, b"mumboTokens", payload[off + 0x65] as usize, wrote);
    write_num_field_auto(w, b"eggs", payload[off + 0x66] as usize, wrote);
    write_num_field_auto(w, b"redFeathers", payload[off + 0x67] as usize, wrote);
    write_num_field_auto(w, b"goldFeathers", payload[off + 0x68] as usize, wrote);
    write_bool_field_auto(w, b"doubleHealth", bit(payload[off + 0x57], 1), wrote);
    write_bool_field_auto(w, b"maxEggsUpgrade", bit(payload[off + 0x57], 6), wrote);
    write_bool_field_auto(w, b"maxRedFeathersUpgrade", bit(payload[off + 0x57], 7), wrote);
    write_bool_field_auto(w, b"maxGoldFeathersUpgrade", bit(payload[off + 0x58], 0), wrote);
    write_bk_time_values(w, payload, off, wrote);
    write_bk_note_values(w, payload, off, wrote);
}

fn write_tooie_slot_values(w: &mut Writer, payload: &[u8], off: usize, wrote: &mut bool) {
    write_num_field_auto(w, b"extraHoneycombs", read_be_u16(payload, off + 0x3d) as usize, wrote);
    write_num_field_auto(w, b"cheatoPages", read_be_u16(payload, off + 0x3f) as usize, wrote);
    write_num_field_auto(w, b"glowbos", read_be_u16(payload, off + 0x3b) as usize, wrote);
    write_num_field_auto(w, b"megaGlowbos", read_be_u16(payload, off + 0x53) as usize, wrote);
    write_num_field_auto(w, b"eggs", read_be_u16(payload, off + 0x2b) as usize, wrote);
    write_num_field_auto(w, b"fireEggs", read_be_u16(payload, off + 0x2d) as usize, wrote);
    write_num_field_auto(w, b"iceEggs", read_be_u16(payload, off + 0x2f) as usize, wrote);
    write_num_field_auto(w, b"grenadeEggs", read_be_u16(payload, off + 0x31) as usize, wrote);
    write_num_field_auto(w, b"clockworkEggs", read_be_u16(payload, off + 0x33) as usize, wrote);
    write_num_field_auto(w, b"redFeathers", read_be_u16(payload, off + 0x37) as usize, wrote);
    write_num_field_auto(w, b"goldFeathers", read_be_u16(payload, off + 0x39) as usize, wrote);
    write_num_field_auto(w, b"doubloons", read_be_u16(payload, off + 0x47) as usize, wrote);
    write_num_field_auto(w, b"iceKey", read_be_u16(payload, off + 0x51) as usize, wrote);
    write_num_field_auto(w, b"extraEnergy", read_bitfield(payload, off + 0x11b, 4, 3) as usize, wrote);
    write_num_field_auto(w, b"trainLocationBits", read_bitfield(payload, off + 0x11b, 7, 7) as usize, wrote);
    write_num_field_auto(w, b"jinjoSeed", read_bitfield(payload, off + 0xed, 3, 6) as usize, wrote);
    write_num_field_auto(w, b"klungoPotion", read_bitfield(payload, off + 0xe0, 7, 3) as usize, wrote);
    write_num_field_auto(w, b"jiggywiggyChallenge", read_bitfield(payload, off + 0xe9, 6, 4) as usize, wrote);
    write_num_field_auto(w, b"towerOfTragedyRound", read_bitfield(payload, off + 0x106, 4, 3) as usize, wrote);
    write_bool_field_auto(w, b"dragonKazooie", bit(payload[off + 0xfb], 6), wrote);
    write_bool_field_auto(w, b"blueSecretEgg", bit(payload[off + 0xfa], 5), wrote);
    write_bool_field_auto(w, b"pinkSecretEgg", bit(payload[off + 0xfa], 7), wrote);
    write_bt_time_values(w, payload, off, wrote);
}

fn write_tooie_extra_values(w: &mut Writer, payload: &[u8], extra_off: usize, usa: bool, wrote: &mut bool) {
    write_bool_field_auto(w, b"wideScreen", bit(payload[extra_off + 0x01], 1), wrote);
    write_num_field_auto(w, b"speakerMode", read_bitfield(payload, extra_off + 0x02, 6, 2) as usize, wrote);
    write_num_field_auto(w, b"language", read_bitfield(payload, extra_off + 0x0b, 5, 2) as usize, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayMayanKickballQuarterfinal", 0x2b, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayMayanKickballSemifinal", 0x2d, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayMayanKickballFinal", 0x2f, usa, wrote);
    write_extra_colosseum_field(w, payload, extra_off, b"replayColosseumKickballQuarterfinal", 0x31, usa, wrote);
    write_extra_colosseum_field(w, payload, extra_off, b"replayColosseumKickballSemifinal", 0x33, usa, wrote);
    write_extra_colosseum_field(w, payload, extra_off, b"replayColosseumKickballFinal", 0x35, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayDodgemsOneOnOne", 0x23, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayDodgemsTwoOnOne", 0x25, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayDodgemsThreeOnOne", 0x27, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayPotOGoldBestScore", 0x17, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayPotOGoldBestTime", 0x21, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayOrdnanceStorage", 0x39, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayHoopHurryChallenge", 0x11, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayBalloonBurstChallenge", 0x0f, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replaySaucerOfPerilRide", 0x29, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayMiniSubChallenge", 0x1f, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayChompasBelly", 0x19, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayClinkersCavern", 0x37, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayTwinkliesPacking", 0x15, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayTrashCanGerms", 0x1b, usa, wrote);
    write_extra_i16_field(w, payload, extra_off, b"replayZubbasHive", 0x1d, usa, wrote);
}

fn write_num_field(w: &mut Writer, key: &[u8], value: usize, comma: bool) {
    if comma {
        w.byte(b',');
    }
    w.byte(b'"');
    w.bytes(key);
    w.bytes(b"\":");
    w.usize(value);
}

fn write_num_field_auto(w: &mut Writer, key: &[u8], value: usize, wrote: &mut bool) {
    write_num_field(w, key, value, *wrote);
    *wrote = true;
}

fn write_bool_field(w: &mut Writer, key: &[u8], value: bool, comma: bool) {
    if comma {
        w.byte(b',');
    }
    w.byte(b'"');
    w.bytes(key);
    w.bytes(b"\":");
    w.bool(value);
}

fn write_bool_field_auto(w: &mut Writer, key: &[u8], value: bool, wrote: &mut bool) {
    write_bool_field(w, key, value, *wrote);
    *wrote = true;
}

fn write_bitmask_field(w: &mut Writer, key: &[u8], flags: &[FlagSpec], base: usize, usa: bool, wrote: &mut bool) {
    if *wrote {
        w.byte(b',');
    }
    *wrote = true;
    w.byte(b'"');
    w.bytes(key);
    w.bytes(b"\":[");
    let payload = payload_ref();
    let mut any = false;
    for flag in flags {
        let (off, bit_idx) = physical_flag_location(flag, base, usa);
        if off >= EEPROM_WINDOW {
            continue;
        }
        if bit(payload[off], bit_idx) {
            if any {
                w.byte(b',');
            }
            w.byte(b'"');
            w.bytes(flag.id);
            w.byte(b'"');
            any = true;
        }
    }
    w.byte(b']');
}

fn write_extra_i16_field(w: &mut Writer, payload: &[u8], base: usize, key: &[u8], logical_off: u16, usa: bool, wrote: &mut bool) {
    let off = base + bt_extra_physical_offset(logical_off, usa);
    let value = read_be_i16(payload, off);
    write_num_field_auto(w, key, if value < 0 { 0 } else { value as usize }, wrote);
}

fn write_extra_colosseum_field(w: &mut Writer, payload: &[u8], base: usize, key: &[u8], logical_off: u16, usa: bool, wrote: &mut bool) {
    let off = base + bt_extra_physical_offset(logical_off, usa);
    let mut value = read_be_i16(payload, off);
    if value > 0 {
        value -= 0x3e80;
    }
    write_num_field_auto(w, key, if value < 0 { 0 } else { value as usize }, wrote);
}

fn write_bk_time_values(w: &mut Writer, payload: &[u8], off: usize, wrote: &mut bool) {
    write_num_field_auto(w, b"timeSpiralMountain", read_be_u16(payload, off + 0x2a + 10 * 2) as usize, wrote);
    write_num_field_auto(w, b"timeGruntildasLair", read_be_u16(payload, off + 0x2a + 5 * 2) as usize, wrote);
    write_num_field_auto(w, b"timeMumbosMountain", read_be_u16(payload, off + 0x2a) as usize, wrote);
    write_num_field_auto(w, b"timeTreasureTroveCove", read_be_u16(payload, off + 0x2a + 1 * 2) as usize, wrote);
    write_num_field_auto(w, b"timeClankersCavern", read_be_u16(payload, off + 0x2a + 2 * 2) as usize, wrote);
    write_num_field_auto(w, b"timeBubblegloopSwamp", read_be_u16(payload, off + 0x2a + 3 * 2) as usize, wrote);
    write_num_field_auto(w, b"timeFreezeezyPeak", read_be_u16(payload, off + 0x2a + 4 * 2) as usize, wrote);
    write_num_field_auto(w, b"timeGobisValley", read_be_u16(payload, off + 0x2a + 6 * 2) as usize, wrote);
    write_num_field_auto(w, b"timeMadMonsterMansion", read_be_u16(payload, off + 0x2a + 9 * 2) as usize, wrote);
    write_num_field_auto(w, b"timeRustyBucketBay", read_be_u16(payload, off + 0x2a + 8 * 2) as usize, wrote);
    write_num_field_auto(w, b"timeClickClockWood", read_be_u16(payload, off + 0x2a + 7 * 2) as usize, wrote);
}

fn write_bk_note_values(w: &mut Writer, payload: &[u8], off: usize, wrote: &mut bool) {
    write_num_field_auto(w, b"notesMumbosMountain", bk_note_score(payload, off, 56) as usize, wrote);
    write_num_field_auto(w, b"notesTreasureTroveCove", bk_note_score(payload, off, 49) as usize, wrote);
    write_num_field_auto(w, b"notesClankersCavern", bk_note_score(payload, off, 42) as usize, wrote);
    write_num_field_auto(w, b"notesBubblegloopSwamp", bk_note_score(payload, off, 35) as usize, wrote);
    write_num_field_auto(w, b"notesFreezeezyPeak", bk_note_score(payload, off, 28) as usize, wrote);
    write_num_field_auto(w, b"notesGobisValley", bk_note_score(payload, off, 21) as usize, wrote);
    write_num_field_auto(w, b"notesMadMonsterMansion", bk_note_score(payload, off, 0) as usize, wrote);
    write_num_field_auto(w, b"notesRustyBucketBay", bk_note_score(payload, off, 7) as usize, wrote);
    write_num_field_auto(w, b"notesClickClockWood", bk_note_score(payload, off, 14) as usize, wrote);
}

fn write_bt_time_values(w: &mut Writer, payload: &[u8], off: usize, wrote: &mut bool) {
    write_num_field_auto(w, b"timeSpiralMountain", read_be_u16(payload, off + 0x17) as usize, wrote);
    write_num_field_auto(w, b"timeIsleOHags", read_be_u16(payload, off + 0x25) as usize, wrote);
    write_num_field_auto(w, b"timeMayahemTemple", read_be_u16(payload, off + 0x11) as usize, wrote);
    write_num_field_auto(w, b"timeGlitterGulchMine", read_be_u16(payload, off + 0x0f) as usize, wrote);
    write_num_field_auto(w, b"timeWitchyworld", read_be_u16(payload, off + 0x15) as usize, wrote);
    write_num_field_auto(w, b"timeJollyRogersLagoon", read_be_u16(payload, off + 0x19) as usize, wrote);
    write_num_field_auto(w, b"timeTerrydactyland", read_be_u16(payload, off + 0x1b) as usize, wrote);
    write_num_field_auto(w, b"timeGruntyIndustries", read_be_u16(payload, off + 0x1d) as usize, wrote);
    write_num_field_auto(w, b"timeHailfirePeaks", read_be_u16(payload, off + 0x1f) as usize, wrote);
    write_num_field_auto(w, b"timeCloudCuckooland", read_be_u16(payload, off + 0x21) as usize, wrote);
    write_num_field_auto(w, b"timeCauldronKeep", read_be_u16(payload, off + 0x23) as usize, wrote);
}

fn apply_kazooie_slot_numbers(input: &[u8], updates: usize, off: usize) {
    apply_u8(input, updates, b"jiggiesHeld", off + 0x69, 100);
    apply_u8(input, updates, b"mumboTokens", off + 0x65, 116);
    apply_u8(input, updates, b"eggs", off + 0x66, 200);
    apply_u8(input, updates, b"redFeathers", off + 0x67, 100);
    apply_u8(input, updates, b"goldFeathers", off + 0x68, 20);
    apply_bit(input, updates, b"doubleHealth", off + 0x57, 1);
    apply_bit(input, updates, b"maxEggsUpgrade", off + 0x57, 6);
    apply_bit(input, updates, b"maxRedFeathersUpgrade", off + 0x57, 7);
    apply_bit(input, updates, b"maxGoldFeathersUpgrade", off + 0x58, 0);
    apply_bk_time_values(input, updates, off);
    apply_bk_note_values(input, updates, off);
}

fn apply_tooie_slot_numbers(input: &[u8], updates: usize, off: usize) {
    apply_u16(input, updates, b"extraHoneycombs", off + 0x3d, 25);
    apply_u16(input, updates, b"cheatoPages", off + 0x3f, 25);
    apply_u16(input, updates, b"glowbos", off + 0x3b, 17);
    apply_u16(input, updates, b"megaGlowbos", off + 0x53, 1);
    apply_u16(input, updates, b"eggs", off + 0x2b, 999);
    apply_u16(input, updates, b"fireEggs", off + 0x2d, 999);
    apply_u16(input, updates, b"iceEggs", off + 0x2f, 999);
    apply_u16(input, updates, b"grenadeEggs", off + 0x31, 999);
    apply_u16(input, updates, b"clockworkEggs", off + 0x33, 999);
    apply_u16(input, updates, b"redFeathers", off + 0x37, 999);
    apply_u16(input, updates, b"goldFeathers", off + 0x39, 999);
    apply_u16(input, updates, b"doubloons", off + 0x47, 30);
    apply_u16(input, updates, b"iceKey", off + 0x51, 1);
    apply_bitfield(input, updates, b"extraEnergy", off + 0x11b, 4, 3, 5);
    apply_bitfield(input, updates, b"trainLocationBits", off + 0x11b, 7, 7, 0x7f);
    apply_bitfield(input, updates, b"jinjoSeed", off + 0xed, 3, 6, 0x3f);
    apply_bitfield(input, updates, b"klungoPotion", off + 0xe0, 7, 3, 6);
    apply_bitfield(input, updates, b"jiggywiggyChallenge", off + 0xe9, 6, 4, 10);
    apply_bitfield(input, updates, b"towerOfTragedyRound", off + 0x106, 4, 3, 4);
    apply_bit(input, updates, b"dragonKazooie", off + 0xfb, 6);
    apply_bit(input, updates, b"blueSecretEgg", off + 0xfa, 5);
    apply_bit(input, updates, b"pinkSecretEgg", off + 0xfa, 7);
    apply_bt_time_values(input, updates, off);
}

fn apply_tooie_extra_numbers(input: &[u8], updates: usize, extra_off: usize, usa: bool) {
    apply_bit(input, updates, b"wideScreen", extra_off + 0x01, 1);
    apply_bitfield(input, updates, b"speakerMode", extra_off + 0x02, 6, 2, 3);
    apply_bitfield(input, updates, b"language", extra_off + 0x0b, 5, 2, 3);
    apply_extra_i16(input, updates, extra_off, b"replayMayanKickballQuarterfinal", 0x2b, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayMayanKickballSemifinal", 0x2d, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayMayanKickballFinal", 0x2f, usa, 32767);
    apply_extra_colosseum(input, updates, extra_off, b"replayColosseumKickballQuarterfinal", 0x31, usa);
    apply_extra_colosseum(input, updates, extra_off, b"replayColosseumKickballSemifinal", 0x33, usa);
    apply_extra_colosseum(input, updates, extra_off, b"replayColosseumKickballFinal", 0x35, usa);
    apply_extra_i16(input, updates, extra_off, b"replayDodgemsOneOnOne", 0x23, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayDodgemsTwoOnOne", 0x25, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayDodgemsThreeOnOne", 0x27, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayPotOGoldBestScore", 0x17, usa, 100);
    apply_extra_i16(input, updates, extra_off, b"replayPotOGoldBestTime", 0x21, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayOrdnanceStorage", 0x39, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayHoopHurryChallenge", 0x11, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayBalloonBurstChallenge", 0x0f, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replaySaucerOfPerilRide", 0x29, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayMiniSubChallenge", 0x1f, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayChompasBelly", 0x19, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayClinkersCavern", 0x37, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayTwinkliesPacking", 0x15, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayTrashCanGerms", 0x1b, usa, 32767);
    apply_extra_i16(input, updates, extra_off, b"replayZubbasHive", 0x1d, usa, 32767);
}

fn apply_bk_time_values(input: &[u8], updates: usize, off: usize) {
    apply_u16(input, updates, b"timeSpiralMountain", off + 0x2a + 10 * 2, 65535);
    apply_u16(input, updates, b"timeGruntildasLair", off + 0x2a + 5 * 2, 65535);
    apply_u16(input, updates, b"timeMumbosMountain", off + 0x2a, 65535);
    apply_u16(input, updates, b"timeTreasureTroveCove", off + 0x2a + 1 * 2, 65535);
    apply_u16(input, updates, b"timeClankersCavern", off + 0x2a + 2 * 2, 65535);
    apply_u16(input, updates, b"timeBubblegloopSwamp", off + 0x2a + 3 * 2, 65535);
    apply_u16(input, updates, b"timeFreezeezyPeak", off + 0x2a + 4 * 2, 65535);
    apply_u16(input, updates, b"timeGobisValley", off + 0x2a + 6 * 2, 65535);
    apply_u16(input, updates, b"timeMadMonsterMansion", off + 0x2a + 9 * 2, 65535);
    apply_u16(input, updates, b"timeRustyBucketBay", off + 0x2a + 8 * 2, 65535);
    apply_u16(input, updates, b"timeClickClockWood", off + 0x2a + 7 * 2, 65535);
}

fn apply_bk_note_values(input: &[u8], updates: usize, off: usize) {
    apply_bk_note(input, updates, b"notesMumbosMountain", off, 56);
    apply_bk_note(input, updates, b"notesTreasureTroveCove", off, 49);
    apply_bk_note(input, updates, b"notesClankersCavern", off, 42);
    apply_bk_note(input, updates, b"notesBubblegloopSwamp", off, 35);
    apply_bk_note(input, updates, b"notesFreezeezyPeak", off, 28);
    apply_bk_note(input, updates, b"notesGobisValley", off, 21);
    apply_bk_note(input, updates, b"notesMadMonsterMansion", off, 0);
    apply_bk_note(input, updates, b"notesRustyBucketBay", off, 7);
    apply_bk_note(input, updates, b"notesClickClockWood", off, 14);
}

fn apply_bt_time_values(input: &[u8], updates: usize, off: usize) {
    apply_u16(input, updates, b"timeSpiralMountain", off + 0x17, 65535);
    apply_u16(input, updates, b"timeIsleOHags", off + 0x25, 65535);
    apply_u16(input, updates, b"timeMayahemTemple", off + 0x11, 65535);
    apply_u16(input, updates, b"timeGlitterGulchMine", off + 0x0f, 65535);
    apply_u16(input, updates, b"timeWitchyworld", off + 0x15, 65535);
    apply_u16(input, updates, b"timeJollyRogersLagoon", off + 0x19, 65535);
    apply_u16(input, updates, b"timeTerrydactyland", off + 0x1b, 65535);
    apply_u16(input, updates, b"timeGruntyIndustries", off + 0x1d, 65535);
    apply_u16(input, updates, b"timeHailfirePeaks", off + 0x1f, 65535);
    apply_u16(input, updates, b"timeCloudCuckooland", off + 0x21, 65535);
    apply_u16(input, updates, b"timeCauldronKeep", off + 0x23, 65535);
}

fn apply_u8(input: &[u8], start: usize, key: &[u8], off: usize, max: i32) {
    if let Some(value) = json_number_from(input, start, key) {
        let value = clamp(value, 0, max) as u8;
        write_u8(off, value);
    }
}

fn apply_u16(input: &[u8], start: usize, key: &[u8], off: usize, max: i32) {
    if let Some(value) = json_number_from(input, start, key) {
        let value = clamp(value, 0, max) as u16;
        write_be_u16(off, value);
    }
}

fn apply_bit(input: &[u8], start: usize, key: &[u8], off: usize, bit_idx: u8) {
    if let Some(value) = json_bool_from(input, start, key) {
        let current = payload_ref()[off];
        let mask = 1u8 << bit_idx;
        write_u8(off, if value { current | mask } else { current & !mask });
    }
}

fn apply_bitfield(input: &[u8], start: usize, key: &[u8], off: usize, bit_start: u8, bit_len: u8, max: i32) {
    if let Some(value) = json_number_from(input, start, key) {
        write_bitfield(off, bit_start, bit_len, clamp(value, 0, max) as u16);
    }
}

fn apply_extra_i16(input: &[u8], start: usize, base: usize, key: &[u8], logical_off: u16, usa: bool, max: i32) {
    if let Some(value) = json_number_from(input, start, key) {
        let value = clamp(value, 0, max) as i16;
        let off = base + bt_extra_physical_offset(logical_off, usa);
        write_be_i16(off, value);
    }
}

fn apply_extra_colosseum(input: &[u8], start: usize, base: usize, key: &[u8], logical_off: u16, usa: bool) {
    if let Some(value) = json_number_from(input, start, key) {
        let mut value = clamp(value, 0, 50) as i16;
        if value > 0 {
            value += 0x3e80;
        }
        let off = base + bt_extra_physical_offset(logical_off, usa);
        write_be_i16(off, value);
    }
}

fn apply_bk_note(input: &[u8], start: usize, key: &[u8], off: usize, shift: u8) {
    if let Some(value) = json_number_from(input, start, key) {
        write_bk_note_score(off, shift, clamp(value, 0, 100) as u8);
    }
}

fn apply_bitmask_fields(input: &[u8], start: usize, base: usize, fields: &[BitmaskField], usa: bool) {
    for field in fields {
        if find_key_from(input, start, field.key).is_none() {
            continue;
        }
        for flag in field.flags {
            let selected = json_array_has_string_from(input, start, field.key, flag.id);
            let (off, bit_idx) = physical_flag_location(flag, base, usa);
            if off >= EEPROM_WINDOW {
                continue;
            }
            let current = payload_ref()[off];
            let mask = 1u8 << bit_idx;
            write_u8(off, if selected { current | mask } else { current & !mask });
        }
    }
}

fn clamp(value: i32, min: i32, max: i32) -> i32 {
    if value < min { min } else if value > max { max } else { value }
}

fn bk_checksum_32(payload: &[u8], start: usize, end: usize) -> u32 {
    let mut shift: u32 = 0;
    let mut seed: u64 = 0x8f80_9f47_3108_b3c1;
    let mut crc1: u32 = 0;
    let mut crc2: u32 = 0;
    let mut p = start;
    while p < end {
        seed = seed.wrapping_add((payload[p] as u64) << (shift & 15));
        let out = bk_transform_seed(&mut seed);
        crc1 ^= out;
        shift = shift.wrapping_add(7);
        p += 1;
    }
    p = end;
    while p > start {
        p -= 1;
        seed = seed.wrapping_add((payload[p] as u64) << (shift & 15));
        let out = bk_transform_seed(&mut seed);
        crc2 ^= out;
        shift = shift.wrapping_add(3);
    }
    crc1 ^ crc2
}

fn bk_transform_seed(seed: &mut u64) -> u32 {
    *seed = ((*seed << 63) >> 31 | (*seed << 31) >> 32) ^ (*seed << 44) >> 32;
    *seed = ((*seed >> 20) & 0xfff) ^ *seed;
    *seed as u32
}

fn rare_checksum_64(payload: &[u8], start: usize, end: usize) -> u64 {
    let mut checksum1: u64 = 0;
    let mut polynormal: u64 = 0x1_3108_b3c1;
    let mut shift: u32 = 0;
    let mut p = start;
    while p < end {
        polynormal = rare_hash(payload[p], polynormal, shift);
        checksum1 ^= polynormal;
        shift = shift.wrapping_add(7);
        p += 1;
    }
    let mut checksum2 = checksum1;
    p = end;
    while p > start {
        p -= 1;
        polynormal = rare_hash(payload[p], polynormal, shift);
        checksum2 ^= polynormal;
        shift = shift.wrapping_add(3);
    }
    ((checksum1 & 0xffff_ffff) << 32) | ((checksum1 ^ checksum2) & 0xffff_ffff)
}

fn rare_hash(value: u8, polynormal: u64, shift: u32) -> u64 {
    let hash1 = polynormal.wrapping_add((value as u64) << (shift & 0xf)) & 0x1_ffff_ffff;
    let hash2 = ((hash1 << 63) >> 31 | (hash1 >> 1)) ^ ((hash1 << 44) >> 32);
    ((hash2 >> 20) & 0xfff) ^ hash2
}

fn payload_ref() -> &'static [u8] {
    unsafe { slice::from_raw_parts(ptr::addr_of!(PAYLOAD) as *const u8, EEPROM_WINDOW) }
}

fn payload_ref_range(len: usize) -> &'static [u8] {
    unsafe { slice::from_raw_parts(ptr::addr_of!(PAYLOAD) as *const u8, len) }
}

fn write_u8(off: usize, value: u8) {
    unsafe {
        PAYLOAD[off] = value;
    }
}

fn write_be_u16(off: usize, value: u16) {
    write_u8(off, (value >> 8) as u8);
    write_u8(off + 1, value as u8);
}

fn write_be_i16(off: usize, value: i16) {
    write_be_u16(off, value as u16);
}

fn write_be_u32(off: usize, value: u32) {
    write_u8(off, (value >> 24) as u8);
    write_u8(off + 1, (value >> 16) as u8);
    write_u8(off + 2, (value >> 8) as u8);
    write_u8(off + 3, value as u8);
}

fn write_be_u64(off: usize, value: u64) {
    for idx in 0..8 {
        write_u8(off + idx, (value >> ((7 - idx) * 8)) as u8);
    }
}

fn read_be_u16(payload: &[u8], off: usize) -> u16 {
    ((payload[off] as u16) << 8) | payload[off + 1] as u16
}

fn read_be_i16(payload: &[u8], off: usize) -> i16 {
    read_be_u16(payload, off) as i16
}

fn read_be_u32(payload: &[u8], off: usize) -> u32 {
    ((payload[off] as u32) << 24)
        | ((payload[off + 1] as u32) << 16)
        | ((payload[off + 2] as u32) << 8)
        | payload[off + 3] as u32
}

fn read_be_u64(payload: &[u8], off: usize) -> u64 {
    let mut value = 0u64;
    for idx in 0..8 {
        value = (value << 8) | payload[off + idx] as u64;
    }
    value
}

fn bit(value: u8, bit_idx: u8) -> bool {
    value & (1 << bit_idx) != 0
}

fn read_bitfield(payload: &[u8], off: usize, bit_start: u8, bit_len: u8) -> u16 {
    let mut value = 0u16;
    let mut i = 0u8;
    while i < bit_len {
        let absolute = bit_start + i;
        if bit(payload[off + (absolute / 8) as usize], absolute % 8) {
            value |= 1u16 << i;
        }
        i += 1;
    }
    value
}

fn write_bitfield(off: usize, bit_start: u8, bit_len: u8, value: u16) {
    let mut i = 0u8;
    while i < bit_len {
        let absolute = bit_start + i;
        let byte_off = off + (absolute / 8) as usize;
        let bit_idx = absolute % 8;
        let current = payload_ref()[byte_off];
        let mask = 1u8 << bit_idx;
        let enabled = value & (1u16 << i) != 0;
        write_u8(byte_off, if enabled { current | mask } else { current & !mask });
        i += 1;
    }
}

fn bk_note_score(payload: &[u8], off: usize, shift: u8) -> u8 {
    ((read_be_u64(payload, off + 0x22) >> shift) & 0x7f) as u8
}

fn write_bk_note_score(off: usize, shift: u8, value: u8) {
    let current = read_be_u64(payload_ref(), off + 0x22);
    let mask = 0x7fu64 << shift;
    write_be_u64(off + 0x22, (current & !mask) | (((value as u64) & 0x7f) << shift));
}

fn kazooie_total_playtime(payload: &[u8], off: usize) -> usize {
    let mut total = 0usize;
    for idx in 0..11 {
        total += read_be_u16(payload, off + 0x2a + idx * 2) as usize;
    }
    total
}

fn kazooie_total_notes(payload: &[u8], off: usize) -> usize {
    let shifts = [56u8, 49, 42, 35, 28, 21, 0, 7, 14];
    let mut total = 0usize;
    for shift in shifts {
        total += bk_note_score(payload, off, shift) as usize;
    }
    total
}

fn tooie_total_playtime(payload: &[u8], off: usize) -> usize {
    let mut total = 0usize;
    for idx in 0..14 {
        total += read_be_u16(payload, off + 0x0d + idx * 2) as usize;
    }
    total
}

fn tooie_total_jiggies(payload: &[u8], off: usize, usa: bool) -> usize {
    let mut total = 0usize;
    let mut logical_off = 0xc8u16;
    let mut bit_idx = 2u8;
    for _ in 0..0x5a {
        let (physical_off, physical_bit) = bt_slot_physical_location(logical_off, bit_idx, usa);
        if bit(payload[off + physical_off], physical_bit) {
            total += 1;
        }
        bit_idx += 1;
        if bit_idx == 8 {
            logical_off += 1;
            bit_idx = 0;
        }
    }
    total
}

fn tooie_total_notes(payload: &[u8], off: usize, usa: bool) -> usize {
    let mut total = 0usize;
    let mut logical_off = 0x108u16;
    let mut bit_idx = 1u8;
    let mut iteration = 1usize;
    for _ in 0..0x99 {
        let (physical_off, physical_bit) = bt_slot_physical_location(logical_off, bit_idx, usa);
        if bit(payload[off + physical_off], physical_bit) {
            total += if iteration % 17 == 0 { 20 } else { 5 };
        }
        bit_idx += 1;
        if bit_idx == 8 {
            logical_off += 1;
            bit_idx = 0;
        }
        iteration += 1;
    }
    total
}

fn bit_count_range(payload: &[u8], off: usize, len: usize) -> usize {
    let mut total = 0usize;
    for idx in 0..len {
        let mut value = payload[off + idx];
        while value != 0 {
            total += (value & 1) as usize;
            value >>= 1;
        }
    }
    total
}

fn physical_flag_location(flag: &FlagSpec, base: usize, usa: bool) -> (usize, u8) {
    if flag.extra {
        return (base + bt_extra_physical_offset(flag.offset, usa), flag.bit);
    }
    if flag.usa_shift {
        let (off, bit_idx) = bt_slot_physical_location(flag.offset, flag.bit, usa);
        return (base + off, bit_idx);
    }
    (base + flag.offset as usize, flag.bit)
}

fn bt_slot_physical_location(offset: u16, bit_idx: u8, usa: bool) -> (usize, u8) {
    if !usa || offset < 0xa6 {
        return (offset as usize, bit_idx);
    }
    let mut int = offset as u32 * 8 + bit_idx as u32 + 0x1e;
    if int >= 0x972 && int <= 0x97b {
        int += 0x2;
    }
    ((int / 8) as usize, (int % 8) as u8)
}

fn bt_extra_physical_offset(offset: u16, usa: bool) -> usize {
    if usa && offset >= 0x0f && offset < 0x3b {
        (offset - 0x02) as usize
    } else {
        offset as usize
    }
}

fn bt_region_is_usa(input: &[u8]) -> bool {
    json_any_string_eq(input, b"regionCode", b"US")
        || json_any_string_eq(input, b"regionCode", b"USA")
        || json_any_string_eq(input, b"regionFlag", b"us")
        || json_any_string_eq(input, b"regionFlag", b"usa")
}

fn json_string_field(input: &[u8], key: &[u8]) -> Option<(usize, usize)> {
    let mut i = 0usize;
    while i + key.len() + 2 < input.len() {
        if input[i] == b'"' && input.get(i + 1..i + 1 + key.len()) == Some(key) && input[i + 1 + key.len()] == b'"' {
            let mut j = i + key.len() + 2;
            while j < input.len() && is_ws(input[j]) {
                j += 1;
            }
            if j >= input.len() || input[j] != b':' {
                i += 1;
                continue;
            }
            j += 1;
            while j < input.len() && is_ws(input[j]) {
                j += 1;
            }
            if j >= input.len() || input[j] != b'"' {
                return None;
            }
            let start = j + 1;
            let mut end = start;
            while end < input.len() {
                if input[end] == b'"' && input[end - 1] != b'\\' {
                    return Some((start, end - start));
                }
                end += 1;
            }
            return None;
        }
        i += 1;
    }
    None
}

fn json_any_string_eq(input: &[u8], key: &[u8], expected: &[u8]) -> bool {
    let mut search = 0usize;
    while search < input.len() {
        let Some((value_start, value_len, next)) = json_string_field_from(input, key, search) else {
            return false;
        };
        if ascii_eq_ignore_case(&input[value_start..value_start + value_len], expected) {
            return true;
        }
        search = next;
    }
    false
}

fn json_string_field_from(input: &[u8], key: &[u8], start_at: usize) -> Option<(usize, usize, usize)> {
    let mut i = start_at;
    while i + key.len() + 2 < input.len() {
        if input[i] == b'"' && input.get(i + 1..i + 1 + key.len()) == Some(key) && input[i + 1 + key.len()] == b'"' {
            let mut j = i + key.len() + 2;
            while j < input.len() && is_ws(input[j]) {
                j += 1;
            }
            if j >= input.len() || input[j] != b':' {
                i += 1;
                continue;
            }
            j += 1;
            while j < input.len() && is_ws(input[j]) {
                j += 1;
            }
            if j >= input.len() || input[j] != b'"' {
                i += 1;
                continue;
            }
            let value_start = j + 1;
            let mut end = value_start;
            while end < input.len() {
                if input[end] == b'"' && input[end - 1] != b'\\' {
                    return Some((value_start, end - value_start, end + 1));
                }
                end += 1;
            }
            return None;
        }
        i += 1;
    }
    None
}

fn json_array_has_string_from(input: &[u8], start: usize, key: &[u8], expected: &[u8]) -> bool {
    let mut i = match find_key_from(input, start, key) {
        Some(value) => value,
        None => return false,
    };
    while i < input.len() && is_ws(input[i]) {
        i += 1;
    }
    if i >= input.len() || input[i] != b'[' {
        return false;
    }
    i += 1;
    while i < input.len() {
        while i < input.len() && is_ws(input[i]) {
            i += 1;
        }
        if i >= input.len() || input[i] == b']' {
            return false;
        }
        if input[i] != b'"' {
            i += 1;
            continue;
        }
        let value_start = i + 1;
        let mut end = value_start;
        while end < input.len() {
            if input[end] == b'"' && input[end - 1] != b'\\' {
                if input.get(value_start..end) == Some(expected) {
                    return true;
                }
                i = end + 1;
                break;
            }
            end += 1;
        }
    }
    false
}

fn updates_start(input: &[u8]) -> Option<usize> {
    let key = b"updates";
    let mut i = 0usize;
    while i + key.len() + 2 < input.len() {
        if input[i] == b'"' && input.get(i + 1..i + 1 + key.len()) == Some(key) && input[i + 1 + key.len()] == b'"' {
            while i < input.len() && input[i] != b'{' {
                i += 1;
            }
            return Some(i);
        }
        i += 1;
    }
    None
}

fn json_number_from(input: &[u8], start: usize, key: &[u8]) -> Option<i32> {
    let mut i = find_key_from(input, start, key)?;
    while i < input.len() && is_ws(input[i]) {
        i += 1;
    }
    let mut sign = 1i32;
    if i < input.len() && input[i] == b'-' {
        sign = -1;
        i += 1;
    }
    let mut value = 0i32;
    let mut found = false;
    while i < input.len() && input[i].is_ascii_digit() {
        value = value.saturating_mul(10).saturating_add((input[i] - b'0') as i32);
        i += 1;
        found = true;
    }
    if found { Some(value.saturating_mul(sign)) } else { None }
}

fn json_bool_from(input: &[u8], start: usize, key: &[u8]) -> Option<bool> {
    let mut i = find_key_from(input, start, key)?;
    while i < input.len() && is_ws(input[i]) {
        i += 1;
    }
    if input.get(i..i + 4) == Some(b"true") {
        Some(true)
    } else if input.get(i..i + 5) == Some(b"false") {
        Some(false)
    } else {
        None
    }
}

fn find_key_from(input: &[u8], start: usize, key: &[u8]) -> Option<usize> {
    let mut i = start;
    while i + key.len() + 2 < input.len() {
        if input[i] == b'"' && input.get(i + 1..i + 1 + key.len()) == Some(key) && input[i + 1 + key.len()] == b'"' {
            let mut j = i + key.len() + 2;
            while j < input.len() && is_ws(input[j]) {
                j += 1;
            }
            if j < input.len() && input[j] == b':' {
                return Some(j + 1);
            }
        }
        i += 1;
    }
    None
}

fn ascii_eq_ignore_case(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    for idx in 0..a.len() {
        if ascii_lower(a[idx]) != ascii_lower(b[idx]) {
            return false;
        }
    }
    true
}

fn ascii_lower(value: u8) -> u8 {
    if value >= b'A' && value <= b'Z' { value + 32 } else { value }
}

fn is_ws(value: u8) -> bool {
    value == b' ' || value == b'\n' || value == b'\r' || value == b'\t'
}

fn decoded_base64_len(input: &[u8]) -> Option<usize> {
    let mut chars = 0usize;
    let mut padding = 0usize;
    for b in input {
        if is_ws(*b) {
            continue;
        }
        if *b == b'=' {
            padding += 1;
            chars += 1;
        } else if base64_value(*b).is_some() {
            chars += 1;
        } else {
            return None;
        }
    }
    if chars == 0 || chars % 4 != 0 || padding > 2 {
        return None;
    }
    Some((chars / 4) * 3 - padding)
}

fn decode_base64_prefix(input: &[u8], wanted: usize) -> Option<usize> {
    unsafe {
        for idx in 0..wanted {
            PAYLOAD[idx] = 0;
        }
    }
    let mut quartet = [0u8; 4];
    let mut q = 0usize;
    let mut out = 0usize;
    for b in input {
        if is_ws(*b) {
            continue;
        }
        quartet[q] = *b;
        q += 1;
        if q == 4 {
            let a = base64_value(quartet[0])?;
            let b1 = base64_value(quartet[1])?;
            let c = if quartet[2] == b'=' { 64 } else { base64_value(quartet[2])? };
            let d = if quartet[3] == b'=' { 64 } else { base64_value(quartet[3])? };
            let bytes = [
                (a << 2) | (b1 >> 4),
                ((b1 & 0xf) << 4) | if c == 64 { 0 } else { c >> 2 },
                if c == 64 || d == 64 { 0 } else { ((c & 0x3) << 6) | d },
            ];
            let count = if quartet[2] == b'=' { 1 } else if quartet[3] == b'=' { 2 } else { 3 };
            for value in bytes.iter().take(count) {
                if out < wanted {
                    unsafe {
                        PAYLOAD[out] = *value;
                    }
                }
                out += 1;
            }
            q = 0;
        }
    }
    if q == 0 && out >= wanted { Some(out) } else { None }
}

fn base64_value(b: u8) -> Option<u8> {
    match b {
        b'A'..=b'Z' => Some(b - b'A'),
        b'a'..=b'z' => Some(b - b'a' + 26),
        b'0'..=b'9' => Some(b - b'0' + 52),
        b'+' => Some(62),
        b'/' => Some(63),
        _ => None,
    }
}

fn write_base64(w: &mut Writer, bytes: &[u8]) {
    let alphabet = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut i = 0usize;
    while i < bytes.len() {
        let b0 = bytes[i];
        let b1 = if i + 1 < bytes.len() { bytes[i + 1] } else { 0 };
        let b2 = if i + 2 < bytes.len() { bytes[i + 2] } else { 0 };
        w.byte(alphabet[(b0 >> 2) as usize]);
        w.byte(alphabet[(((b0 & 0x03) << 4) | (b1 >> 4)) as usize]);
        if i + 1 < bytes.len() {
            w.byte(alphabet[(((b1 & 0x0f) << 2) | (b2 >> 6)) as usize]);
        } else {
            w.byte(b'=');
        }
        if i + 2 < bytes.len() {
            w.byte(alphabet[(b2 & 0x3f) as usize]);
        } else {
            w.byte(b'=');
        }
        i += 3;
    }
}
