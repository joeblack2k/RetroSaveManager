# Banjo-Tooie Game Support Module

This module validates Banjo-Tooie Nintendo 64 EEPROM saves and exposes checksum-repaired inventory, playtime, collectible flag, move, progress, jukebox, replay, settings, and language fields.

Supported payloads:

- 2048-byte native 16Kbit EEPROM windows.
- 296960-byte RetroArch N64 SRM containers, read-only for semantic details and cheat reads.

Validation uses the Game Tools Collection Banjo-Tooie layout: four 0x1c0-byte slots at offsets `0x100`, `0x2c0`, `0x480`, and `0x640`; active slots start with `KHJC`, store the display slot id at `0x0a`, and store a big-endian 64-bit Rare checksum at `0x1b8` over bytes `0x00-0x1b7`. Replay/settings data uses the 0x80-byte extra block whose 64-bit checksum is stored at `0x78`.

Editable fields are limited to offsets and labels from the Game Tools Collection template: counters, per-level playtime seconds, individual Jiggy/Note/Jinjo/Cheato Page/Extra Honeycomb/Glowbo flags, special moves, named progress flags, warp pads, silos, cheat/jukebox flags, replay unlocks/high scores, wide-screen mode, speaker mode, and the Europe language bits. For slot fields at/after logical offset `0xa6`, USA saves use the same region-shift transform as Game Tools Collection `utils.ts`; non-USA saves use the unshifted logical offsets. RetroArch SRM containers are parsed/read-only.
