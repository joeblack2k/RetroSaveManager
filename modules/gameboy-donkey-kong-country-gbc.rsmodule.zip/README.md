# Donkey Kong Country Game Boy Color Module

This module provides structural, read-only support for the Game Boy Color Donkey Kong Country SRAM.

The parser accepts non-blank 8 KiB raw SRAM, matching documented cartridge SRAM size. It does not expose SNES Donkey Kong Country fields and does not reuse the SNES editor because the Game Boy Color save layout is a different format.

The only cheat-pack field is an inert `Keep Current Save` value. Applying it returns the original payload unchanged.

Research sources:

- Data Crystal Donkey Kong Country (Game Boy Color) cartridge notes for 8 KiB SRAM.
- Game Boy hardware database cartridge record for CGB-BDDE-0, confirming battery-backed 32Kbit SRAM hardware.

Known limitation:

- No verified GBC semantic save map or raw SRAM sample with field proof was found during this intake.
