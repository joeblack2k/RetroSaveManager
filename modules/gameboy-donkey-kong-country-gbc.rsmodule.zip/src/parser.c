#include <stdbool.h>
#include <stdint.h>

extern unsigned char __heap_base;

static uint32_t heap_ptr = 0;

static void *rsm_bump_alloc(uint32_t len) {
    if (heap_ptr == 0) {
        heap_ptr = (uint32_t)(uintptr_t)&__heap_base;
    }
    heap_ptr = (heap_ptr + 7u) & ~7u;
    void *ptr = (void *)(uintptr_t)heap_ptr;
    heap_ptr += (len + 7u) & ~7u;
    return ptr;
}

__attribute__((export_name("rsm_alloc")))
int32_t rsm_alloc(int32_t len) {
    if (len <= 0) {
        return 0;
    }
    return (int32_t)(uintptr_t)rsm_bump_alloc((uint32_t)len);
}

typedef struct {
    char *data;
    uint32_t len;
    uint32_t cap;
} builder;

static uint32_t c_len(const char *s) {
    uint32_t n = 0;
    while (s[n] != 0) n++;
    return n;
}

static void b_init(builder *b, uint32_t cap) {
    b->data = (char *)rsm_bump_alloc(cap);
    b->len = 0;
    b->cap = cap;
}

static void b_char(builder *b, char c) {
    if (b->len < b->cap) b->data[b->len++] = c;
}

static void b_strn(builder *b, const char *s, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) b_char(b, s[i]);
}

static void b_str(builder *b, const char *s) {
    b_strn(b, s, c_len(s));
}

static void b_u64(builder *b, uint64_t value) {
    char tmp[24];
    uint32_t n = 0;
    if (value == 0) {
        b_char(b, '0');
        return;
    }
    while (value > 0 && n < sizeof(tmp)) {
        tmp[n++] = (char)('0' + (value % 10u));
        value /= 10u;
    }
    while (n > 0) b_char(b, tmp[--n]);
}

static uint64_t finish(builder *b) {
    return ((uint64_t)(uint32_t)(uintptr_t)b->data << 32) | (uint64_t)b->len;
}

typedef struct {
    const uint8_t *ptr;
    uint32_t len;
} slice;

static bool bytes_eq(const uint8_t *a, const char *b, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) {
        if (a[i] != (uint8_t)b[i]) return false;
    }
    return true;
}

static uint8_t ascii_lower(uint8_t c) {
    if (c >= 'A' && c <= 'Z') return (uint8_t)(c + 32);
    return c;
}

static bool slice_contains_ci(slice haystack, const char *needle) {
    uint32_t needle_len = c_len(needle);
    if (needle_len == 0 || haystack.len < needle_len) return false;
    for (uint32_t i = 0; i <= haystack.len - needle_len; i++) {
        bool ok = true;
        for (uint32_t j = 0; j < needle_len; j++) {
            if (ascii_lower(haystack.ptr[i + j]) != ascii_lower((uint8_t)needle[j])) {
                ok = false;
                break;
            }
        }
        if (ok) return true;
    }
    return false;
}

static int32_t find_bytes(const uint8_t *input, uint32_t len, const char *needle, uint32_t needle_len) {
    if (needle_len == 0 || len < needle_len) return -1;
    for (uint32_t i = 0; i <= len - needle_len; i++) {
        bool ok = true;
        for (uint32_t j = 0; j < needle_len; j++) {
            if (input[i + j] != (uint8_t)needle[j]) {
                ok = false;
                break;
            }
        }
        if (ok) return (int32_t)i;
    }
    return -1;
}

static bool input_has(const uint8_t *input, uint32_t len, const char *needle) {
    return find_bytes(input, len, needle, c_len(needle)) >= 0;
}

static uint32_t skip_ws(const uint8_t *input, uint32_t len, uint32_t idx) {
    while (idx < len) {
        uint8_t c = input[idx];
        if (c != ' ' && c != '\n' && c != '\r' && c != '\t') break;
        idx++;
    }
    return idx;
}

static bool json_field_key(const uint8_t *input, uint32_t len, const char *field, uint32_t *after_key) {
    char key[96];
    uint32_t field_len = c_len(field);
    if (field_len + 2 >= sizeof(key)) return false;
    key[0] = '"';
    for (uint32_t i = 0; i < field_len; i++) key[i + 1] = field[i];
    key[field_len + 1] = '"';
    key[field_len + 2] = 0;
    int32_t found = find_bytes(input, len, key, field_len + 2);
    if (found < 0) return false;
    uint32_t idx = skip_ws(input, len, (uint32_t)found + field_len + 2);
    if (idx >= len || input[idx] != ':') return false;
    *after_key = skip_ws(input, len, idx + 1);
    return true;
}

static bool json_string_raw(const uint8_t *input, uint32_t len, const char *field, slice *out) {
    uint32_t idx = 0;
    if (!json_field_key(input, len, field, &idx) || idx >= len || input[idx] != '"') return false;
    uint32_t start = idx + 1;
    idx = start;
    while (idx < len) {
        if (input[idx] == '\\') {
            idx += 2;
            continue;
        }
        if (input[idx] == '"') {
            out->ptr = input + start;
            out->len = idx - start;
            return true;
        }
        idx++;
    }
    return false;
}

static bool json_object_raw(const uint8_t *input, uint32_t len, const char *field, slice *out) {
    uint32_t idx = 0;
    if (!json_field_key(input, len, field, &idx) || idx >= len || input[idx] != '{') return false;
    uint32_t start = idx;
    int32_t depth = 0;
    bool in_string = false;
    while (idx < len) {
        uint8_t c = input[idx];
        if (in_string) {
            if (c == '\\') {
                idx += 2;
                continue;
            }
            if (c == '"') in_string = false;
            idx++;
            continue;
        }
        if (c == '"') {
            in_string = true;
        } else if (c == '{') {
            depth++;
        } else if (c == '}') {
            depth--;
            if (depth == 0) {
                out->ptr = input + start;
                out->len = idx - start + 1;
                return true;
            }
        }
        idx++;
    }
    return false;
}

static bool json_array_raw(const uint8_t *input, uint32_t len, const char *field, slice *out) {
    uint32_t idx = 0;
    if (!json_field_key(input, len, field, &idx) || idx >= len || input[idx] != '[') return false;
    uint32_t start = idx;
    int32_t depth = 0;
    bool in_string = false;
    while (idx < len) {
        uint8_t c = input[idx];
        if (in_string) {
            if (c == '\\') {
                idx += 2;
                continue;
            }
            if (c == '"') in_string = false;
            idx++;
            continue;
        }
        if (c == '"') {
            in_string = true;
        } else if (c == '[') {
            depth++;
        } else if (c == ']') {
            depth--;
            if (depth == 0) {
                out->ptr = input + start;
                out->len = idx - start + 1;
                return true;
            }
        }
        idx++;
    }
    return false;
}

static bool json_int_value(const uint8_t *input, uint32_t len, const char *field, int32_t *out) {
    uint32_t idx = 0;
    if (!json_field_key(input, len, field, &idx)) return false;
    bool neg = false;
    if (idx < len && input[idx] == '-') {
        neg = true;
        idx++;
    }
    if (idx >= len || input[idx] < '0' || input[idx] > '9') return false;
    int32_t value = 0;
    while (idx < len && input[idx] >= '0' && input[idx] <= '9') {
        value = value * 10 + (int32_t)(input[idx] - '0');
        idx++;
    }
    *out = neg ? -value : value;
    return true;
}

static bool array_contains_string(slice arr, const char *value) {
    uint32_t value_len = c_len(value);
    uint32_t idx = 0;
    while (idx < arr.len) {
        if (arr.ptr[idx] != '"') {
            idx++;
            continue;
        }
        uint32_t start = idx + 1;
        idx = start;
        while (idx < arr.len) {
            if (arr.ptr[idx] == '\\') {
                idx += 2;
                continue;
            }
            if (arr.ptr[idx] == '"') {
                uint32_t n = idx - start;
                if (n == value_len) {
                    bool ok = true;
                    for (uint32_t j = 0; j < n; j++) {
                        if (arr.ptr[start + j] != (uint8_t)value[j]) {
                            ok = false;
                            break;
                        }
                    }
                    if (ok) return true;
                }
                break;
            }
            idx++;
        }
        idx++;
    }
    return false;
}

static int b64_value(uint8_t c) {
    if (c >= 'A' && c <= 'Z') return (int)(c - 'A');
    if (c >= 'a' && c <= 'z') return (int)(c - 'a' + 26);
    if (c >= '0' && c <= '9') return (int)(c - '0' + 52);
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

static bool base64_decode(slice encoded, uint8_t **out, uint32_t *out_len) {
    uint32_t cap = (encoded.len / 4u) * 3u + 3u;
    uint8_t *dst = (uint8_t *)rsm_bump_alloc(cap);
    uint32_t n = 0;
    for (uint32_t i = 0; i < encoded.len;) {
        int vals[4] = {0, 0, 0, 0};
        int pad = 0;
        for (uint32_t j = 0; j < 4; j++) {
            if (i >= encoded.len) return false;
            uint8_t c = encoded.ptr[i++];
            if (c == '=') {
                vals[j] = 0;
                pad++;
            } else {
                vals[j] = b64_value(c);
                if (vals[j] < 0) return false;
            }
        }
        uint32_t triple = ((uint32_t)vals[0] << 18) | ((uint32_t)vals[1] << 12) | ((uint32_t)vals[2] << 6) | (uint32_t)vals[3];
        if (n < cap) dst[n++] = (uint8_t)((triple >> 16) & 0xff);
        if (pad < 2 && n < cap) dst[n++] = (uint8_t)((triple >> 8) & 0xff);
        if (pad < 1 && n < cap) dst[n++] = (uint8_t)(triple & 0xff);
    }
    *out = dst;
    *out_len = n;
    return true;
}

static const char b64_table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static void b_base64(builder *b, const uint8_t *src, uint32_t len) {
    uint32_t i = 0;
    while (i < len) {
        uint32_t a = src[i++];
        uint32_t have_b = i < len;
        uint32_t bb = have_b ? src[i++] : 0;
        uint32_t have_c = i < len;
        uint32_t c = have_c ? src[i++] : 0;
        uint32_t triple = (a << 16) | (bb << 8) | c;
        b_char(b, b64_table[(triple >> 18) & 0x3f]);
        b_char(b, b64_table[(triple >> 12) & 0x3f]);
        b_char(b, have_b ? b64_table[(triple >> 6) & 0x3f] : '=');
        b_char(b, have_c ? b64_table[triple & 0x3f] : '=');
    }
}

static uint16_t read_be16(const uint8_t *p) {
    return ((uint16_t)p[0] << 8) | (uint16_t)p[1];
}

static uint32_t read_be32(const uint8_t *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}

static void write_be16(uint8_t *p, uint16_t value) {
    p[0] = (uint8_t)((value >> 8) & 0xff);
    p[1] = (uint8_t)(value & 0xff);
}

static bool all_same(const uint8_t *payload, uint32_t len, uint8_t value) {
    for (uint32_t i = 0; i < len; i++) {
        if (payload[i] != value) return false;
    }
    return true;
}

static bool bcd_valid(const uint8_t *payload, uint32_t offset, uint32_t bytes) {
    for (uint32_t i = 0; i < bytes; i++) {
        uint8_t v = payload[offset + i];
        if (((v >> 4) & 0xf) > 9 || (v & 0xf) > 9) return false;
    }
    return true;
}

static uint32_t bcd_read_be(const uint8_t *payload, uint32_t offset, uint32_t bytes) {
    uint32_t value = 0;
    for (uint32_t i = 0; i < bytes; i++) {
        uint8_t v = payload[offset + i];
        value = value * 100u + (uint32_t)(((v >> 4) & 0xf) * 10u + (v & 0xf));
    }
    return value;
}

static void bcd_write_be(uint8_t *payload, uint32_t offset, uint32_t bytes, uint32_t value) {
    for (uint32_t i = 0; i < bytes; i++) {
        uint32_t pos = bytes - 1u - i;
        uint32_t lo = value % 10u;
        value /= 10u;
        uint32_t hi = value % 10u;
        value /= 10u;
        payload[offset + pos] = (uint8_t)((hi << 4) | lo);
    }
}

static bool pokemon_checksum_ok(const uint8_t *payload, uint32_t len) {
    if (len != 32768u) return false;
    uint32_t sum = 0;
    for (uint32_t i = 0x2598u; i < 0x3523u; i++) sum += payload[i];
    uint8_t checksum = (uint8_t)((0xffu - (sum & 0xffu)) & 0xffu);
    return checksum == payload[0x3523u];
}

static uint8_t pokemon_checksum(const uint8_t *payload) {
    uint32_t sum = 0;
    for (uint32_t i = 0x2598u; i < 0x3523u; i++) sum += payload[i];
    return (uint8_t)((0xffu - (sum & 0xffu)) & 0xffu);
}

static bool pokemon_name_plausible(const uint8_t *payload) {
    for (uint32_t i = 0x2598u; i < 0x2598u + 11u; i++) {
        if (payload[i] == 0x50u) return true;
    }
    return false;
}

static bool pokemon_supported(const uint8_t *payload, uint32_t len) {
    return pokemon_checksum_ok(payload, len) &&
        pokemon_name_plausible(payload) &&
        bcd_valid(payload, 0x25f3u, 3u) &&
        bcd_valid(payload, 0x2850u, 2u) &&
        payload[0x2f2cu] <= 6u;
}

static uint32_t bit_count8(uint8_t value) {
    uint32_t count = 0;
    for (uint32_t i = 0; i < 8; i++) {
        if ((value & (1u << i)) != 0) count++;
    }
    return count;
}

static const char *badge_ids[8] = {
    "boulderBadge", "cascadeBadge", "thunderBadge", "rainbowBadge",
    "soulBadge", "marshBadge", "volcanoBadge", "earthBadge",
};

static void b_badges_array(builder *b, uint8_t mask) {
    b_char(b, '[');
    bool first = true;
    for (uint32_t i = 0; i < 8; i++) {
        if ((mask & (1u << i)) == 0) continue;
        if (!first) b_char(b, ',');
        b_char(b, '"');
        b_str(b, badge_ids[i]);
        b_char(b, '"');
        first = false;
    }
    b_char(b, ']');
}

static uint8_t parse_badges_update(slice updates, uint8_t current) {
    slice arr;
    if (!json_array_raw(updates.ptr, updates.len, "badges", &arr)) return current;
    uint8_t mask = 0;
    for (uint32_t i = 0; i < 8; i++) {
        if (array_contains_string(arr, badge_ids[i])) mask |= (uint8_t)(1u << i);
    }
    return mask;
}

static bool wario2_version_ok(const uint8_t *p) {
    return bytes_eq(p, "\x05\x07\x05\x12", 4) ||
        bytes_eq(p, "\x19\x64\x05\x07", 4) ||
        bytes_eq(p, "\x1a\x65\x06\x08", 4);
}

static uint32_t wario2_section_end(uint32_t section) {
    return (section == 0u || section == 3u) ? 0x437u : 0x55du;
}

static uint32_t wario2_checksum_offset(uint32_t section) {
    static const uint8_t map[6] = {0, 2, 4, 1, 3, 5};
    return 0x1u + (uint32_t)map[section] * 2u;
}

static uint16_t wario2_calc_checksum(const uint8_t *payload, uint32_t section) {
    uint32_t shift = section * 0x200u;
    uint32_t sum = 0;
    for (uint32_t i = 0x404u + shift; i < wario2_section_end(section) + shift; i++) {
        sum += payload[i];
    }
    return (uint16_t)(sum & 0xffffu);
}

static bool wario2_section_checksum_ok(const uint8_t *payload, uint32_t section) {
    uint32_t off = wario2_checksum_offset(section);
    return read_be16(payload + off) == wario2_calc_checksum(payload, section);
}

static bool wario2_find_active(const uint8_t *payload, uint32_t len, uint32_t *section, uint32_t *save_count) {
    if (len != 32768u) return false;
    uint32_t best_count = 0;
    uint32_t best_section = 0;
    bool found = false;
    for (uint32_t i = 0; i < 6; i++) {
        uint32_t base = 0x400u + i * 0x200u;
        if (!wario2_version_ok(payload + base)) continue;
        uint32_t count = read_be32(payload + base + 4u);
        if (count == 0xffffffffu) continue;
        if (!wario2_section_checksum_ok(payload, i)) continue;
        if (!found || count > best_count) {
            found = true;
            best_count = count;
            best_section = i;
        }
    }
    if (!found) return false;
    *section = best_section;
    *save_count = best_count;
    return true;
}

static void wario2_write_checksum(uint8_t *payload, uint32_t section) {
    write_be16(payload + wario2_checksum_offset(section), wario2_calc_checksum(payload, section));
}

typedef enum {
    GAME_UNKNOWN = 0,
    GAME_POKEMON = 1,
    GAME_WARIO2 = 2,
    GAME_SMBDX = 3,
    GAME_DKC_GBC = 4,
} game_kind;

static game_kind detect_game(const uint8_t *input, uint32_t input_len) {
    if (input_has(input, input_len, "gameboy/pokemon-red-blue-yellow")) return GAME_POKEMON;
    if (input_has(input, input_len, "gameboy/wario-land-ii")) return GAME_WARIO2;
    if (input_has(input, input_len, "gameboy/super-mario-bros-deluxe")) return GAME_SMBDX;
    if (input_has(input, input_len, "gameboy/donkey-kong-country-gbc")) return GAME_DKC_GBC;

    slice title = {0};
    if (!json_string_raw(input, input_len, "displayTitle", &title)) {
        (void)json_string_raw(input, input_len, "filename", &title);
    }
    if (title.ptr != 0) {
        if (slice_contains_ci(title, "pokemon")) return GAME_POKEMON;
        if (slice_contains_ci(title, "wario land ii") || slice_contains_ci(title, "wario land 2")) return GAME_WARIO2;
        if (slice_contains_ci(title, "super mario bros") || slice_contains_ci(title, "mario bros deluxe")) return GAME_SMBDX;
        if (slice_contains_ci(title, "donkey kong country")) return GAME_DKC_GBC;
    }
    return GAME_UNKNOWN;
}

static bool decode_payload(const uint8_t *input, uint32_t input_len, uint8_t **payload, uint32_t *payload_len) {
    slice encoded;
    if (!json_string_raw(input, input_len, "payload", &encoded)) return false;
    return base64_decode(encoded, payload, payload_len);
}

static uint64_t parse_response(game_kind game, const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0;
    uint32_t len = 0;
    if (!decode_payload(input, input_len, &payload, &len)) {
        builder b;
        b_init(&b, 96);
        b_str(&b, "{\"supported\":false,\"warnings\":[\"payload missing\"]}");
        return finish(&b);
    }

    builder b;
    b_init(&b, 1024);
    if (game == GAME_POKEMON) {
        if (!pokemon_supported(payload, len)) {
            b_str(&b, "{\"supported\":false,\"warnings\":[\"Pokemon Gen 1 main checksum or structural sanity checks failed\"]}");
            return finish(&b);
        }
        uint32_t money = bcd_read_be(payload, 0x25f3u, 3u);
        uint32_t coins = bcd_read_be(payload, 0x2850u, 2u);
        uint32_t badges = bit_count8(payload[0x2602u]);
        b_str(&b, "{\"supported\":true,\"parserLevel\":\"semantic\",\"validatedSystem\":\"gameboy\",\"validatedGameId\":\"gameboy/pokemon-red-blue-yellow\",\"validatedGameTitle\":\"Pokemon Red/Blue/Yellow\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[\"32 KiB Gen 1 SRAM\",\"main checksum valid\",\"trainer name terminator present\",\"BCD money and casino coin fields valid\"],\"checksumValid\":true,\"slotCount\":1,\"activeSlotIndexes\":[0],\"semanticFields\":{\"region\":\"international\",\"money\":");
        b_u64(&b, money);
        b_str(&b, ",\"casinoCoins\":");
        b_u64(&b, coins);
        b_str(&b, ",\"badgeCount\":");
        b_u64(&b, badges);
        b_str(&b, "}}");
        return finish(&b);
    }

    if (game == GAME_WARIO2) {
        uint32_t section = 0;
        uint32_t save_count = 0;
        if (!wario2_find_active(payload, len, &section, &save_count)) {
            b_str(&b, "{\"supported\":false,\"warnings\":[\"Wario Land II active save section or checksum not valid\"]}");
            return finish(&b);
        }
        uint32_t base = 0x400u + section * 0x200u;
        b_str(&b, "{\"supported\":true,\"parserLevel\":\"semantic\",\"validatedSystem\":\"gameboy\",\"validatedGameId\":\"gameboy/wario-land-ii\",\"validatedGameTitle\":\"Wario Land II\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[\"32 KiB Wario Land II SRAM\",\"recognized save-section signature\",\"active section checksum valid\"],\"checksumValid\":true,\"slotCount\":1,\"activeSlotIndexes\":[0],\"semanticFields\":{\"activeSection\":");
        b_u64(&b, section);
        b_str(&b, ",\"saveCount\":");
        b_u64(&b, save_count);
        b_str(&b, ",\"stageCoins\":");
        b_u64(&b, bcd_read_be(payload, base + 0x12u, 2u));
        b_str(&b, ",\"totalCoins\":");
        b_u64(&b, bcd_read_be(payload, base + 0x0fu, 3u));
        b_str(&b, ",\"flagmanDDHighScore\":");
        b_u64(&b, bcd_read_be(payload, base + 0x35u, 2u));
        b_str(&b, "}}");
        return finish(&b);
    }

    if (game == GAME_SMBDX || game == GAME_DKC_GBC) {
        const char *game_id = game == GAME_SMBDX ? "gameboy/super-mario-bros-deluxe" : "gameboy/donkey-kong-country-gbc";
        const char *title = game == GAME_SMBDX ? "Super Mario Bros. Deluxe" : "Donkey Kong Country (Game Boy Color)";
        if (len != 8192u || all_same(payload, len, 0x00u) || all_same(payload, len, 0xffu)) {
            b_str(&b, "{\"supported\":false,\"warnings\":[\"expected non-blank 8 KiB Game Boy SRAM\"]}");
            return finish(&b);
        }
        b_str(&b, "{\"supported\":true,\"parserLevel\":\"structural\",\"validatedSystem\":\"gameboy\",\"validatedGameId\":\"");
        b_str(&b, game_id);
        b_str(&b, "\",\"validatedGameTitle\":\"");
        b_str(&b, title);
        b_str(&b, "\",\"trustLevel\":\"module-structural-verified\",\"evidence\":[\"8 KiB cartridge SRAM size documented\",\"payload is non-blank raw SRAM\"],\"warnings\":[\"No verified semantic save map is available; cheat pack is read-only.\"],\"slotCount\":1,\"activeSlotIndexes\":[0],\"semanticFields\":{\"readOnly\":true,\"sramSizeBytes\":8192,\"cheatEditing\":\"not available until a semantic save map is verified\"}}");
        return finish(&b);
    }

    b_str(&b, "{\"supported\":false,\"warnings\":[\"game not recognized by module\"]}");
    return finish(&b);
}

static uint64_t read_response(game_kind game, const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0;
    uint32_t len = 0;
    if (!decode_payload(input, input_len, &payload, &len)) {
        builder b;
        b_init(&b, 96);
        b_str(&b, "{\"supported\":false}");
        return finish(&b);
    }
    builder b;
    b_init(&b, 512);

    if (game == GAME_POKEMON && pokemon_supported(payload, len)) {
        b_str(&b, "{\"supported\":true,\"values\":{\"money\":");
        b_u64(&b, bcd_read_be(payload, 0x25f3u, 3u));
        b_str(&b, ",\"casinoCoins\":");
        b_u64(&b, bcd_read_be(payload, 0x2850u, 2u));
        b_str(&b, ",\"badges\":");
        b_badges_array(&b, payload[0x2602u]);
        b_str(&b, "}}");
        return finish(&b);
    }

    if (game == GAME_WARIO2) {
        uint32_t section = 0;
        uint32_t save_count = 0;
        if (wario2_find_active(payload, len, &section, &save_count)) {
            uint32_t base = 0x400u + section * 0x200u;
            b_str(&b, "{\"supported\":true,\"values\":{\"stageCoins\":");
            b_u64(&b, bcd_read_be(payload, base + 0x12u, 2u));
            b_str(&b, ",\"totalCoins\":");
            b_u64(&b, bcd_read_be(payload, base + 0x0fu, 3u));
            b_str(&b, ",\"flagmanDDHighScore\":");
            b_u64(&b, bcd_read_be(payload, base + 0x35u, 2u));
            b_str(&b, "}}");
            return finish(&b);
        }
    }

    if ((game == GAME_SMBDX || game == GAME_DKC_GBC) && len == 8192u && !all_same(payload, len, 0x00u) && !all_same(payload, len, 0xffu)) {
        b_str(&b, "{\"supported\":true,\"values\":{\"detailsOnly\":\"keep\"}}");
        return finish(&b);
    }

    b_str(&b, "{\"supported\":false}");
    return finish(&b);
}

static uint64_t apply_response(game_kind game, const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0;
    uint32_t len = 0;
    if (!decode_payload(input, input_len, &payload, &len)) {
        builder b;
        b_init(&b, 96);
        b_str(&b, "{\"payload\":\"\"}");
        return finish(&b);
    }
    uint8_t *updated = (uint8_t *)rsm_bump_alloc(len);
    for (uint32_t i = 0; i < len; i++) updated[i] = payload[i];

    slice updates = {0};
    (void)json_object_raw(input, input_len, "updates", &updates);

    builder b;
    b_init(&b, (len * 4u) / 3u + 1024u);
    if (game == GAME_POKEMON && pokemon_supported(payload, len)) {
        int32_t v = 0;
        bool changed_money = false;
        bool changed_coins = false;
        bool changed_badges = false;
        if (updates.ptr != 0 && json_int_value(updates.ptr, updates.len, "money", &v) && v >= 0 && v <= 999999) {
            bcd_write_be(updated, 0x25f3u, 3u, (uint32_t)v);
            changed_money = true;
        }
        if (updates.ptr != 0 && json_int_value(updates.ptr, updates.len, "casinoCoins", &v) && v >= 0 && v <= 9999) {
            bcd_write_be(updated, 0x2850u, 2u, (uint32_t)v);
            changed_coins = true;
        }
        if (updates.ptr != 0) {
            slice arr;
            if (json_array_raw(updates.ptr, updates.len, "badges", &arr)) {
                updated[0x2602u] = parse_badges_update(updates, updated[0x2602u]);
                changed_badges = true;
            }
        }
        updated[0x3523u] = pokemon_checksum(updated);
        b_str(&b, "{\"payload\":\"");
        b_base64(&b, updated, len);
        b_str(&b, "\",\"changed\":{");
        bool first = true;
        if (changed_money) {
            b_str(&b, "\"money\":");
            b_u64(&b, bcd_read_be(updated, 0x25f3u, 3u));
            first = false;
        }
        if (changed_coins) {
            if (!first) b_char(&b, ',');
            b_str(&b, "\"casinoCoins\":");
            b_u64(&b, bcd_read_be(updated, 0x2850u, 2u));
            first = false;
        }
        if (changed_badges) {
            if (!first) b_char(&b, ',');
            b_str(&b, "\"badges\":");
            b_badges_array(&b, updated[0x2602u]);
        }
        b_str(&b, "},\"integritySteps\":[\"Pokemon main checksum rebuilt\"]}");
        return finish(&b);
    }

    if (game == GAME_WARIO2) {
        uint32_t section = 0;
        uint32_t save_count = 0;
        if (wario2_find_active(payload, len, &section, &save_count)) {
            int32_t v = 0;
            bool patch_stage = updates.ptr != 0 && json_int_value(updates.ptr, updates.len, "stageCoins", &v) && v >= 0 && v <= 999;
            int32_t stage_value = v;
            bool patch_total = updates.ptr != 0 && json_int_value(updates.ptr, updates.len, "totalCoins", &v) && v >= 0 && v <= 99999;
            int32_t total_value = v;
            bool patch_score = updates.ptr != 0 && json_int_value(updates.ptr, updates.len, "flagmanDDHighScore", &v) && v >= 0 && v <= 9999;
            int32_t score_value = v;
            for (uint32_t s = 0; s < 6; s++) {
                uint32_t base = 0x400u + s * 0x200u;
                if (!wario2_version_ok(payload + base)) continue;
                if (read_be32(payload + base + 4u) != save_count) continue;
                if (!wario2_section_checksum_ok(payload, s)) continue;
                if (patch_stage) bcd_write_be(updated, base + 0x12u, 2u, (uint32_t)stage_value);
                if (patch_total) bcd_write_be(updated, base + 0x0fu, 3u, (uint32_t)total_value);
                if (patch_score) bcd_write_be(updated, base + 0x35u, 2u, (uint32_t)score_value);
                wario2_write_checksum(updated, s);
            }
            b_str(&b, "{\"payload\":\"");
            b_base64(&b, updated, len);
            b_str(&b, "\",\"changed\":{");
            bool first = true;
            if (patch_stage) {
                b_str(&b, "\"stageCoins\":");
                b_u64(&b, (uint32_t)stage_value);
                first = false;
            }
            if (patch_total) {
                if (!first) b_char(&b, ',');
                b_str(&b, "\"totalCoins\":");
                b_u64(&b, (uint32_t)total_value);
                first = false;
            }
            if (patch_score) {
                if (!first) b_char(&b, ',');
                b_str(&b, "\"flagmanDDHighScore\":");
                b_u64(&b, (uint32_t)score_value);
            }
            b_str(&b, "},\"integritySteps\":[\"Wario Land II active-section checksums rebuilt\",\"Mirrored sections with matching save count patched\"]}");
            return finish(&b);
        }
    }

    if (game == GAME_SMBDX || game == GAME_DKC_GBC) {
        b_str(&b, "{\"payload\":\"");
        b_base64(&b, updated, len);
        b_str(&b, "\",\"changed\":{\"detailsOnly\":\"keep\"},\"integritySteps\":[\"Read-only module left payload unchanged\"]}");
        return finish(&b);
    }

    b_str(&b, "{\"payload\":\"\"}");
    return finish(&b);
}

__attribute__((export_name("rsm_call")))
int64_t rsm_call(int32_t command_ptr, int32_t command_len, int32_t input_ptr, int32_t input_len) {
    const uint8_t *command = (const uint8_t *)(uintptr_t)command_ptr;
    const uint8_t *input = (const uint8_t *)(uintptr_t)input_ptr;
    if (command_len == 12 && bytes_eq(command, "capabilities", 12)) {
        builder b;
        b_init(&b, 128);
        b_str(&b, "{\"supported\":true,\"abiVersion\":\"rsm-wasm-json-v1\",\"operations\":[\"parse\",\"readCheats\",\"applyCheats\"]}");
        return (int64_t)finish(&b);
    }
    game_kind game = detect_game(input, (uint32_t)input_len);
    if (command_len == 5 && bytes_eq(command, "parse", 5)) {
        return (int64_t)parse_response(game, input, (uint32_t)input_len);
    }
    if (command_len == 10 && bytes_eq(command, "readCheats", 10)) {
        return (int64_t)read_response(game, input, (uint32_t)input_len);
    }
    if (command_len == 11 && bytes_eq(command, "applyCheats", 11)) {
        return (int64_t)apply_response(game, input, (uint32_t)input_len);
    }
    builder b;
    b_init(&b, 64);
    b_str(&b, "{\"supported\":false}");
    return (int64_t)finish(&b);
}
