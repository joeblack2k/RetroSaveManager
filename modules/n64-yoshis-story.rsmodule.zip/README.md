# Yoshi's Story (Nintendo 64)

This module adds parser-backed support for the real Yoshi's Story 16Kbit EEPROM container.
It validates the 2048-byte payload, the two 0x400-byte EEPROM copies, and the EepBuffer magic value `0x81317531` documented by the public decompilation.

The bundled cheat pack exposes one safe write: installing a verified 100% Project64 EEPROM sample from EmuNations. That sample is documented as 100% complete, with black and white Yoshis unlocked for Story Mode and all stages available in Trial Mode. The module replaces the full EEPROM payload with that verified sample so the mirrored copies and stored checksum bytes remain consistent.

Granular edits for individual progress bits, fruit/melon counters, scores/high scores, and options are intentionally not exposed yet. Public RAM cheat addresses prove some live-memory semantics, but the EEPROM save-data transform (`func_80065528`) and checksum routine (`func_800699BC`) are not fully decompiled in the reviewed source, so byte-level partial writes would be speculative.

Research sources:
- decompals/yoshis-story `include/eepmgr.h`: `EepBuffer` layout with `data[0x3FA]`, `unk3FA`, and magic.
- decompals/yoshis-story `src/main/O2/65520.c`: save writes clone the first `EepBuffer` to a second copy; loads accept copy 1 first, then copy 2, after checksum and magic validation.
- EmuNations Yoshi's Story N64 save samples: Project64 `.eep` and RetroArch `.srm`; the RetroArch sample begins with the same 2048-byte EEPROM payload.
- Almar's Guides/GameShark code list: supports the RAM-side interpretation that all Trial Mode levels are controlled in the loaded save/work area, but is not used as raw save-edit data.
