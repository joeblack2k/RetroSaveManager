#![no_std]

mod verified_100_percent;

use core::panic::PanicInfo;
use core::ptr;
use core::slice;

const EEPROM_SIZE: usize = 0x800;
const COPY_SIZE: usize = 0x400;
const DATA_SIZE: usize = 0x3FA;
const CHECKSUM_OFFSET: usize = 0x3FA;
const MAGIC_OFFSET: usize = 0x3FC;
const MAGIC: [u8; 4] = [0x81, 0x31, 0x75, 0x31];
const HEAP_SIZE: usize = 64 * 1024;
const OUTPUT_CAP: usize = 8192;

static mut HEAP: [u8; HEAP_SIZE] = [0; HEAP_SIZE];
static mut HEAP_OFFSET: usize = 8;
static mut PAYLOAD: [u8; EEPROM_SIZE] = [0; EEPROM_SIZE];

#[panic_handler]
fn panic(_: &PanicInfo) -> ! {
    loop {}
}


fn heap_base() -> usize {
    ptr::addr_of_mut!(HEAP) as *mut u8 as usize
}

#[no_mangle]
pub extern "C" fn rsm_alloc(len: i32) -> i32 {
    if len < 0 {
        return 0;
    }
    let len = len as usize;
    unsafe {
        let relative = (HEAP_OFFSET + 7) & !7;
        let Some(end) = relative.checked_add(len) else { return 0; };
        if end >= HEAP_SIZE {
            return 0;
        }
        HEAP_OFFSET = end;
        (heap_base() + relative) as i32
    }
}

#[no_mangle]
pub extern "C" fn rsm_call(command_ptr: i32, command_len: i32, input_ptr: i32, input_len: i32) -> u64 {
    let Some(command) = read_bytes(command_ptr, command_len) else {
        return write_unsupported(b"bad command pointer");
    };
    let input = read_bytes(input_ptr, input_len).unwrap_or(&[]);
    if command == b"capabilities" {
        write_capabilities()
    } else if command == b"parse" {
        write_parse(input)
    } else if command == b"readCheats" {
        write_read_cheats(input)
    } else if command == b"applyCheats" {
        write_apply_cheats(input)
    } else {
        write_unsupported(b"unsupported command")
    }
}

fn read_bytes(ptr: i32, len: i32) -> Option<&'static [u8]> {
    if ptr < 0 || len < 0 {
        return None;
    }
    let ptr = ptr as usize;
    let len = len as usize;
    let end = ptr.checked_add(len)?;
    let base = heap_base();
    if ptr < base || end > base + HEAP_SIZE {
        return None;
    }
    unsafe { Some(slice::from_raw_parts(ptr as *const u8, len)) }
}

struct Writer {
    ptr: usize,
    len: usize,
    cap: usize,
}

impl Writer {
    fn new() -> Option<Writer> {
        let ptr = rsm_alloc(OUTPUT_CAP as i32);
        if ptr <= 0 {
            return None;
        }
        Some(Writer { ptr: ptr as usize, len: 0, cap: OUTPUT_CAP })
    }

    fn finish(self) -> u64 {
        ((self.ptr as u64) << 32) | (self.len as u64)
    }

    fn byte(&mut self, value: u8) {
        if self.len >= self.cap {
            return;
        }
        unsafe {
            ptr::write((self.ptr + self.len) as *mut u8, value);
        }
        self.len += 1;
    }

    fn bytes(&mut self, values: &[u8]) {
        for value in values {
            self.byte(*value);
        }
    }

    fn bool(&mut self, value: bool) {
        if value {
            self.bytes(b"true");
        } else {
            self.bytes(b"false");
        }
    }

    fn usize(&mut self, mut value: usize) {
        let mut tmp = [0u8; 20];
        let mut idx = tmp.len();
        if value == 0 {
            self.byte(b'0');
            return;
        }
        while value > 0 {
            idx -= 1;
            tmp[idx] = b'0' + (value % 10) as u8;
            value /= 10;
        }
        self.bytes(&tmp[idx..]);
    }

    fn escaped_json_string(&mut self, value: &[u8]) {
        self.byte(b'"');
        for b in value {
            match *b {
                b'"' => self.bytes(br#"\""#),
                b'\\' => self.bytes(br#"\\"#),
                b'\n' => self.bytes(br#"\n"#),
                b'\r' => self.bytes(br#"\r"#),
                b'\t' => self.bytes(br#"\t"#),
                other => self.byte(other),
            }
        }
        self.byte(b'"');
    }
}

fn write_capabilities() -> u64 {
    let Some(mut w) = Writer::new() else { return 0; };
    w.bytes(b"{\"capabilities\":{\"abiVersion\":\"rsm-wasm-json-v1\",\"commands\":[\"capabilities\",\"parse\",\"readCheats\",\"applyCheats\"],\"operations\":[\"moduleTemplate\"],\"editableFields\":1},\"supported\":true}");
    w.finish()
}

fn write_read_cheats(input: &[u8]) -> u64 {
    let verified = json_string_field(input, b"payload")
        .and_then(|(start, len)| decode_and_analyze(&input[start..start + len]))
        .map(|analysis| analysis.verified_template)
        .unwrap_or(false);
    let Some(mut w) = Writer::new() else { return 0; };
    w.bytes(b"{\"supported\":true,\"gameId\":\"n64/yoshis-story\",\"systemSlug\":\"n64\",\"editorId\":\"yoshis-story-wasm\",\"adapterId\":\"yoshis-story-wasm\",\"packId\":\"n64--yoshis-story\",\"title\":\"Yoshi's Story\",\"availableCount\":1,\"values\":{\"installVerified100Percent\":");
    w.bool(verified);
    w.bytes(b"},\"sections\":[{\"id\":\"verified-template\",\"title\":\"Verified Save Template\",\"fields\":[{\"id\":\"installVerified100Percent\",\"ref\":\"installVerified100Percent\",\"label\":\"Install Verified 100% Save\",\"description\":\"Replaces this EEPROM with the verified 100% Project64 sample: black and white Yoshis unlocked and all stages available in Trial Mode.\",\"type\":\"boolean\",\"op\":{\"kind\":\"moduleTemplate\",\"field\":\"verified100Percent\"}}]}],\"presets\":[{\"id\":\"installVerified100Percent\",\"label\":\"Install verified 100% save\",\"description\":\"Uses the real EmuNations Project64 sample and preserves its valid mirrored EEPROM/checksum bytes.\",\"updates\":{\"installVerified100Percent\":true}}]}");
    w.finish()
}

fn write_apply_cheats(input: &[u8]) -> u64 {
    if json_bool_field(input, b"installVerified100Percent") == Some(true) {
        let Some(mut w) = Writer::new() else { return 0; };
        w.bytes(b"{\"payload\":\"");
        write_base64(&mut w, &verified_100_percent::VERIFIED_100_PERCENT);
        w.bytes(b"\",\"changed\":{\"installVerified100Percent\":true},\"integritySteps\":[\"replaced payload with verified 2048-byte 100% Project64 EEPROM sample\",\"sample contains two mirrored EepBuffer copies with stored checksum 0x9EB0 and magic 0x81317531\"]}");
        return w.finish();
    }

    let Some(mut w) = Writer::new() else { return 0; };
    w.bytes(b"{\"payload\":");
    if let Some((start, len)) = json_string_field(input, b"payload") {
        w.escaped_json_string(&input[start..start + len]);
    } else {
        w.bytes(b"\"\"");
    }
    w.bytes(b",\"changed\":{},\"integritySteps\":[\"no Yoshi's Story template update requested\"]}");
    w.finish()
}

struct Analysis {
    copy1_magic: bool,
    copy2_magic: bool,
    identical: bool,
    copy1_non_zero: usize,
    copy2_non_zero: usize,
    checksum1: usize,
    checksum2: usize,
    verified_template: bool,
}

fn write_parse(input: &[u8]) -> u64 {
    let Some((payload_start, payload_len)) = json_string_field(input, b"payload") else {
        return write_unsupported(b"payload missing");
    };
    let Some(analysis) = decode_and_analyze(&input[payload_start..payload_start + payload_len]) else {
        return write_unsupported(b"expected 2048-byte base64 Yoshi's Story EEPROM");
    };
    if !analysis.copy1_magic && !analysis.copy2_magic {
        return write_unsupported(b"Yoshi's Story EEPROM magic not found");
    }

    let Some(mut w) = Writer::new() else { return 0; };
    w.bytes(b"{\"supported\":true,\"parserLevel\":\"structural\",\"parserId\":\"yoshis-story-wasm\",\"validatedSystem\":\"n64\",\"validatedGameId\":\"n64/yoshis-story\",\"validatedGameTitle\":\"Yoshi's Story\",\"trustLevel\":\"module-structural-verified\",\"evidence\":[\"validated 2048-byte 16Kbit EEPROM container\",\"validated EepBuffer magic 0x81317531 in at least one copy\",\"decomp source shows two 0x400 EepBuffer copies with data[0x3FA], u16 checksum, and magic\"],\"warnings\":[");
    if !analysis.identical {
        w.bytes(b"\"Yoshi's Story EEPROM copies are not byte-identical.\",");
    }
    w.bytes(b"\"Granular gameplay edits are limited to the verified 100% template because func_800699BC and the save-data transform are not fully decompiled.\"],\"slotCount\":");
    w.usize(usize::from(analysis.copy1_magic) + usize::from(analysis.copy2_magic));
    w.bytes(b",\"activeSlotIndexes\":[");
    let mut wrote = false;
    if analysis.copy1_magic {
        w.byte(b'1');
        wrote = true;
    }
    if analysis.copy2_magic {
        if wrote { w.byte(b','); }
        w.byte(b'2');
    }
    w.bytes(b"],\"semanticFields\":{\"variant\":\"yoshis-story\",\"container\":\"eeprom-16k-two-0x400-copies\",\"dataBytesPerCopy\":");
    w.usize(DATA_SIZE);
    w.bytes(b",\"storedChecksumCopy1\":");
    w.usize(analysis.checksum1);
    w.bytes(b",\"storedChecksumCopy2\":");
    w.usize(analysis.checksum2);
    w.bytes(b",\"copy1MagicValid\":");
    w.bool(analysis.copy1_magic);
    w.bytes(b",\"copy2MagicValid\":");
    w.bool(analysis.copy2_magic);
    w.bytes(b",\"copy1NonZeroData\":");
    w.usize(analysis.copy1_non_zero);
    w.bytes(b",\"copy2NonZeroData\":");
    w.usize(analysis.copy2_non_zero);
    w.bytes(b",\"identicalCopies\":");
    w.bool(analysis.identical);
    w.bytes(b",\"verified100PercentTemplate\":");
    w.bool(analysis.verified_template);
    w.bytes(b",\"editableFields\":1}}");
    w.finish()
}

fn write_base64(w: &mut Writer, bytes: &[u8]) {
    const TABLE: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut i = 0usize;
    while i + 3 <= bytes.len() {
        let n = ((bytes[i] as u32) << 16) | ((bytes[i + 1] as u32) << 8) | bytes[i + 2] as u32;
        w.byte(TABLE[((n >> 18) & 0x3F) as usize]);
        w.byte(TABLE[((n >> 12) & 0x3F) as usize]);
        w.byte(TABLE[((n >> 6) & 0x3F) as usize]);
        w.byte(TABLE[(n & 0x3F) as usize]);
        i += 3;
    }
    let rem = bytes.len() - i;
    if rem == 1 {
        let n = (bytes[i] as u32) << 16;
        w.byte(TABLE[((n >> 18) & 0x3F) as usize]);
        w.byte(TABLE[((n >> 12) & 0x3F) as usize]);
        w.byte(b'=');
        w.byte(b'=');
    } else if rem == 2 {
        let n = ((bytes[i] as u32) << 16) | ((bytes[i + 1] as u32) << 8);
        w.byte(TABLE[((n >> 18) & 0x3F) as usize]);
        w.byte(TABLE[((n >> 12) & 0x3F) as usize]);
        w.byte(TABLE[((n >> 6) & 0x3F) as usize]);
        w.byte(b'=');
    }
}

fn write_unsupported(reason: &[u8]) -> u64 {
    let Some(mut w) = Writer::new() else { return 0; };
    w.bytes(b"{\"supported\":false,\"warnings\":[");
    w.escaped_json_string(reason);
    w.bytes(b"]}");
    w.finish()
}

fn decode_and_analyze(input: &[u8]) -> Option<Analysis> {
    let mut out_len = 0usize;
    let mut buf = 0u32;
    let mut bits = 0u8;
    for b in input {
        let value = match *b {
            b'A'..=b'Z' => *b - b'A',
            b'a'..=b'z' => *b - b'a' + 26,
            b'0'..=b'9' => *b - b'0' + 52,
            b'+' => 62,
            b'/' => 63,
            b'=' => break,
            b'\r' | b'\n' | b'\t' | b' ' => continue,
            _ => return None,
        } as u32;
        buf = (buf << 6) | value;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            if out_len >= EEPROM_SIZE {
                return None;
            }
            unsafe {
                PAYLOAD[out_len] = ((buf >> bits) & 0xFF) as u8;
            }
            out_len += 1;
        }
    }
    if out_len != EEPROM_SIZE {
        return None;
    }

    unsafe {
        let copy1 = &PAYLOAD[..COPY_SIZE];
        let copy2 = &PAYLOAD[COPY_SIZE..EEPROM_SIZE];
        Some(Analysis {
            copy1_magic: has_magic(copy1),
            copy2_magic: has_magic(copy2),
            identical: copy1 == copy2,
            copy1_non_zero: count_non_zero(&copy1[..DATA_SIZE]),
            copy2_non_zero: count_non_zero(&copy2[..DATA_SIZE]),
            checksum1: read_be_u16(copy1, CHECKSUM_OFFSET),
            checksum2: read_be_u16(copy2, CHECKSUM_OFFSET),
            verified_template: PAYLOAD == verified_100_percent::VERIFIED_100_PERCENT,
        })
    }
}

fn has_magic(copy: &[u8]) -> bool {
    copy.len() == COPY_SIZE && copy[MAGIC_OFFSET..MAGIC_OFFSET + 4] == MAGIC
}

fn read_be_u16(bytes: &[u8], offset: usize) -> usize {
    (((bytes[offset] as u16) << 8) | (bytes[offset + 1] as u16)) as usize
}

fn count_non_zero(bytes: &[u8]) -> usize {
    let mut total = 0usize;
    for b in bytes {
        if *b != 0 {
            total += 1;
        }
    }
    total
}

fn json_string_field(input: &[u8], key: &[u8]) -> Option<(usize, usize)> {
    let key_pos = find_key(input, key)?;
    let mut i = key_pos + key.len() + 2;
    while i < input.len() && input[i].is_ascii_whitespace() {
        i += 1;
    }
    if i >= input.len() || input[i] != b':' {
        return None;
    }
    i += 1;
    while i < input.len() && input[i].is_ascii_whitespace() {
        i += 1;
    }
    if i >= input.len() || input[i] != b'"' {
        return None;
    }
    i += 1;
    let start = i;
    while i < input.len() {
        match input[i] {
            b'"' => return Some((start, i - start)),
            b'\\' => i += 2,
            _ => i += 1,
        }
    }
    None
}

fn json_bool_field(input: &[u8], key: &[u8]) -> Option<bool> {
    let key_pos = find_key(input, key)?;
    let mut i = key_pos + key.len() + 2;
    while i < input.len() && input[i].is_ascii_whitespace() {
        i += 1;
    }
    if i >= input.len() || input[i] != b':' {
        return None;
    }
    i += 1;
    while i < input.len() && input[i].is_ascii_whitespace() {
        i += 1;
    }
    if i + 4 <= input.len() && &input[i..i + 4] == b"true" {
        return Some(true);
    }
    if i + 5 <= input.len() && &input[i..i + 5] == b"false" {
        return Some(false);
    }
    None
}

fn find_key(input: &[u8], key: &[u8]) -> Option<usize> {
    if key.is_empty() || input.len() < key.len() + 2 {
        return None;
    }
    let mut i = 0usize;
    while i + key.len() + 2 <= input.len() {
        if input[i] == b'"' && input[i + key.len() + 1] == b'"' && &input[i + 1..i + 1 + key.len()] == key {
            return Some(i);
        }
        i += 1;
    }
    None
}
