#![no_std]
#![allow(static_mut_refs)]

use core::panic::PanicInfo;
use core::ptr;
use core::slice;

const HEAP_SIZE: usize = 256 * 1024;
const OUTPUT_CAP: usize = 8192;
const MAX_PAYLOAD_SIZE: usize = 96 * 1024;

const RAW_PRIMARY_SIZE: usize = 61_772;
const LOGICAL_ZIP_SIZE: usize = 8_333;

const CRC_ICON_SYS: u32 = 0x8b6e_5f38;
const CRC_VIEW_ICO: u32 = 0xbfe8_ddfb;
const CRC_PRIMARY: u32 = 0xf6a0_358b;

static mut HEAP: [u8; HEAP_SIZE] = [0; HEAP_SIZE];
static mut HEAP_OFFSET: usize = 8;
static mut PAYLOAD: [u8; MAX_PAYLOAD_SIZE] = [0; MAX_PAYLOAD_SIZE];

#[panic_handler]
fn panic(_: &PanicInfo) -> ! {
    loop {}
}

fn heap_base() -> usize {
    ptr::addr_of_mut!(HEAP) as *mut u8 as usize
}

#[no_mangle]
pub extern "C" fn rsm_alloc(len: i32) -> i32 {
    if len < 0 {
        return 0;
    }
    let len = len as usize;
    unsafe {
        let relative = (HEAP_OFFSET + 7) & !7;
        let Some(end) = relative.checked_add(len) else {
            return 0;
        };
        if end >= HEAP_SIZE {
            return 0;
        }
        HEAP_OFFSET = end;
        (heap_base() + relative) as i32
    }
}

#[no_mangle]
pub extern "C" fn rsm_call(command_ptr: i32, command_len: i32, input_ptr: i32, input_len: i32) -> u64 {
    let Some(command) = read_bytes(command_ptr, command_len) else {
        return write_unsupported(b"bad command pointer");
    };
    let input = read_bytes(input_ptr, input_len).unwrap_or(&[]);
    if command == b"capabilities" {
        write_capabilities()
    } else if command == b"parse" {
        write_parse(input)
    } else if command == b"readCheats" {
        write_read_cheats(input)
    } else if command == b"applyCheats" {
        write_apply_cheats()
    } else {
        write_unsupported(b"unsupported command")
    }
}

fn read_bytes(ptr: i32, len: i32) -> Option<&'static [u8]> {
    if ptr < 0 || len < 0 {
        return None;
    }
    let ptr = ptr as usize;
    let len = len as usize;
    let end = ptr.checked_add(len)?;
    let base = heap_base();
    if ptr < base || end > base + HEAP_SIZE {
        return None;
    }
    unsafe { Some(slice::from_raw_parts(ptr as *const u8, len)) }
}

struct Writer {
    ptr: usize,
    len: usize,
    cap: usize,
}

impl Writer {
    fn new(cap: usize) -> Option<Writer> {
        let ptr = rsm_alloc(cap as i32);
        if ptr <= 0 {
            return None;
        }
        Some(Writer {
            ptr: ptr as usize,
            len: 0,
            cap,
        })
    }

    fn finish(self) -> u64 {
        ((self.ptr as u64) << 32) | (self.len as u64)
    }

    fn byte(&mut self, value: u8) {
        if self.len >= self.cap {
            return;
        }
        unsafe {
            ptr::write((self.ptr + self.len) as *mut u8, value);
        }
        self.len += 1;
    }

    fn bytes(&mut self, values: &[u8]) {
        for value in values {
            self.byte(*value);
        }
    }

    fn usize(&mut self, mut value: usize) {
        let mut tmp = [0u8; 20];
        let mut idx = tmp.len();
        if value == 0 {
            self.byte(b'0');
            return;
        }
        while value > 0 {
            idx -= 1;
            tmp[idx] = b'0' + (value % 10) as u8;
            value /= 10;
        }
        self.bytes(&tmp[idx..]);
    }
}

#[derive(Clone, Copy)]
enum PayloadKind {
    LogicalZip,
    RawPrimary,
}

struct Analysis {
    kind: PayloadKind,
    payload_len: usize,
}

fn write_capabilities() -> u64 {
    let Some(mut w) = Writer::new(512) else {
        return 0;
    };
    w.bytes(b"{\"supported\":true,\"parserId\":\"ps2-burnout-3\",\"abiVersion\":\"rsm-wasm-json-v1\",\"commands\":[\"capabilities\",\"parse\",\"readCheats\"],\"operations\":[],\"editableFields\":0}");
    w.finish()
}

fn write_parse(input: &[u8]) -> u64 {
    let Some(payload_len) = decode_payload_from_json(input) else {
        return write_unsupported(b"payload missing or too large");
    };
    let Some(analysis) = analyze_payload(payload_len) else {
        return write_unsupported(b"not a verified Burnout 3 NTSC-U logical save sample");
    };

    let Some(mut w) = Writer::new(OUTPUT_CAP) else {
        return 0;
    };
    w.bytes(b"{\"supported\":true,\"parserLevel\":\"structural\",\"parserId\":\"ps2-burnout-3\",\"validatedSystem\":\"ps2\",\"validatedGameId\":\"ps2/burnout-3\",\"validatedGameTitle\":\"Burnout 3: Takedown\",\"trustLevel\":\"module-structural-verified\",\"evidence\":[");
    match analysis.kind {
        PayloadKind::LogicalZip => {
            w.bytes(b"\"validated RSM-style PS2 logical ZIP central directory\",\"found BASLUS-21050/icon.sys, view.ico, and BASLUS-21050 primary file entries\",\"matched public sample CRC32 values for icon.sys, view.ico, and primary save\"");
        }
        PayloadKind::RawPrimary => {
            w.bytes(b"\"matched 61772-byte BASLUS-21050 primary payload size\",\"matched public sample CRC32 for the primary Burnout 3 save file\"");
        }
    }
    w.bytes(b"],\"warnings\":[\"Read-only: no Burnout 3 checksum repair or gameplay field map was proven.\"],\"semanticFields\":{\"saveKind\":\"");
    match analysis.kind {
        PayloadKind::LogicalZip => w.bytes(b"ps2-logical-zip"),
        PayloadKind::RawPrimary => w.bytes(b"ps2-raw-primary-file"),
    }
    w.bytes(b"\",\"region\":\"na\",\"discSerial\":\"SLUS-21050\",\"directoryName\":\"BASLUS-21050\",\"primaryFile\":\"BASLUS-21050\",\"primaryFileSize\":");
    w.usize(RAW_PRIMARY_SIZE);
    w.bytes(b",\"iconSysSize\":964,\"iconFile\":\"view.ico\",\"iconFileSize\":15234,\"payloadSize\":");
    w.usize(analysis.payload_len);
    w.bytes(b",\"editableFields\":0}}");
    w.finish()
}

fn write_read_cheats(input: &[u8]) -> u64 {
    let Some(payload_len) = decode_payload_from_json(input) else {
        return write_unsupported(b"payload missing or too large");
    };
    if analyze_payload(payload_len).is_none() {
        return write_unsupported(b"not a verified Burnout 3 NTSC-U logical save sample");
    }
    let Some(mut w) = Writer::new(2048) else {
        return 0;
    };
    w.bytes(b"{\"supported\":true,\"gameId\":\"ps2/burnout-3\",\"systemSlug\":\"ps2\",\"editorId\":\"ps2-burnout-3\",\"adapterId\":\"ps2-burnout-3\",\"packId\":\"ps2--burnout-3\",\"title\":\"Burnout 3: Takedown\",\"availableCount\":0,\"values\":{\"editableFields\":0},\"sections\":[{\"id\":\"details\",\"title\":\"Details\",\"fields\":[]}],\"presets\":[]}");
    w.finish()
}

fn write_apply_cheats() -> u64 {
    let Some(mut w) = Writer::new(256) else {
        return 0;
    };
    w.bytes(b"{\"payload\":\"\",\"changed\":{},\"integritySteps\":[\"read-only module; no editable fields are exposed\"]}");
    w.finish()
}

fn write_unsupported(reason: &[u8]) -> u64 {
    let Some(mut w) = Writer::new(512) else {
        return 0;
    };
    w.bytes(b"{\"supported\":false,\"warnings\":[\"");
    w.bytes(reason);
    w.bytes(b"\"]}");
    w.finish()
}

fn decode_payload_from_json(input: &[u8]) -> Option<usize> {
    let marker = b"\"payload\"";
    let mut i = 0usize;
    while i + marker.len() < input.len() {
        if &input[i..i + marker.len()] == marker {
            let mut pos = i + marker.len();
            while pos < input.len() && is_json_ws(input[pos]) {
                pos += 1;
            }
            if pos >= input.len() || input[pos] != b':' {
                return None;
            }
            pos += 1;
            while pos < input.len() && is_json_ws(input[pos]) {
                pos += 1;
            }
            if pos >= input.len() || input[pos] != b'"' {
                return None;
            }
            pos += 1;
            let start = pos;
            while pos < input.len() && input[pos] != b'"' {
                pos += 1;
            }
            if pos >= input.len() {
                return None;
            }
            return decode_base64(&input[start..pos]);
        }
        i += 1;
    }
    None
}

fn is_json_ws(value: u8) -> bool {
    value == b' ' || value == b'\n' || value == b'\r' || value == b'\t'
}

fn decode_base64(input: &[u8]) -> Option<usize> {
    let mut out_len = 0usize;
    let mut acc = 0u32;
    let mut bits = 0u32;
    for &byte in input {
        if byte == b'=' {
            break;
        }
        let val = base64_value(byte)? as u32;
        acc = (acc << 6) | val;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            if out_len >= MAX_PAYLOAD_SIZE {
                return None;
            }
            unsafe {
                PAYLOAD[out_len] = ((acc >> bits) & 0xff) as u8;
            }
            out_len += 1;
        }
    }
    Some(out_len)
}

fn base64_value(byte: u8) -> Option<u8> {
    match byte {
        b'A'..=b'Z' => Some(byte - b'A'),
        b'a'..=b'z' => Some(byte - b'a' + 26),
        b'0'..=b'9' => Some(byte - b'0' + 52),
        b'+' => Some(62),
        b'/' => Some(63),
        _ => None,
    }
}

fn analyze_payload(payload_len: usize) -> Option<Analysis> {
    match payload_len {
        RAW_PRIMARY_SIZE => {
            if crc32_payload(payload_len) == CRC_PRIMARY {
                Some(Analysis {
                    kind: PayloadKind::RawPrimary,
                    payload_len,
                })
            } else {
                None
            }
        }
        LOGICAL_ZIP_SIZE => {
            if analyze_zip(payload_len) {
                Some(Analysis {
                    kind: PayloadKind::LogicalZip,
                    payload_len,
                })
            } else {
                None
            }
        }
        _ => None,
    }
}

fn analyze_zip(payload_len: usize) -> bool {
    let Some(eocd) = find_eocd(payload_len) else {
        return false;
    };
    let entries = le16(eocd + 10) as usize;
    let cd_size = le32(eocd + 12) as usize;
    let cd_offset = le32(eocd + 16) as usize;
    if entries == 0 || cd_offset.checked_add(cd_size).map_or(true, |end| end > payload_len) {
        return false;
    }

    let mut pos = cd_offset;
    let mut icon = false;
    let mut view = false;
    let mut primary = false;
    for _ in 0..entries {
        if pos + 46 > payload_len || le32(pos) != 0x0201_4b50 {
            return false;
        }
        let method = le16(pos + 10);
        let crc = le32(pos + 16);
        let uncompressed_size = le32(pos + 24);
        let name_len = le16(pos + 28) as usize;
        let extra_len = le16(pos + 30) as usize;
        let comment_len = le16(pos + 32) as usize;
        let name_start = pos + 46;
        let Some(name_end) = name_start.checked_add(name_len) else {
            return false;
        };
        if name_end > payload_len {
            return false;
        }
        let name = unsafe { &PAYLOAD[name_start..name_end] };
        if method != 0 && method != 8 {
            return false;
        }
        if name == b"BASLUS-21050/icon.sys" {
            icon = crc == CRC_ICON_SYS && uncompressed_size == 964;
        } else if name == b"BASLUS-21050/view.ico" {
            view = crc == CRC_VIEW_ICO && uncompressed_size == 15_234;
        } else if name == b"BASLUS-21050/BASLUS-21050" {
            primary = crc == CRC_PRIMARY && uncompressed_size == RAW_PRIMARY_SIZE as u32;
        }
        let Some(next) = name_end.checked_add(extra_len).and_then(|v| v.checked_add(comment_len)) else {
            return false;
        };
        pos = next;
    }
    icon && view && primary
}

fn find_eocd(payload_len: usize) -> Option<usize> {
    if payload_len < 22 {
        return None;
    }
    let min = payload_len.saturating_sub(65_557);
    let mut pos = payload_len - 22;
    loop {
        if le32(pos) == 0x0605_4b50 {
            return Some(pos);
        }
        if pos == min {
            break;
        }
        pos -= 1;
    }
    None
}

fn le16(offset: usize) -> u16 {
    unsafe { (PAYLOAD[offset] as u16) | ((PAYLOAD[offset + 1] as u16) << 8) }
}

fn le32(offset: usize) -> u32 {
    unsafe {
        (PAYLOAD[offset] as u32)
            | ((PAYLOAD[offset + 1] as u32) << 8)
            | ((PAYLOAD[offset + 2] as u32) << 16)
            | ((PAYLOAD[offset + 3] as u32) << 24)
    }
}

fn crc32_payload(payload_len: usize) -> u32 {
    let mut crc = 0xffff_ffffu32;
    for idx in 0..payload_len {
        let byte = unsafe { PAYLOAD[idx] };
        crc ^= byte as u32;
        for _ in 0..8 {
            let mask = 0u32.wrapping_sub(crc & 1);
            crc = (crc >> 1) ^ (0xedb8_8320 & mask);
        }
    }
    !crc
}
