# Burnout 3: Takedown PS2 Module

Read-only structural support for the verified NTSC-U Burnout 3 sample from the public PCSX2 Save File Collection Memory Card 7.

## Supported Payloads

- 8,333-byte RSM-style logical ZIP containing `BASLUS-21050/icon.sys`, `BASLUS-21050/view.ico`, and `BASLUS-21050/BASLUS-21050`.
- 61,772-byte raw primary `BASLUS-21050` payload when supplied as a `.bin` or `.dat`.

The module validates file sizes and CRC32 values from the real sample:

| file | size | crc32 |
|---|---:|---:|
| `BASLUS-21050/icon.sys` | 964 | `8b6e5f38` |
| `BASLUS-21050/view.ico` | 15234 | `bfe8ddfb` |
| `BASLUS-21050/BASLUS-21050` | 61772 | `f6a0358b` |

## Editable Surface

No editable fields are exposed. The save body has no obvious text magic, public checksum documentation, or independently verified field map in the researched material. The bundled cheat pack intentionally contains an empty details section so the module can be imported without enabling writes.
