#![no_std]

use core::panic::PanicInfo;
use core::ptr;
use core::slice;

const PS1_CARD_SIZE: usize = 131_072;
const PS1_BLOCK_SIZE: usize = 8192;
const PS1_DIR_SIZE: usize = 128;
const PS1_DIR_COUNT: usize = 15;
const SAVE_DATA_SIZE: u32 = 0x11CC;
const MAX_GOLD: i32 = 999_999;
const MAX_ENTRIES: usize = 15;
const HEAP_SIZE: usize = 512 * 1024;
const OUTPUT_CAP: usize = 220_000;

static mut HEAP: [u8; HEAP_SIZE] = [0; HEAP_SIZE];
static mut HEAP_OFFSET: usize = 8;
static mut PAYLOAD: [u8; PS1_CARD_SIZE] = [0; PS1_CARD_SIZE];
static mut PAYLOAD_LEN: usize = 0;

#[panic_handler]
fn panic(_: &PanicInfo) -> ! {
    loop {}
}

fn heap_base() -> usize {
    ptr::addr_of_mut!(HEAP) as *mut u8 as usize
}

#[no_mangle]
pub extern "C" fn rsm_alloc(len: i32) -> i32 {
    if len <= 0 {
        return 0;
    }
    let len = len as usize;
    unsafe {
        let relative = (HEAP_OFFSET + 7) & !7;
        let Some(end) = relative.checked_add(len) else { return 0; };
        if end >= HEAP_SIZE {
            return 0;
        }
        HEAP_OFFSET = end;
        (heap_base() + relative) as i32
    }
}

#[no_mangle]
pub extern "C" fn rsm_call(command_ptr: i32, command_len: i32, input_ptr: i32, input_len: i32) -> u64 {
    let Some(command) = read_bytes(command_ptr, command_len) else {
        return write_error(b"bad command pointer");
    };
    let input = read_bytes(input_ptr, input_len).unwrap_or(&[]);
    match command {
        b"capabilities" => write_capabilities(),
        b"parse" => write_parse(input),
        b"readCheats" => write_read_cheats(input),
        b"applyCheats" => write_apply_cheats(input),
        _ => write_error(b"unsupported command"),
    }
}

fn read_bytes(ptr_value: i32, len_value: i32) -> Option<&'static [u8]> {
    if ptr_value < 0 || len_value < 0 {
        return None;
    }
    let ptr_value = ptr_value as usize;
    let len_value = len_value as usize;
    let end = ptr_value.checked_add(len_value)?;
    let base = heap_base();
    if ptr_value < base || end > base + HEAP_SIZE {
        return None;
    }
    unsafe { Some(slice::from_raw_parts(ptr_value as *const u8, len_value)) }
}

struct Writer {
    ptr: usize,
    len: usize,
    cap: usize,
}

impl Writer {
    fn new(cap: usize) -> Option<Writer> {
        let ptr_value = rsm_alloc(cap as i32);
        if ptr_value <= 0 {
            return None;
        }
        Some(Writer { ptr: ptr_value as usize, len: 0, cap })
    }

    fn finish(self) -> u64 {
        ((self.ptr as u64) << 32) | (self.len as u64)
    }

    fn byte(&mut self, value: u8) {
        if self.len >= self.cap {
            return;
        }
        unsafe {
            ptr::write((self.ptr + self.len) as *mut u8, value);
        }
        self.len += 1;
    }

    fn bytes(&mut self, values: &[u8]) {
        for value in values {
            self.byte(*value);
        }
    }

    fn bool(&mut self, value: bool) {
        self.bytes(if value { b"true" } else { b"false" });
    }

    fn u32(&mut self, mut value: u32) {
        if value == 0 {
            self.byte(b'0');
            return;
        }
        let mut tmp = [0u8; 10];
        let mut idx = tmp.len();
        while value > 0 {
            idx -= 1;
            tmp[idx] = b'0' + (value % 10) as u8;
            value /= 10;
        }
        self.bytes(&tmp[idx..]);
    }

    fn i32(&mut self, value: i32) {
        if value < 0 {
            self.byte(b'-');
            self.u32(value.wrapping_neg() as u32);
        } else {
            self.u32(value as u32);
        }
    }

    fn json_ascii(&mut self, bytes: &[u8], uppercase: bool, trim_spaces: bool) {
        let mut end = bytes.len();
        while end > 0 && (bytes[end - 1] == 0 || (trim_spaces && bytes[end - 1] == b' ')) {
            end -= 1;
        }
        self.byte(b'"');
        for item in &bytes[..end] {
            let mut c = *item;
            if c == 0 {
                break;
            }
            if uppercase && c.is_ascii_lowercase() {
                c = c - b'a' + b'A';
            }
            match c {
                b'"' | b'\\' => {
                    self.byte(b'\\');
                    self.byte(c);
                }
                0x20..=0x7e => self.byte(c),
                _ => {}
            }
        }
        self.byte(b'"');
    }

    fn hex_from_payload(&mut self, off: usize, len: usize) {
        const HEX: &[u8; 16] = b"0123456789abcdef";
        self.byte(b'"');
        let mut i = 0usize;
        while i < len {
            let value = payload_read(off + i);
            self.byte(HEX[(value >> 4) as usize]);
            self.byte(HEX[(value & 0x0f) as usize]);
            i += 1;
        }
        self.byte(b'"');
    }

    fn u32_array_from_payload(&mut self, off: usize, count: usize) {
        self.byte(b'[');
        let mut i = 0usize;
        while i < count {
            if i > 0 {
                self.byte(b',');
            }
            self.u32(rd_u32(off + i * 4));
            i += 1;
        }
        self.byte(b']');
    }
}

fn write_error(message: &[u8]) -> u64 {
    let Some(mut w) = Writer::new(256) else { return 0; };
    w.bytes(b"{\"supported\":false,\"error\":\"");
    w.bytes(message);
    w.bytes(b"\"}");
    w.finish()
}

fn find_bytes(input: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() || input.len() < needle.len() {
        return None;
    }
    let last = input.len() - needle.len();
    let mut i = 0;
    while i <= last {
        if &input[i..i + needle.len()] == needle {
            return Some(i);
        }
        i += 1;
    }
    None
}

fn skip_ws(input: &[u8], mut idx: usize) -> usize {
    while idx < input.len() {
        match input[idx] {
            b' ' | b'\n' | b'\r' | b'\t' => idx += 1,
            _ => break,
        }
    }
    idx
}

fn json_string_raw<'a>(input: &'a [u8], field: &[u8]) -> Option<&'a [u8]> {
    let mut key = [0u8; 80];
    if field.len() + 2 >= key.len() {
        return None;
    }
    key[0] = b'"';
    key[1..1 + field.len()].copy_from_slice(field);
    key[field.len() + 1] = b'"';
    let key_len = field.len() + 2;
    let found = find_bytes(input, &key[..key_len])?;
    let mut idx = skip_ws(input, found + key_len);
    if input.get(idx) != Some(&b':') {
        return None;
    }
    idx = skip_ws(input, idx + 1);
    if input.get(idx) != Some(&b'"') {
        return None;
    }
    let start = idx + 1;
    idx = start;
    while idx < input.len() {
        if input[idx] == b'\\' {
            idx += 2;
            continue;
        }
        if input[idx] == b'"' {
            return Some(&input[start..idx]);
        }
        idx += 1;
    }
    None
}

fn json_i32_field(input: &[u8], field: &[u8]) -> Option<i32> {
    let mut key = [0u8; 80];
    if field.len() + 2 >= key.len() {
        return None;
    }
    key[0] = b'"';
    key[1..1 + field.len()].copy_from_slice(field);
    key[field.len() + 1] = b'"';
    let key_len = field.len() + 2;
    let found = find_bytes(input, &key[..key_len])?;
    let mut idx = skip_ws(input, found + key_len);
    if input.get(idx) != Some(&b':') {
        return None;
    }
    idx = skip_ws(input, idx + 1);
    let mut neg = false;
    if input.get(idx) == Some(&b'-') {
        neg = true;
        idx += 1;
    }
    let mut value: i32 = 0;
    let mut saw = false;
    while idx < input.len() && input[idx].is_ascii_digit() {
        saw = true;
        value = value.saturating_mul(10).saturating_add((input[idx] - b'0') as i32);
        idx += 1;
    }
    if !saw {
        return None;
    }
    Some(if neg { -value } else { value })
}

fn b64_value(c: u8) -> Option<u8> {
    match c {
        b'A'..=b'Z' => Some(c - b'A'),
        b'a'..=b'z' => Some(c - b'a' + 26),
        b'0'..=b'9' => Some(c - b'0' + 52),
        b'+' => Some(62),
        b'/' => Some(63),
        _ => None,
    }
}

fn payload_ptr() -> *mut u8 {
    ptr::addr_of_mut!(PAYLOAD) as *mut u8
}

fn payload_read(off: usize) -> u8 {
    unsafe { ptr::read(payload_ptr().add(off)) }
}

fn payload_write(off: usize, value: u8) {
    unsafe { ptr::write(payload_ptr().add(off), value); }
}

fn set_payload_len(len: usize) {
    unsafe { PAYLOAD_LEN = len; }
}

fn payload_len() -> usize {
    unsafe { PAYLOAD_LEN }
}

fn base64_decode_to_payload(encoded: &[u8]) -> bool {
    let mut out = 0usize;
    let mut i = 0usize;
    while i < encoded.len() {
        let mut vals = [0u8; 4];
        let mut pad = 0usize;
        let mut j = 0usize;
        while j < 4 {
            if i >= encoded.len() {
                return false;
            }
            let c = encoded[i];
            i += 1;
            if c == b'=' {
                vals[j] = 0;
                pad += 1;
            } else if let Some(v) = b64_value(c) {
                vals[j] = v;
            } else {
                return false;
            }
            j += 1;
        }
        let triple = ((vals[0] as u32) << 18) | ((vals[1] as u32) << 12) | ((vals[2] as u32) << 6) | vals[3] as u32;
        if out >= PS1_CARD_SIZE { return false; }
        payload_write(out, ((triple >> 16) & 0xff) as u8);
        out += 1;
        if pad < 2 {
            if out >= PS1_CARD_SIZE { return false; }
            payload_write(out, ((triple >> 8) & 0xff) as u8);
            out += 1;
        }
        if pad < 1 {
            if out >= PS1_CARD_SIZE { return false; }
            payload_write(out, (triple & 0xff) as u8);
            out += 1;
        }
    }
    set_payload_len(out);
    true
}

fn write_base64_payload(w: &mut Writer, len: usize) {
    const TABLE: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut i = 0usize;
    while i + 3 <= len {
        let n = ((payload_read(i) as u32) << 16) | ((payload_read(i + 1) as u32) << 8) | payload_read(i + 2) as u32;
        w.byte(TABLE[((n >> 18) & 0x3f) as usize]);
        w.byte(TABLE[((n >> 12) & 0x3f) as usize]);
        w.byte(TABLE[((n >> 6) & 0x3f) as usize]);
        w.byte(TABLE[(n & 0x3f) as usize]);
        i += 3;
    }
    match len - i {
        1 => {
            let n = (payload_read(i) as u32) << 16;
            w.byte(TABLE[((n >> 18) & 0x3f) as usize]);
            w.byte(TABLE[((n >> 12) & 0x3f) as usize]);
            w.byte(b'=');
            w.byte(b'=');
        }
        2 => {
            let n = ((payload_read(i) as u32) << 16) | ((payload_read(i + 1) as u32) << 8);
            w.byte(TABLE[((n >> 18) & 0x3f) as usize]);
            w.byte(TABLE[((n >> 12) & 0x3f) as usize]);
            w.byte(TABLE[((n >> 6) & 0x3f) as usize]);
            w.byte(b'=');
        }
        _ => {}
    }
}

fn rd_u16(off: usize) -> u16 {
    payload_read(off) as u16 | ((payload_read(off + 1) as u16) << 8)
}

fn rd_u32(off: usize) -> u32 {
    payload_read(off) as u32
        | ((payload_read(off + 1) as u32) << 8)
        | ((payload_read(off + 2) as u32) << 16)
        | ((payload_read(off + 3) as u32) << 24)
}

fn rd_i32(off: usize) -> i32 {
    rd_u32(off) as i32
}

fn wr_i32(off: usize, value: i32) {
    let v = value as u32;
    payload_write(off, (v & 0xff) as u8);
    payload_write(off + 1, ((v >> 8) & 0xff) as u8);
    payload_write(off + 2, ((v >> 16) & 0xff) as u8);
    payload_write(off + 3, ((v >> 24) & 0xff) as u8);
}

fn payload_eq(off: usize, bytes: &[u8]) -> bool {
    let len = payload_len();
    if off + bytes.len() > len {
        return false;
    }
    let mut i = 0usize;
    while i < bytes.len() {
        if payload_read(off + i) != bytes[i] {
            return false;
        }
        i += 1;
    }
    true
}

fn nonzero_count(off: usize, len: usize) -> u32 {
    let mut count = 0u32;
    let mut i = 0usize;
    while i < len {
        if payload_read(off + i) != 0 {
            count += 1;
        }
        i += 1;
    }
    count
}

fn ps1_frame_checksum_ok(off: usize) -> bool {
    let mut checksum = 0u8;
    let mut i = 0usize;
    while i < PS1_DIR_SIZE - 1 {
        checksum ^= payload_read(off + i);
        i += 1;
    }
    checksum == payload_read(off + PS1_DIR_SIZE - 1)
}

#[derive(Copy, Clone)]
struct SotnEntry {
    present: bool,
    dir_slot: u32,
    save_slot: u32,
    block_offset: usize,
    product_len: usize,
    product: [u8; 20],
    name: [u8; 12],
    level: u32,
    gold: i32,
    hours: u32,
    minutes: u32,
    seconds: u32,
    card_icon: u32,
    rooms: u32,
    percent: u32,
    stage: u32,
    character: u32,
    hp: i32,
    hp_max: i32,
    hearts: i32,
    hearts_max: i32,
    mp: i32,
    mp_max: i32,
    exp: u32,
    kills: i32,
}

const EMPTY_ENTRY: SotnEntry = SotnEntry {
    present: false,
    dir_slot: 0,
    save_slot: 0,
    block_offset: 0,
    product_len: 0,
    product: [0; 20],
    name: [0; 12],
    level: 0,
    gold: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    card_icon: 0,
    rooms: 0,
    percent: 0,
    stage: 0,
    character: 0,
    hp: 0,
    hp_max: 0,
    hearts: 0,
    hearts_max: 0,
    mp: 0,
    mp_max: 0,
    exp: 0,
    kills: 0,
};

#[derive(Copy, Clone)]
struct Analysis {
    supported: bool,
    is_card: bool,
    card_header_checksum: bool,
    dir_checksum_all: bool,
    count: usize,
    entries: [SotnEntry; MAX_ENTRIES],
}

const TITLE_PREFIX: &[u8] = &[
    0x82, 0x62, 0x82, 0x60, 0x82, 0x72, 0x82, 0x73, 0x82, 0x6b, 0x82, 0x64,
    0x82, 0x75, 0x82, 0x60, 0x82, 0x6d, 0x82, 0x68, 0x82, 0x60, 0x81, 0x7c,
];
const MEMCARD_ID_PREFIX: &[u8] = b"BASLUS-00067DRAX";

fn valid_name_bytes(off: usize, len: usize) -> bool {
    let mut saw = false;
    let mut i = 0usize;
    while i < len {
        let c = payload_read(off + i);
        if c != 0 {
            saw = true;
            if !(0x20..=0x7e).contains(&c) {
                return false;
            }
        }
        i += 1;
    }
    saw
}

fn parse_save_block(off: usize, entry: &mut SotnEntry) -> bool {
    if off + PS1_BLOCK_SIZE > payload_len() {
        return false;
    }
    if payload_read(off) != b'S' || payload_read(off + 1) != b'C' || payload_read(off + 2) != 0x13 || payload_read(off + 3) != 0x01 {
        return false;
    }
    if !payload_eq(off + 4, TITLE_PREFIX) {
        return false;
    }
    let info = off + 0x200;
    let status = off + 0x238;
    if rd_u32(info + 0x34) != SAVE_DATA_SIZE {
        return false;
    }
    let info_gold = rd_i32(info + 0x10);
    let status_gold = rd_i32(status + 0x28c);
    let info_level = rd_u32(info + 0x0c);
    let status_level = rd_u32(status + 0x284);
    if info_gold != status_gold || info_level != status_level {
        return false;
    }
    if !(0..=MAX_GOLD).contains(&info_gold) {
        return false;
    }
    if !valid_name_bytes(info, 10) || !valid_name_bytes(status + 0x22c, 12) {
        return false;
    }
    let mut i = 0usize;
    while i < 10 {
        if payload_read(info + i) != payload_read(status + 0x22c + i) {
            return false;
        }
        i += 1;
    }
    let rooms = rd_u16(info + 0x2a) as u32;
    if rooms > 1884 {
        return false;
    }
    let character = rd_u32(info + 0x30);
    if character > 2 {
        return false;
    }

    *entry = EMPTY_ENTRY;
    entry.present = true;
    entry.block_offset = off;
    let mut n = 0usize;
    while n < 12 {
        entry.name[n] = payload_read(info + n);
        n += 1;
    }
    entry.level = info_level;
    entry.gold = info_gold;
    entry.hours = rd_u32(info + 0x14);
    entry.minutes = rd_u32(info + 0x18);
    entry.seconds = rd_u32(info + 0x1c);
    entry.card_icon = rd_u32(info + 0x20);
    entry.stage = rd_u16(info + 0x28) as u32;
    entry.rooms = rooms;
    entry.percent = rooms * 100 / 942;
    entry.character = character;
    entry.hp = rd_i32(status + 0x23c);
    entry.hp_max = rd_i32(status + 0x240);
    entry.hearts = rd_i32(status + 0x244);
    entry.hearts_max = rd_i32(status + 0x248);
    entry.mp = rd_i32(status + 0x24c);
    entry.mp_max = rd_i32(status + 0x250);
    entry.exp = rd_u32(status + 0x288);
    entry.kills = rd_i32(status + 0x290);
    true
}

fn append_entry_from_dir(analysis: &mut Analysis, dir_slot: usize, block_off: usize) {
    if analysis.count >= MAX_ENTRIES {
        return;
    }
    let mut entry = EMPTY_ENTRY;
    if !parse_save_block(block_off, &mut entry) {
        return;
    }
    let dir = dir_slot * PS1_DIR_SIZE;
    entry.dir_slot = dir_slot as u32;
    entry.product_len = 18;
    let mut i = 0usize;
    while i < 18 {
        entry.product[i] = payload_read(dir + 0x0a + i);
        i += 1;
    }
    let tens = payload_read(dir + 0x0a + 16);
    let ones = payload_read(dir + 0x0a + 17);
    if tens.is_ascii_digit() && ones.is_ascii_digit() {
        entry.save_slot = ((tens - b'0') as u32) * 10 + (ones - b'0') as u32 + 1;
    } else {
        entry.save_slot = dir_slot as u32;
    }
    analysis.entries[analysis.count] = entry;
    analysis.count += 1;
}

fn analyze_payload() -> Analysis {
    let mut out = Analysis {
        supported: false,
        is_card: false,
        card_header_checksum: false,
        dir_checksum_all: true,
        count: 0,
        entries: [EMPTY_ENTRY; MAX_ENTRIES],
    };
    let len = payload_len();
    if len == PS1_BLOCK_SIZE {
        let mut entry = EMPTY_ENTRY;
        if parse_save_block(0, &mut entry) {
            entry.save_slot = 1;
            out.entries[0] = entry;
            out.count = 1;
            out.supported = true;
        }
        return out;
    }
    if len != PS1_CARD_SIZE {
        return out;
    }
    out.is_card = true;
    if payload_read(0) != b'M' || payload_read(1) != b'C' {
        return out;
    }
    out.card_header_checksum = ps1_frame_checksum_ok(0);
    let mut dir_slot = 1usize;
    while dir_slot <= PS1_DIR_COUNT {
        let dir = dir_slot * PS1_DIR_SIZE;
        if payload_read(dir) == 0x51 {
            if !ps1_frame_checksum_ok(dir) {
                out.dir_checksum_all = false;
            }
            if rd_u32(dir + 4) == PS1_BLOCK_SIZE as u32
                && rd_u16(dir + 8) == 0xffff
                && payload_eq(dir + 0x0a, MEMCARD_ID_PREFIX)
            {
                let tens = payload_read(dir + 0x0a + 16);
                let ones = payload_read(dir + 0x0a + 17);
                if (b'0'..=b'1').contains(&tens) && ones.is_ascii_digit() {
                    append_entry_from_dir(&mut out, dir_slot, dir_slot * PS1_BLOCK_SIZE);
                }
            }
        }
        dir_slot += 1;
    }
    out.supported = out.count > 0;
    out
}

fn load_payload_from_json(input: &[u8]) -> bool {
    let Some(encoded) = json_string_raw(input, b"payload") else {
        return false;
    };
    base64_decode_to_payload(encoded)
}

fn write_slot_values(w: &mut Writer, analysis: &Analysis) {
    w.bytes(b"\"slotValues\":{");
    let mut i = 0usize;
    while i < analysis.count {
        if i > 0 { w.byte(b','); }
        w.byte(b'"');
        w.u32(analysis.entries[i].save_slot);
        w.bytes(b"\":{\"gold\":");
        w.i32(analysis.entries[i].gold);
        w.byte(b'}');
        i += 1;
    }
    w.byte(b'}');
}

fn write_entry_semantics(w: &mut Writer, entry: &SotnEntry) {
    let block = entry.block_offset;
    let status = block + 0x238;
    w.bytes(b"\"saveSlot\":"); w.u32(entry.save_slot);
    w.bytes(b",\"playerName\":"); w.json_ascii(&entry.name, true, true);
    w.bytes(b",\"level\":"); w.u32(entry.level);
    w.bytes(b",\"gold\":"); w.i32(entry.gold);
    w.bytes(b",\"roomsExplored\":"); w.u32(entry.rooms);
    w.bytes(b",\"castleCompletionPercent\":"); w.u32(entry.percent);
    w.bytes(b",\"playHours\":"); w.u32(entry.hours);
    w.bytes(b",\"playMinutes\":"); w.u32(entry.minutes);
    w.bytes(b",\"playSeconds\":"); w.u32(entry.seconds);
    w.bytes(b",\"stageId\":"); w.u32(entry.stage);
    w.bytes(b",\"characterId\":"); w.u32(entry.character);
    w.bytes(b",\"hp\":"); w.i32(entry.hp);
    w.bytes(b",\"hpMax\":"); w.i32(entry.hp_max);
    w.bytes(b",\"hearts\":"); w.i32(entry.hearts);
    w.bytes(b",\"heartsMax\":"); w.i32(entry.hearts_max);
    w.bytes(b",\"mp\":"); w.i32(entry.mp);
    w.bytes(b",\"mpMax\":"); w.i32(entry.mp_max);
    w.bytes(b",\"exp\":"); w.u32(entry.exp);
    w.bytes(b",\"killCount\":"); w.i32(entry.kills);
    w.bytes(b",\"spellsLearntMask\":"); w.u32(rd_u32(status + 0x238));
    w.bytes(b",\"relicsHex\":"); w.hex_from_payload(status, 30);
    w.bytes(b",\"relicsNonZeroCount\":"); w.u32(nonzero_count(status, 30));
    w.bytes(b",\"spellsHex\":"); w.hex_from_payload(status + 0x1e, 8);
    w.bytes(b",\"equipHandCountHex\":"); w.hex_from_payload(status + 0x26, 169);
    w.bytes(b",\"equipBodyCountHex\":"); w.hex_from_payload(status + 0xcf, 90);
    w.bytes(b",\"equipHandOrderHex\":"); w.hex_from_payload(status + 0x129, 169);
    w.bytes(b",\"equipBodyOrderHex\":"); w.hex_from_payload(status + 0x1d2, 90);
    w.bytes(b",\"equipHandOwnedKinds\":"); w.u32(nonzero_count(status + 0x26, 169));
    w.bytes(b",\"equipBodyOwnedKinds\":"); w.u32(nonzero_count(status + 0xcf, 90));
    w.bytes(b",\"equipmentRawSlots\":"); w.u32_array_from_payload(status + 0x29c, 7);
    w.bytes(b",\"attackHands\":"); w.u32_array_from_payload(status + 0x2b8, 2);
    w.bytes(b",\"defenseEquip\":"); w.i32(rd_i32(status + 0x2c0));
    w.bytes(b",\"castleFlagsHex\":"); w.hex_from_payload(block + 0x6c8, 0x300);
    w.bytes(b",\"castleFlagsNonZeroBytes\":"); w.u32(nonzero_count(block + 0x6c8, 0x300));
    w.bytes(b",\"castleMapHex\":"); w.hex_from_payload(block + 0x9c8, 0x800);
    w.bytes(b",\"castleMapNonZeroBytes\":"); w.u32(nonzero_count(block + 0x9c8, 0x800));
    if entry.product_len > 0 {
        w.bytes(b",\"memcardFileName\":"); w.json_ascii(&entry.product[..entry.product_len], false, true);
        w.bytes(b",\"memoryCardDirectorySlot\":"); w.u32(entry.dir_slot);
    }
}

fn write_capabilities() -> u64 {
    let Some(mut w) = Writer::new(512) else { return 0; };
    w.bytes(b"{\"capabilities\":{\"abiVersion\":\"rsm-wasm-json-v1\",\"commands\":[\"capabilities\",\"parse\",\"readCheats\",\"applyCheats\"],\"operations\":[\"moduleNumber\"],\"editableFields\":1},\"supported\":true}");
    w.finish()
}

fn write_parse(input: &[u8]) -> u64 {
    if !load_payload_from_json(input) {
        return write_error(b"payload missing or not supported base64");
    }
    let analysis = analyze_payload();
    if !analysis.supported {
        return write_error(b"expected a US Castlevania: Symphony of the Night PS1 save block or memory card");
    }
    let Some(mut w) = Writer::new(32768) else { return 0; };
    w.bytes(b"{\"supported\":true,\"parserLevel\":\"semantic\",\"parserId\":\"sotn-psx-save\",\"validatedSystem\":\"psx\",\"validatedGameId\":\"psx/castlevania-symphony-of-the-night\",\"validatedGameTitle\":\"Castlevania: Symphony of the Night\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[");
    if analysis.is_card {
        w.bytes(b"\"validated 128 KiB PlayStation memory card header\",\"matched BASLUS-00067DRAXnn directory entry and one-block 8192-byte save payload\"");
    } else {
        w.bytes(b"\"validated standalone 8192-byte one-block PS1 save payload\"");
    }
    w.bytes(b",\"validated SOTN save header magic SC 0x13 0x01, US title prefix, SaveInfo size 0x11CC, and mirrored gold/level fields\",\"sotn-decomp StoreSaveData/ApplySaveData structure used for offsets\"],\"warnings\":[");
    let mut wrote_warning = false;
    if analysis.count > 1 {
        w.bytes(b"\"Multiple SOTN saves found; choose the intended save slot before applying edits.\"");
        wrote_warning = true;
    }
    if analysis.is_card && (!analysis.card_header_checksum || !analysis.dir_checksum_all) {
        if wrote_warning { w.byte(b','); }
        w.bytes(b"\"PS1 directory/header checksum anomaly detected; gameplay payload was not modified during parse.\"");
    }
    w.bytes(b"],\"payloadSizeBytes\":"); w.u32(payload_len() as u32);
    w.bytes(b",\"slotCount\":"); w.u32(analysis.count as u32);
    w.bytes(b",\"activeSlotIndexes\":[");
    let mut i = 0usize;
    while i < analysis.count {
        if i > 0 { w.byte(b','); }
        w.u32(analysis.entries[i].save_slot);
        i += 1;
    }
    w.bytes(b"],\"checksumValid\":");
    w.bool(!analysis.is_card || (analysis.card_header_checksum && analysis.dir_checksum_all));
    w.bytes(b",\"semanticFields\":{\"container\":\"");
    w.bytes(if analysis.is_card { b"ps1-memory-card" } else { b"ps1-single-save-block" });
    w.bytes(b"\",\"sotnEntryCount\":"); w.u32(analysis.count as u32);
    w.byte(b',');
    write_entry_semantics(&mut w, &analysis.entries[0]);
    w.bytes(b",\"editableFields\":[\"gold\"]}}");
    w.finish()
}

fn write_read_cheats(input: &[u8]) -> u64 {
    if !load_payload_from_json(input) {
        return write_error(b"payload missing or not supported base64");
    }
    let analysis = analyze_payload();
    if !analysis.supported {
        return write_error(b"SOTN save not found");
    }
    let Some(mut w) = Writer::new(8192) else { return 0; };
    w.bytes(b"{\"supported\":true,\"gameId\":\"psx/castlevania-symphony-of-the-night\",\"systemSlug\":\"psx\",\"editorId\":\"sotn-psx-save\",\"adapterId\":\"sotn-psx-save\",\"packId\":\"psx--castlevania-symphony-of-the-night\",\"title\":\"Castlevania: Symphony of the Night\",\"availableCount\":2,");
    if analysis.count == 1 {
        w.bytes(b"\"values\":{\"gold\":");
        w.i32(analysis.entries[0].gold);
        w.bytes(b"},");
    }
    write_slot_values(&mut w, &analysis);
    w.byte(b'}');
    w.finish()
}

fn slot_matches(slot_id: &[u8], save_slot: u32) -> bool {
    if slot_id.is_empty() {
        return false;
    }
    let mut value = 0u32;
    for c in slot_id {
        if !c.is_ascii_digit() {
            return false;
        }
        value = value.saturating_mul(10).saturating_add((*c - b'0') as u32);
    }
    value == save_slot
}

fn write_apply_cheats(input: &[u8]) -> u64 {
    if !load_payload_from_json(input) {
        return write_error(b"payload missing or not supported base64");
    }
    let Some(gold) = json_i32_field(input, b"gold") else {
        return write_error(b"gold update is required");
    };
    if !(0..=MAX_GOLD).contains(&gold) {
        return write_error(b"gold must be between 0 and 999999");
    }
    let analysis = analyze_payload();
    if !analysis.supported {
        return write_error(b"SOTN save not found");
    }
    let slot_id = json_string_raw(input, b"slotId").unwrap_or(&[]);
    let mut target: Option<usize> = None;
    if analysis.count == 1 && slot_id.is_empty() {
        target = Some(0);
    } else {
        let mut i = 0usize;
        while i < analysis.count {
            if slot_matches(slot_id, analysis.entries[i].save_slot) {
                target = Some(i);
                break;
            }
            i += 1;
        }
    }
    let Some(target_index) = target else {
        return write_error(b"matching save slot was not found");
    };
    let off = analysis.entries[target_index].block_offset;
    wr_i32(off + 0x200 + 0x10, gold);
    wr_i32(off + 0x238 + 0x28c, gold);

    let Some(mut w) = Writer::new(OUTPUT_CAP) else { return 0; };
    w.bytes(b"{\"payload\":\"");
    write_base64_payload(&mut w, payload_len());
    w.bytes(b"\",\"changed\":{\"gold\":");
    w.i32(gold);
    w.bytes(b",\"saveSlot\":");
    w.u32(analysis.entries[target_index].save_slot);
    w.bytes(b"},\"integritySteps\":[\"updated SaveInfo.gold at +0x210 and PlayerStatus.gold at +0x4C4 inside the selected 8192-byte SOTN save block\",\"no SOTN gameplay checksum is present in StoreSaveData/ApplySaveData; PS1 directory frames were preserved\"]}");
    w.finish()
}
