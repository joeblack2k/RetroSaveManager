# Castlevania: Symphony of the Night PS1 Module

This module validates US PlayStation Castlevania: Symphony of the Night saves, reports detailed read-only `SaveData` fields, and exposes one safe edit: gold.

Supported payloads:

- 131072-byte PlayStation memory card images containing a one-block `BASLUS-00067DRAXnn` save.
- 8192-byte standalone SOTN save blocks beginning with `SC 13 01`.

Evidence:

- `sotn-decomp` defines the US memory-card id as `BASLUS-00067DRAX00`, writes slot digits into the last two characters, and stores one 8192-byte block.
- `SaveData` is size `0x11CC`; `StoreSaveData` writes `SaveInfo.gold` from `g_Status.gold`, then stores the full `PlayerStatus`; `ApplySaveData` restores the full `PlayerStatus` and validates only `SaveInfo.saveSize`.
- FantasyAnime NTSC PS1 `.mcr` samples validate the directory id, SOTN header, duplicated level/gold values, player name, room count, and save size across early, mid, inverse-castle, and endgame saves.

Gold writes update both known copies inside the selected 8192-byte block:

- `SaveInfo.gold` at block offset `0x210`.
- `PlayerStatus.gold` at block offset `0x4C4`.

Read-only parser details include HP, MP, hearts, level, room count, computed castle percentage, stage id, relic bytes, spells, inventory count/order arrays, equipment raw slots, attack hands, defense equip, castle flags, and castle map bytes. Castle flags are read from `SaveData + 0x6C8` and castle map bytes from `SaveData + 0x9C8`, the offsets implied by the decomp struct layout.

The module does not expose HP, MP, map, inventory, relics, equipment, rooms, level, stage, castle flag, or castle map writes. Those fields are reported as read-only parser details only because safe static ranges, menu side effects, and complete semantic repair rules were not proven for this intake.
