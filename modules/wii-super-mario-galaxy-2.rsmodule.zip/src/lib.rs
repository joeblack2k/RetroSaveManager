#![no_std]

use core::panic::PanicInfo;
use core::ptr;
use core::slice;

const DATA_BIN_SIZE: usize = 75200;
const RAW_GAME_DATA_SIZE: usize = 0x30A0;
const RAW_GAME_DATA_VERSION: u32 = 3;
const BACKUP_HEADER_OFFSET: usize = 0xF0C0;
const FILE_HEADER_OFFSET: usize = 0xF140;
const TITLE_CODE_OFFSET: usize = BACKUP_HEADER_OFFSET + 0x64;
const OUTPUT_CAP: usize = 144 * 1024;
const RAW_INDEX_OFFSET: usize = 0x10;
const RAW_INDEX_ENTRY_SIZE: usize = 0x10;
const GAME_HOLDER_SIZE: usize = 0xF80;
const CONFIG_HOLDER_SIZE: usize = 0x60;
const SYSCONF_HOLDER_SIZE: usize = 0x80;
const MAX_USER_SLOTS: usize = 6;
const MAX_CONFIG_SLOTS: usize = 6;

const CHUNK_HASH_CONTENT_0X20: u32 = 0x20;
const CHUNK_HASH_EVENT_FLAG: u32 = 0x65020442;
const CHUNK_HASH_EVENT_VALUE: u32 = 0x564C4531;
const CHUNK_HASH_TICO_FAT: u32 = 0x8F32A6A4;
const CHUNK_HASH_WORLD_MAP: u32 = 0x12DC670E;
const CHUNK_HASH_CONFIG_CREATE: u32 = 0x2432DA;
const CHUNK_HASH_CONFIG_MII: u32 = 0x2836E9;
const CHUNK_HASH_ONE: u32 = 0x1;
const CHUNK_HASH_SYSCONF: u32 = 0x3;

const ATTR_PLAYER_LEFT: u16 = 0x4ED5;
const ATTR_STOCKED_STAR_PIECE_NUM: u16 = 0xE352;
const ATTR_STOCKED_COIN_NUM: u16 = 0x450D;
const ATTR_LAST_1UP_COIN_NUM: u16 = 0x23EC;
const ATTR_FLAG: u16 = 0x7579;
const ATTR_DATA_SIZE: u16 = 0x0658;
const ATTR_SCENARIO_NUM: u16 = 0x6729;
const ATTR_GALAXY_STATE: u16 = 0xACB4;
const ATTR_BANK_STAR_PIECE_NUM: u16 = 0x3D13;
const ATTR_BANK_STAR_PIECE_MAX: u16 = 0x36F1;
const ATTR_GIFTED_PLAYER_LEFT: u16 = 0x3044;

static SAMPLE_20695: &[u8; DATA_BIN_SIZE] = include_bytes!("samples/smg2-20695-sb4e.bin");
static SAMPLE_20827: &[u8; DATA_BIN_SIZE] = include_bytes!("samples/smg2-20827-sb4e.bin");
static SAMPLE_20813: &[u8; DATA_BIN_SIZE] = include_bytes!("samples/smg2-20813-sb4p.bin");
static SAMPLE_24225: &[u8; DATA_BIN_SIZE] = include_bytes!("samples/smg2-24225-sb4p.bin");

extern "C" {
    static __heap_base: u8;
}

static mut HEAP_OFFSET: usize = 0;

#[panic_handler]
fn panic(_: &PanicInfo) -> ! {
    loop {}
}

#[derive(Clone, Copy)]
struct Template {
    id: &'static [u8],
    title_code: [u8; 4],
    sha256: &'static [u8],
    sample: &'static [u8; DATA_BIN_SIZE],
}

#[derive(Clone, Copy)]
struct UserSlotSummary {
    present: bool,
    slot: usize,
    chunk_count: usize,
    has_play: bool,
    lives: usize,
    stocked_star_bits: usize,
    stocked_coins: usize,
    last_one_up_coins: usize,
    player_luigi: bool,
    has_galaxy: bool,
    galaxy_count: usize,
    open_galaxy_count: usize,
    power_star_count: usize,
    bronze_star_count: usize,
    comet_medal_count: usize,
    visited_scenario_count: usize,
    ghost_luigi_scenario_count: usize,
    standby_luigi_scenario_count: usize,
    event_flag_count: usize,
    enabled_event_flag_count: usize,
    event_value_count: usize,
    nonzero_event_value_count: usize,
    hungry_luma_star_bits: usize,
    coin_luma_galaxy_count: usize,
    world_no: usize,
    world_map_present: bool,
}

#[derive(Clone, Copy)]
struct ConfigSlotSummary {
    present: bool,
    slot: usize,
    chunk_count: usize,
    created_present: bool,
    created: bool,
    mii_present: bool,
    mii_choice_flag: bool,
    icon_id: usize,
    misc_present: bool,
}

#[derive(Clone, Copy)]
struct SysconfSummary {
    present: bool,
    chunk_count: usize,
    bank_star_bits_present: bool,
    bank_star_bits: usize,
    bank_star_bits_max: usize,
    gifted_lives_present: bool,
    gifted_lives: usize,
}

struct RawGameDataAnalysis {
    checksum: u32,
    entry_count: usize,
    user_file_count: usize,
    config_file_count: usize,
    sysconf_present: bool,
    users: [UserSlotSummary; MAX_USER_SLOTS],
    configs: [ConfigSlotSummary; MAX_CONFIG_SLOTS],
    sysconf: SysconfSummary,
    total_power_stars: usize,
    total_bronze_stars: usize,
    total_comet_medals: usize,
    total_enabled_event_flags: usize,
}

const EMPTY_USER_SLOT: UserSlotSummary = UserSlotSummary {
    present: false,
    slot: 0,
    chunk_count: 0,
    has_play: false,
    lives: 0,
    stocked_star_bits: 0,
    stocked_coins: 0,
    last_one_up_coins: 0,
    player_luigi: false,
    has_galaxy: false,
    galaxy_count: 0,
    open_galaxy_count: 0,
    power_star_count: 0,
    bronze_star_count: 0,
    comet_medal_count: 0,
    visited_scenario_count: 0,
    ghost_luigi_scenario_count: 0,
    standby_luigi_scenario_count: 0,
    event_flag_count: 0,
    enabled_event_flag_count: 0,
    event_value_count: 0,
    nonzero_event_value_count: 0,
    hungry_luma_star_bits: 0,
    coin_luma_galaxy_count: 0,
    world_no: 0,
    world_map_present: false,
};

const EMPTY_CONFIG_SLOT: ConfigSlotSummary = ConfigSlotSummary {
    present: false,
    slot: 0,
    chunk_count: 0,
    created_present: false,
    created: false,
    mii_present: false,
    mii_choice_flag: false,
    icon_id: 0,
    misc_present: false,
};

const EMPTY_SYSCONF: SysconfSummary = SysconfSummary {
    present: false,
    chunk_count: 0,
    bank_star_bits_present: false,
    bank_star_bits: 0,
    bank_star_bits_max: 0,
    gifted_lives_present: false,
    gifted_lives: 0,
};

const TEMPLATES: [Template; 4] = [
    Template {
        id: b"gamefaqs-20695-sb4e",
        title_code: *b"SB4E",
        sha256: b"66866f9d4951ddf8dc428ee326f62a425ec0b844362bc5b301c333f2d46655d3",
        sample: SAMPLE_20695,
    },
    Template {
        id: b"gamefaqs-20827-sb4e",
        title_code: *b"SB4E",
        sha256: b"a44c1e29c5365e1870b029f083029ca346570aef2af7aa67a21922d2ea0c49c4",
        sample: SAMPLE_20827,
    },
    Template {
        id: b"gamefaqs-20813-sb4p",
        title_code: *b"SB4P",
        sha256: b"a1c8d2023685c4a32506ce98746956d95fa75412728a06044b5291aac77d50b5",
        sample: SAMPLE_20813,
    },
    Template {
        id: b"gamefaqs-24225-sb4p",
        title_code: *b"SB4P",
        sha256: b"feca26ceeb4cc65d96acb110c4f156ee6428d5708e4db25e45fa23d5ed628584",
        sample: SAMPLE_24225,
    },
];

#[no_mangle]
pub extern "C" fn rsm_alloc(len: i32) -> i32 {
    if len < 0 {
        return 0;
    }
    let len = len as usize;
    unsafe {
        if HEAP_OFFSET == 0 {
            HEAP_OFFSET = heap_base();
        }
        let absolute = (HEAP_OFFSET + 7) & !7;
        let Some(end) = absolute.checked_add((len + 7) & !7) else {
            return 0;
        };
        HEAP_OFFSET = end;
        absolute as i32
    }
}

#[no_mangle]
pub extern "C" fn rsm_call(
    command_ptr: i32,
    command_len: i32,
    input_ptr: i32,
    input_len: i32,
) -> u64 {
    let Some(command) = read_bytes(command_ptr, command_len) else {
        return write_unsupported(b"bad command pointer");
    };
    let input = read_bytes(input_ptr, input_len).unwrap_or(&[]);
    if command == b"capabilities" {
        write_capabilities()
    } else if command == b"parse" {
        write_parse(input)
    } else if command == b"readCheats" {
        write_read_cheats(input)
    } else if command == b"applyCheats" {
        write_apply_cheats(input)
    } else {
        write_unsupported(b"unsupported command")
    }
}

fn heap_base() -> usize {
    ptr::addr_of!(__heap_base) as usize
}

fn read_bytes(ptr: i32, len: i32) -> Option<&'static [u8]> {
    if ptr < 0 || len < 0 {
        return None;
    }
    let ptr = ptr as usize;
    let len = len as usize;
    let end = ptr.checked_add(len)?;
    let base = heap_base();
    if ptr < base || end < ptr {
        return None;
    }
    unsafe { Some(slice::from_raw_parts(ptr as *const u8, len)) }
}

struct Writer {
    ptr: usize,
    len: usize,
    cap: usize,
}

impl Writer {
    fn new() -> Option<Writer> {
        let ptr = rsm_alloc(OUTPUT_CAP as i32);
        if ptr <= 0 {
            return None;
        }
        Some(Writer {
            ptr: ptr as usize,
            len: 0,
            cap: OUTPUT_CAP,
        })
    }

    fn finish(self) -> u64 {
        ((self.ptr as u64) << 32) | (self.len as u64)
    }

    fn byte(&mut self, value: u8) {
        if self.len >= self.cap {
            return;
        }
        unsafe {
            ptr::write((self.ptr + self.len) as *mut u8, value);
        }
        self.len += 1;
    }

    fn bytes(&mut self, values: &[u8]) {
        for value in values {
            self.byte(*value);
        }
    }

    fn bool(&mut self, value: bool) {
        self.bytes(if value { b"true" } else { b"false" });
    }

    fn usize(&mut self, mut value: usize) {
        let mut tmp = [0u8; 20];
        let mut idx = tmp.len();
        if value == 0 {
            self.byte(b'0');
            return;
        }
        while value > 0 {
            idx -= 1;
            tmp[idx] = b'0' + (value % 10) as u8;
            value /= 10;
        }
        self.bytes(&tmp[idx..]);
    }

    fn hex_u32_string(&mut self, value: u32) {
        const HEX: &[u8; 16] = b"0123456789ABCDEF";
        self.byte(b'"');
        self.bytes(b"0x");
        let mut shift = 28i32;
        while shift >= 0 {
            self.byte(HEX[((value >> shift) & 0x0F) as usize]);
            shift -= 4;
        }
        self.byte(b'"');
    }

    fn json_string(&mut self, value: &[u8]) {
        self.byte(b'"');
        for b in value {
            match *b {
                b'"' => self.bytes(br#"\""#),
                b'\\' => self.bytes(br#"\\"#),
                b'\n' => self.bytes(br#"\n"#),
                b'\r' => self.bytes(br#"\r"#),
                b'\t' => self.bytes(br#"\t"#),
                other => self.byte(other),
            }
        }
        self.byte(b'"');
    }
}

fn write_capabilities() -> u64 {
    let Some(mut w) = Writer::new() else {
        return 0;
    };
    w.bytes(b"{\"capabilities\":{\"abiVersion\":\"rsm-wasm-json-v1\",\"commands\":[\"capabilities\",\"parse\",\"readCheats\",\"applyCheats\"],\"operations\":[\"moduleTemplate\"],\"editableFields\":1,\"notes\":\"Official Wii data.bin is encrypted; raw decrypted GameData.bin is parsed read-only, while only verified whole-save data.bin template replacement is editable.\"},\"supported\":true}");
    w.finish()
}

fn write_parse(input: &[u8]) -> u64 {
    let Some(payload) = payload_from_input(input) else {
        return write_unsupported(
            b"expected base64 Wii data.bin or raw Super Mario Galaxy 2 GameData.bin payload",
        );
    };
    if decoded_base64_len(payload.encoded) == Some(DATA_BIN_SIZE) {
        let Some(analysis) = analyze_data_bin(payload) else {
            return write_unsupported(b"not a supported Super Mario Galaxy 2 data.bin");
        };
        return write_parse_data_bin(analysis);
    }
    if decoded_base64_len(payload.encoded) == Some(RAW_GAME_DATA_SIZE) {
        let Some(analysis) = analyze_raw_game_data(payload) else {
            return write_unsupported(b"not a valid raw Super Mario Galaxy 2 GameData.bin");
        };
        return write_parse_raw_game_data(&analysis);
    }

    write_unsupported(b"unsupported Super Mario Galaxy 2 payload size")
}

fn write_parse_data_bin(analysis: Analysis) -> u64 {
    let Some(mut w) = Writer::new() else {
        return 0;
    };
    w.bytes(b"{\"supported\":true,\"parserLevel\":\"structural\",\"parserId\":\"smg2-data-bin-wasm\",\"validatedSystem\":\"wii\",\"validatedGameId\":\"wii/super-mario-galaxy-2\",\"validatedGameTitle\":\"Super Mario Galaxy 2\",\"trustLevel\":\"module-structure-verified\",\"evidence\":[\"validated 75200-byte Wii SD data.bin export\",\"validated Wii backup header at 0xF0C0\",\"validated file header at 0xF140\",\"validated embedded GameData.bin file entry\",\"validated Super Mario Galaxy 2 title code ");
    w.bytes(&analysis.title_code);
    w.bytes(b"\"");
    if let Some(template) = analysis.template {
        w.bytes(b",\"payload matches embedded public template ");
        w.bytes(template.id);
        w.bytes(b"\"");
    }
    w.bytes(b"],\"warnings\":[\"Official Wii data.bin exports keep GameData.bin encrypted; granular lives, Star Bits, Power Stars, comet medals, and galaxy flags are intentionally not exposed.\",\"Template replacement is limited to exact public data.bin samples and should only be applied to matching title-code regions.\"],\"payloadSizeBytes\":");
    w.usize(DATA_BIN_SIZE);
    w.bytes(b",\"slotCount\":1,\"activeSlotIndexes\":[0],\"semanticFields\":{\"containerKind\":\"wii-data-bin\",\"titleCode\":");
    w.json_string(&analysis.title_code);
    w.bytes(b",\"embeddedFileName\":\"GameData.bin\",\"embeddedFileSize\":");
    w.usize(analysis.file_size as usize);
    w.bytes(b",\"fileCount\":");
    w.usize(analysis.file_count as usize);
    w.bytes(b",\"declaredDataSize\":");
    w.usize(analysis.declared_data_size as usize);
    w.bytes(b",\"backupHeaderOffset\":\"0xF0C0\",\"fileHeaderOffset\":\"0xF140\",\"encrypted\":true,\"certificateChainPresent\":");
    w.bool(analysis.certificate_present);
    w.bytes(b",\"templateReplacementAvailable\":");
    w.bool(template_available_for_title(analysis.title_code));
    w.bytes(b",\"currentPublicTemplateId\":");
    if let Some(template) = analysis.template {
        w.json_string(template.id);
    } else {
        w.bytes(b"null");
    }
    w.bytes(b",\"editableFields\":\"verified-public-data-bin-template-only\"}}");
    w.finish()
}

fn write_parse_raw_game_data(analysis: &RawGameDataAnalysis) -> u64 {
    let Some(mut w) = Writer::new() else {
        return 0;
    };
    w.bytes(b"{\"supported\":true,\"parserLevel\":\"semantic\",\"parserId\":\"smg2-data-bin-wasm\",\"validatedSystem\":\"wii\",\"validatedGameId\":\"wii/super-mario-galaxy-2\",\"validatedGameTitle\":\"Super Mario Galaxy 2\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[\"validated raw decrypted Super Mario Galaxy 2 GameData.bin\",\"validated GameData.bin version 3\",\"validated checksum\",\"validated entry index\",\"parsed read-only PLAY/GALA/config chunks\"],\"warnings\":[\"Raw GameData.bin semantic fields are read-only; this module does not expose lives, Star Bits, coins, Power Stars, comet medals, galaxy flags, Mii/config, or raw GameData.bin edits as cheats.\"],\"payloadSizeBytes\":");
    w.usize(RAW_GAME_DATA_SIZE);
    w.bytes(b",\"slotCount\":");
    w.usize(analysis.user_file_count);
    w.bytes(b",\"activeSlotIndexes\":[");
    write_active_user_slots(&mut w, analysis);
    w.bytes(b"],\"checksumValid\":true,\"semanticFields\":{\"containerKind\":\"smg2-raw-gamedata\",\"encrypted\":false,\"readOnlyGameData\":true,\"editableFields\":\"none-for-raw-gamedata\",\"version\":3,\"entryCount\":");
    w.usize(analysis.entry_count);
    w.bytes(b",\"checksum\":");
    w.hex_u32_string(analysis.checksum);
    w.bytes(b",\"userFileCount\":");
    w.usize(analysis.user_file_count);
    w.bytes(b",\"configFileCount\":");
    w.usize(analysis.config_file_count);
    w.bytes(b",\"sysconfPresent\":");
    w.bool(analysis.sysconf_present);
    w.bytes(b",\"totals\":{\"powerStars\":");
    w.usize(analysis.total_power_stars);
    w.bytes(b",\"bronzeStars\":");
    w.usize(analysis.total_bronze_stars);
    w.bytes(b",\"cometMedals\":");
    w.usize(analysis.total_comet_medals);
    w.bytes(b",\"enabledEventFlags\":");
    w.usize(analysis.total_enabled_event_flags);
    w.bytes(b"},\"userSlots\":[");
    write_user_slots(&mut w, analysis);
    w.bytes(b"],\"configSlots\":[");
    write_config_slots(&mut w, analysis);
    w.bytes(b"],\"sysconf\":");
    write_sysconf(&mut w, analysis.sysconf);
    w.bytes(b"}}");
    w.finish()
}

fn write_read_cheats(input: &[u8]) -> u64 {
    let template = payload_from_input(input)
        .and_then(analyze_data_bin)
        .and_then(|analysis| analysis.template);
    let Some(mut w) = Writer::new() else {
        return 0;
    };
    w.bytes(b"{\"supported\":true,\"gameId\":\"wii/super-mario-galaxy-2\",\"systemSlug\":\"wii\",\"editorId\":\"smg2-data-bin-wasm\",\"adapterId\":\"smg2-data-bin-wasm\",\"packId\":\"wii--super-mario-galaxy-2\",\"title\":\"Super Mario Galaxy 2\",\"availableCount\":1,\"values\":{\"templateId\":");
    if let Some(template) = template {
        w.json_string(template.id);
    } else {
        w.bytes(b"\"none\"");
    }
    w.bytes(b"}}");
    w.finish()
}

fn write_apply_cheats(input: &[u8]) -> u64 {
    let Some(payload) = payload_from_input(input) else {
        return write_unsupported(b"payload missing");
    };
    let Some(analysis) = analyze_data_bin(payload) else {
        return write_unsupported(b"not a supported Super Mario Galaxy 2 data.bin");
    };
    let Some((updates_start, updates_len)) = json_last_object_field(input, b"updates") else {
        return write_unchanged(payload.encoded, b"no template update requested");
    };
    let updates = &input[updates_start..updates_start + updates_len];
    let Some((id_start, id_len)) = json_string_field(updates, b"templateId") else {
        return write_unchanged(payload.encoded, b"no template update requested");
    };
    let template_id = &updates[id_start..id_start + id_len];
    if template_id == b"none" {
        return write_unchanged(payload.encoded, b"kept current save");
    }
    let Some(template) = find_template(template_id) else {
        return write_unsupported(b"unknown public template id");
    };
    if template.title_code != analysis.title_code {
        return write_unsupported(b"template title code does not match current save title code");
    }

    let Some(mut w) = Writer::new() else {
        return 0;
    };
    w.bytes(b"{\"payload\":\"");
    write_base64(&mut w, template.sample);
    w.bytes(b"\",\"changed\":{\"templateId\":");
    w.json_string(template.id);
    w.bytes(b",\"templateTitleCode\":");
    w.json_string(&template.title_code);
    w.bytes(b",\"templateSha256\":");
    w.json_string(template.sha256);
    w.bytes(b"},\"integritySteps\":[\"replaced full encrypted Wii data.bin with exact verified public sample\",\"validated template title code matches current save title code\",\"preserved Wii export structure without raw hex writes or decrypted-field guesses\"]}");
    w.finish()
}

fn write_unchanged(encoded_payload: &[u8], reason: &[u8]) -> u64 {
    let Some(mut w) = Writer::new() else {
        return 0;
    };
    w.bytes(b"{\"payload\":\"");
    w.bytes(encoded_payload);
    w.bytes(b"\",\"changed\":{},\"integritySteps\":[");
    w.json_string(reason);
    w.bytes(b"]}");
    w.finish()
}

fn write_unsupported(message: &[u8]) -> u64 {
    let Some(mut w) = Writer::new() else {
        return 0;
    };
    w.bytes(b"{\"supported\":false,\"error\":");
    w.json_string(message);
    w.bytes(b"}");
    w.finish()
}

struct Analysis {
    title_code: [u8; 4],
    file_count: u32,
    declared_data_size: u32,
    file_size: u32,
    certificate_present: bool,
    template: Option<Template>,
}

#[derive(Clone, Copy)]
struct EncodedPayload<'a> {
    encoded: &'a [u8],
}

fn analyze_data_bin(payload: EncodedPayload<'_>) -> Option<Analysis> {
    if decoded_base64_len(payload.encoded)? != DATA_BIN_SIZE {
        return None;
    }
    if read_be_u32(payload, BACKUP_HEADER_OFFSET)? != 0x70 {
        return None;
    }
    if !has_bytes(payload, BACKUP_HEADER_OFFSET + 4, b"Bk\0\x01") {
        return None;
    }
    let file_count = read_be_u32(payload, BACKUP_HEADER_OFFSET + 0x0C)?;
    if file_count != 1 {
        return None;
    }
    let declared_data_size = read_be_u32(payload, BACKUP_HEADER_OFFSET + 0x10)?;
    if declared_data_size != 0x3140 {
        return None;
    }
    if read_be_u32(payload, FILE_HEADER_OFFSET)? != 0x03ADF17E {
        return None;
    }
    let file_size = read_be_u32(payload, FILE_HEADER_OFFSET + 4)?;
    if file_size != 0x30A0 {
        return None;
    }
    if !has_bytes(payload, FILE_HEADER_OFFSET + 0x0B, b"GameData.bin\0") {
        return None;
    }
    let title_code = [
        decoded_byte_at(payload.encoded, TITLE_CODE_OFFSET)?,
        decoded_byte_at(payload.encoded, TITLE_CODE_OFFSET + 1)?,
        decoded_byte_at(payload.encoded, TITLE_CODE_OFFSET + 2)?,
        decoded_byte_at(payload.encoded, TITLE_CODE_OFFSET + 3)?,
    ];
    if !is_smg2_title_code(title_code) {
        return None;
    }
    Some(Analysis {
        title_code,
        file_count,
        declared_data_size,
        file_size,
        certificate_present: contains(payload, b"Root-CA") || contains(payload, b"AP000"),
        template: matching_template(payload),
    })
}

fn payload_from_input(input: &[u8]) -> Option<EncodedPayload<'_>> {
    let (start, len) = json_string_field(input, b"payload")?;
    let encoded = &input[start..start + len];
    let decoded_len = decoded_base64_len(encoded)?;
    if decoded_len != DATA_BIN_SIZE && decoded_len != RAW_GAME_DATA_SIZE {
        return None;
    }
    Some(EncodedPayload { encoded })
}

fn is_smg2_title_code(code: [u8; 4]) -> bool {
    code == *b"SB4E" || code == *b"SB4P" || code == *b"SB4J" || code == *b"SB4K"
}

fn template_available_for_title(code: [u8; 4]) -> bool {
    let mut idx = 0;
    while idx < TEMPLATES.len() {
        if TEMPLATES[idx].title_code == code {
            return true;
        }
        idx += 1;
    }
    false
}

fn matching_template(payload: EncodedPayload<'_>) -> Option<Template> {
    let mut idx = 0;
    while idx < TEMPLATES.len() {
        let template = TEMPLATES[idx];
        if decoded_eq(payload, template.sample) {
            return Some(template);
        }
        idx += 1;
    }
    None
}

fn find_template(id: &[u8]) -> Option<Template> {
    let mut idx = 0;
    while idx < TEMPLATES.len() {
        let template = TEMPLATES[idx];
        if id == template.id {
            return Some(template);
        }
        idx += 1;
    }
    None
}

fn analyze_raw_game_data(payload: EncodedPayload<'_>) -> Option<RawGameDataAnalysis> {
    if decoded_base64_len(payload.encoded)? != RAW_GAME_DATA_SIZE {
        return None;
    }
    let stored_checksum = read_be_u32(payload, 0)?;
    if read_be_u32(payload, 4)? != RAW_GAME_DATA_VERSION {
        return None;
    }
    let entry_count = read_be_u32(payload, 8)? as usize;
    if entry_count == 0 || entry_count > 14 {
        return None;
    }
    if read_be_u32(payload, 12)? as usize != RAW_GAME_DATA_SIZE {
        return None;
    }
    if raw_game_data_checksum(payload)? != stored_checksum {
        return None;
    }

    let index_end = RAW_INDEX_OFFSET + entry_count * RAW_INDEX_ENTRY_SIZE;
    if index_end >= RAW_GAME_DATA_SIZE {
        return None;
    }

    let mut offsets = [0usize; 14];
    let mut kinds = [0u8; 14];
    let mut slots = [0usize; 14];
    let mut user_mask = 0u8;
    let mut config_mask = 0u8;
    let mut sysconf_seen = false;
    let mut user_file_count = 0usize;
    let mut config_file_count = 0usize;
    let mut last_offset = index_end;

    let mut idx = 0usize;
    while idx < entry_count {
        let entry = RAW_INDEX_OFFSET + idx * RAW_INDEX_ENTRY_SIZE;
        let offset = read_be_u32(payload, entry + 12)? as usize;
        if offset < index_end || offset >= RAW_GAME_DATA_SIZE || offset < last_offset {
            return None;
        }
        last_offset = offset;
        offsets[idx] = offset;

        if let Some(slot) = entry_slot(payload, entry, b"user") {
            let bit = 1u8 << (slot - 1);
            if user_mask & bit != 0 {
                return None;
            }
            user_mask |= bit;
            user_file_count += 1;
            kinds[idx] = 1;
            slots[idx] = slot;
        } else if let Some(slot) = entry_slot(payload, entry, b"config") {
            let bit = 1u8 << (slot - 1);
            if config_mask & bit != 0 {
                return None;
            }
            config_mask |= bit;
            config_file_count += 1;
            kinds[idx] = 2;
            slots[idx] = slot;
        } else if entry_name_is(payload, entry, b"sysconf") {
            if sysconf_seen {
                return None;
            }
            sysconf_seen = true;
            kinds[idx] = 3;
        } else {
            return None;
        }
        idx += 1;
    }
    if user_file_count == 0 {
        return None;
    }

    let mut analysis = RawGameDataAnalysis {
        checksum: stored_checksum,
        entry_count,
        user_file_count,
        config_file_count,
        sysconf_present: sysconf_seen,
        users: [EMPTY_USER_SLOT; MAX_USER_SLOTS],
        configs: [EMPTY_CONFIG_SLOT; MAX_CONFIG_SLOTS],
        sysconf: EMPTY_SYSCONF,
        total_power_stars: 0,
        total_bronze_stars: 0,
        total_comet_medals: 0,
        total_enabled_event_flags: 0,
    };

    idx = 0;
    while idx < entry_count {
        let offset = offsets[idx];
        let end = if idx + 1 < entry_count {
            offsets[idx + 1]
        } else {
            RAW_GAME_DATA_SIZE
        };
        if end <= offset {
            return None;
        }
        match kinds[idx] {
            1 => {
                let slot = slots[idx];
                let mut summary = EMPTY_USER_SLOT;
                summary.present = true;
                summary.slot = slot;
                if !parse_user_holder(payload, offset, end, &mut summary) {
                    return None;
                }
                analysis.total_power_stars += summary.power_star_count;
                analysis.total_bronze_stars += summary.bronze_star_count;
                analysis.total_comet_medals += summary.comet_medal_count;
                analysis.total_enabled_event_flags += summary.enabled_event_flag_count;
                analysis.users[slot - 1] = summary;
            }
            2 => {
                let slot = slots[idx];
                let mut summary = EMPTY_CONFIG_SLOT;
                summary.present = true;
                summary.slot = slot;
                if !parse_config_holder(payload, offset, end, &mut summary) {
                    return None;
                }
                analysis.configs[slot - 1] = summary;
            }
            3 => {
                let mut summary = EMPTY_SYSCONF;
                summary.present = true;
                if !parse_sysconf_holder(payload, offset, end, &mut summary) {
                    return None;
                }
                analysis.sysconf = summary;
            }
            _ => return None,
        }
        idx += 1;
    }

    Some(analysis)
}

fn parse_user_holder(
    payload: EncodedPayload<'_>,
    offset: usize,
    entry_end: usize,
    summary: &mut UserSlotSummary,
) -> bool {
    let limit = match offset.checked_add(GAME_HOLDER_SIZE) {
        Some(value) if value <= entry_end && value <= RAW_GAME_DATA_SIZE => value,
        _ => return false,
    };
    if read_u8(payload, offset) != Some(2) || read_be_u16(payload, offset + 2) != Some(0) {
        return false;
    }
    let Some(chunk_count) = read_u8(payload, offset + 1) else {
        return false;
    };
    if chunk_count > 16 {
        return false;
    }
    summary.chunk_count = chunk_count as usize;

    let mut pos = offset + 4;
    let mut idx = 0u8;
    while idx < chunk_count {
        let Some(size) = read_be_u32(payload, pos + 8).map(|v| v as usize) else {
            return false;
        };
        if size < 12 || pos.checked_add(size).map_or(true, |end| end > limit) {
            return false;
        }
        let sig = read_sig(payload, pos);
        if sig == *b"PLAY" {
            let _ = parse_play_chunk(payload, pos, size, summary);
        } else if sig == *b"GALA" {
            let _ = parse_gala_chunk(payload, pos, size, summary);
        } else if sig == *b"FLG1" {
            let _ = parse_event_flag_chunk(payload, pos, size, summary);
        } else if sig == *b"VLE1" {
            let _ = parse_event_value_chunk(payload, pos, size, summary);
        } else if sig == *b"STF1" {
            let _ = parse_tico_fat_chunk(payload, pos, size, summary);
        } else if sig == *b"SSWM" {
            let _ = parse_world_map_chunk(payload, pos, size, summary);
        }
        pos += size;
        idx += 1;
    }
    true
}

fn parse_play_chunk(
    payload: EncodedPayload<'_>,
    pos: usize,
    size: usize,
    summary: &mut UserSlotSummary,
) -> bool {
    if read_be_u32(payload, pos + 4) != Some(CHUNK_HASH_CONTENT_0X20) {
        return false;
    }
    let end = pos + size;
    let header = pos + 12;
    let Some(lives) = content_u8(payload, header, end, ATTR_PLAYER_LEFT) else {
        return false;
    };
    let Some(star_bits) = content_u16(payload, header, end, ATTR_STOCKED_STAR_PIECE_NUM) else {
        return false;
    };
    let Some(coins) = content_u16(payload, header, end, ATTR_STOCKED_COIN_NUM) else {
        return false;
    };
    let Some(last_one_up) = content_u16(payload, header, end, ATTR_LAST_1UP_COIN_NUM) else {
        return false;
    };
    let Some(flag) = content_u8(payload, header, end, ATTR_FLAG) else {
        return false;
    };
    summary.has_play = true;
    summary.lives = lives as usize;
    summary.stocked_star_bits = star_bits as usize;
    summary.stocked_coins = coins as usize;
    summary.last_one_up_coins = last_one_up as usize;
    summary.player_luigi = flag & 0x01 != 0;
    true
}

fn parse_gala_chunk(
    payload: EncodedPayload<'_>,
    pos: usize,
    size: usize,
    summary: &mut UserSlotSummary,
) -> bool {
    if read_be_u32(payload, pos + 4) != Some(CHUNK_HASH_CONTENT_0X20) {
        return false;
    }
    let end = pos + size;
    let base = pos + 12;
    let Some(galaxy_count) = read_be_u16(payload, base) else {
        return false;
    };
    let stage_header = base + 2;
    let Some((stage_data_size, scenario_header)) = content_header_info(payload, stage_header, end)
    else {
        return false;
    };
    let Some((scenario_data_size, mut data_pos)) =
        content_header_info(payload, scenario_header, end)
    else {
        return false;
    };
    let Some(stage_data_size_offset) =
        content_attribute_offset(payload, stage_header, end, ATTR_DATA_SIZE)
    else {
        return false;
    };
    let Some(stage_scenario_num_offset) =
        content_attribute_offset(payload, stage_header, end, ATTR_SCENARIO_NUM)
    else {
        return false;
    };
    let Some(stage_state_offset) =
        content_attribute_offset(payload, stage_header, end, ATTR_GALAXY_STATE)
    else {
        return false;
    };
    let Some(stage_flag_offset) = content_attribute_offset(payload, stage_header, end, ATTR_FLAG)
    else {
        return false;
    };
    let Some(scenario_flag_offset) =
        content_attribute_offset(payload, scenario_header, end, ATTR_FLAG)
    else {
        return false;
    };
    if stage_data_size == 0 || scenario_data_size == 0 {
        return false;
    }

    let mut idx = 0usize;
    while idx < galaxy_count as usize {
        if data_pos
            .checked_add(stage_data_size)
            .map_or(true, |v| v > end)
        {
            return false;
        }
        let Some(record_size) = read_be_u16(payload, data_pos + stage_data_size_offset) else {
            return false;
        };
        let record_size = record_size as usize;
        if record_size < stage_data_size
            || data_pos.checked_add(record_size).map_or(true, |v| v > end)
        {
            return false;
        }
        let scenario_num = match read_u8(payload, data_pos + stage_scenario_num_offset) {
            Some(value) => value as usize,
            None => return false,
        };
        let state = match read_u8(payload, data_pos + stage_state_offset) {
            Some(value) => value,
            None => return false,
        };
        let flag = match read_u8(payload, data_pos + stage_flag_offset) {
            Some(value) => value,
            None => return false,
        };
        if state != 0 {
            summary.open_galaxy_count += 1;
        }
        if flag & 0x01 != 0 {
            summary.comet_medal_count += 1;
        }
        if stage_data_size
            .checked_add(scenario_num.saturating_mul(scenario_data_size))
            .map_or(true, |needed| needed > record_size)
        {
            return false;
        }
        let mut scenario_pos = data_pos + stage_data_size;
        let mut scenario_idx = 0usize;
        while scenario_idx < scenario_num {
            let Some(scenario_flag) = read_u8(payload, scenario_pos + scenario_flag_offset) else {
                return false;
            };
            if scenario_flag & 0x01 != 0 {
                summary.power_star_count += 1;
            }
            if scenario_flag & 0x02 != 0 {
                summary.bronze_star_count += 1;
            }
            if scenario_flag & 0x04 != 0 {
                summary.visited_scenario_count += 1;
            }
            if scenario_flag & 0x08 != 0 {
                summary.ghost_luigi_scenario_count += 1;
            }
            if scenario_flag & 0x10 != 0 {
                summary.standby_luigi_scenario_count += 1;
            }
            scenario_pos += scenario_data_size;
            scenario_idx += 1;
        }
        data_pos += record_size;
        idx += 1;
    }
    summary.has_galaxy = true;
    summary.galaxy_count = galaxy_count as usize;
    true
}

fn parse_event_flag_chunk(
    payload: EncodedPayload<'_>,
    pos: usize,
    size: usize,
    summary: &mut UserSlotSummary,
) -> bool {
    if read_be_u32(payload, pos + 4) != Some(CHUNK_HASH_EVENT_FLAG) || size < 12 {
        return false;
    }
    let data_len = size - 12;
    if data_len % 2 != 0 {
        return false;
    }
    summary.event_flag_count = data_len / 2;
    let mut offset = pos + 12;
    let end = pos + size;
    while offset + 2 <= end {
        let Some(flag) = read_be_u16(payload, offset) else {
            return false;
        };
        if flag & 0x8000 != 0 {
            summary.enabled_event_flag_count += 1;
        }
        offset += 2;
    }
    true
}

fn parse_event_value_chunk(
    payload: EncodedPayload<'_>,
    pos: usize,
    size: usize,
    summary: &mut UserSlotSummary,
) -> bool {
    if read_be_u32(payload, pos + 4) != Some(CHUNK_HASH_EVENT_VALUE) || size < 12 {
        return false;
    }
    let data_len = size - 12;
    if data_len % 4 != 0 {
        return false;
    }
    summary.event_value_count = data_len / 4;
    let mut offset = pos + 12;
    let end = pos + size;
    while offset + 4 <= end {
        let Some(value) = read_be_u16(payload, offset + 2) else {
            return false;
        };
        if value != 0 {
            summary.nonzero_event_value_count += 1;
        }
        offset += 4;
    }
    true
}

fn parse_tico_fat_chunk(
    payload: EncodedPayload<'_>,
    pos: usize,
    size: usize,
    summary: &mut UserSlotSummary,
) -> bool {
    if read_be_u32(payload, pos + 4) != Some(CHUNK_HASH_TICO_FAT) || size < 12 + 128 {
        return false;
    }
    let base = pos + 12;
    let mut offset = base;
    let star_end = base + 96;
    while offset + 2 <= star_end {
        let Some(value) = read_be_u16(payload, offset) else {
            return false;
        };
        summary.hungry_luma_star_bits += value as usize;
        offset += 2;
    }
    let coin_end = base + 128;
    while offset + 2 <= coin_end {
        let Some(value) = read_be_u16(payload, offset) else {
            return false;
        };
        if value != 0 {
            summary.coin_luma_galaxy_count += 1;
        }
        offset += 2;
    }
    true
}

fn parse_world_map_chunk(
    payload: EncodedPayload<'_>,
    pos: usize,
    size: usize,
    summary: &mut UserSlotSummary,
) -> bool {
    if read_be_u32(payload, pos + 4) != Some(CHUNK_HASH_WORLD_MAP) || size < 21 {
        return false;
    }
    let Some(world_no) = read_u8(payload, pos + 12 + 8) else {
        return false;
    };
    summary.world_map_present = true;
    summary.world_no = world_no as usize;
    true
}

fn parse_config_holder(
    payload: EncodedPayload<'_>,
    offset: usize,
    entry_end: usize,
    summary: &mut ConfigSlotSummary,
) -> bool {
    let limit = match offset.checked_add(CONFIG_HOLDER_SIZE) {
        Some(value) if value <= entry_end && value <= RAW_GAME_DATA_SIZE => value,
        _ => return false,
    };
    if read_u8(payload, offset) != Some(2) || read_be_u16(payload, offset + 2) != Some(0) {
        return false;
    }
    let Some(chunk_count) = read_u8(payload, offset + 1) else {
        return false;
    };
    if chunk_count > 8 {
        return false;
    }
    summary.chunk_count = chunk_count as usize;
    let mut pos = offset + 4;
    let mut idx = 0u8;
    while idx < chunk_count {
        let Some(size) = read_be_u32(payload, pos + 8).map(|v| v as usize) else {
            return false;
        };
        if size < 12 || pos.checked_add(size).map_or(true, |end| end > limit) {
            return false;
        }
        let sig = read_sig(payload, pos);
        let hash = read_be_u32(payload, pos + 4);
        if sig == *b"CONF" && hash == Some(CHUNK_HASH_CONFIG_CREATE) && size >= 13 {
            let Some(value) = read_u8(payload, pos + 12) else {
                return false;
            };
            summary.created_present = true;
            summary.created = value != 0;
        } else if sig == *b"MII " && hash == Some(CHUNK_HASH_CONFIG_MII) && size >= 22 {
            let Some(flag) = read_u8(payload, pos + 12) else {
                return false;
            };
            let Some(icon_id) = read_u8(payload, pos + 12 + 9) else {
                return false;
            };
            summary.mii_present = true;
            summary.mii_choice_flag = flag & 0x02 != 0;
            summary.icon_id = icon_id as usize;
        } else if sig == *b"MISC" && hash == Some(CHUNK_HASH_ONE) && size >= 20 {
            summary.misc_present = true;
        }
        pos += size;
        idx += 1;
    }
    true
}

fn parse_sysconf_holder(
    payload: EncodedPayload<'_>,
    offset: usize,
    entry_end: usize,
    summary: &mut SysconfSummary,
) -> bool {
    let limit = match offset.checked_add(SYSCONF_HOLDER_SIZE) {
        Some(value) if value <= entry_end && value <= RAW_GAME_DATA_SIZE => value,
        _ => return false,
    };
    if read_u8(payload, offset) != Some(2) || read_be_u16(payload, offset + 2) != Some(0) {
        return false;
    }
    let Some(chunk_count) = read_u8(payload, offset + 1) else {
        return false;
    };
    if chunk_count > 4 {
        return false;
    }
    summary.chunk_count = chunk_count as usize;
    let mut pos = offset + 4;
    let mut idx = 0u8;
    while idx < chunk_count {
        let Some(size) = read_be_u32(payload, pos + 8).map(|v| v as usize) else {
            return false;
        };
        if size < 12 || pos.checked_add(size).map_or(true, |end| end > limit) {
            return false;
        }
        if read_sig(payload, pos) == *b"SYSC"
            && read_be_u32(payload, pos + 4) == Some(CHUNK_HASH_SYSCONF)
        {
            let end = pos + size;
            let header = pos + 12;
            if let Some(value) = content_u16(payload, header, end, ATTR_BANK_STAR_PIECE_NUM) {
                summary.bank_star_bits_present = true;
                summary.bank_star_bits = value as usize;
            }
            if let Some(value) = content_u16(payload, header, end, ATTR_BANK_STAR_PIECE_MAX) {
                summary.bank_star_bits_max = value as usize;
            }
            if let Some(value) = content_u8(payload, header, end, ATTR_GIFTED_PLAYER_LEFT) {
                summary.gifted_lives_present = true;
                summary.gifted_lives = value as usize;
            }
        }
        pos += size;
        idx += 1;
    }
    true
}

fn raw_game_data_checksum(payload: EncodedPayload<'_>) -> Option<u32> {
    let mut sum = 0u16;
    let mut inv_sum = 0u16;
    let mut idx = 4usize;
    while idx + 1 < RAW_GAME_DATA_SIZE {
        let term = read_be_u16(payload, idx)?;
        sum = sum.wrapping_add(term);
        inv_sum = inv_sum.wrapping_add(!term);
        idx += 2;
    }
    Some(((sum as u32) << 16) | inv_sum as u32)
}

fn write_active_user_slots(w: &mut Writer, analysis: &RawGameDataAnalysis) {
    let mut first = true;
    let mut idx = 0usize;
    while idx < analysis.users.len() {
        let slot = analysis.users[idx];
        if slot.present {
            if !first {
                w.byte(b',');
            }
            first = false;
            w.usize(slot.slot);
        }
        idx += 1;
    }
}

fn write_user_slots(w: &mut Writer, analysis: &RawGameDataAnalysis) {
    let mut first = true;
    let mut idx = 0usize;
    while idx < analysis.users.len() {
        let slot = analysis.users[idx];
        if slot.present {
            if !first {
                w.byte(b',');
            }
            first = false;
            w.bytes(b"{\"slot\":");
            w.usize(slot.slot);
            w.bytes(b",\"chunkCount\":");
            w.usize(slot.chunk_count);
            w.bytes(b",\"play\":");
            if slot.has_play {
                w.bytes(b"{\"lives\":");
                w.usize(slot.lives);
                w.bytes(b",\"stockedStarBits\":");
                w.usize(slot.stocked_star_bits);
                w.bytes(b",\"stockedCoins\":");
                w.usize(slot.stocked_coins);
                w.bytes(b",\"lastOneUpCoins\":");
                w.usize(slot.last_one_up_coins);
                w.bytes(b",\"playerLuigi\":");
                w.bool(slot.player_luigi);
                w.byte(b'}');
            } else {
                w.bytes(b"null");
            }
            w.bytes(b",\"galaxy\":");
            if slot.has_galaxy {
                w.bytes(b"{\"galaxyCount\":");
                w.usize(slot.galaxy_count);
                w.bytes(b",\"openGalaxies\":");
                w.usize(slot.open_galaxy_count);
                w.bytes(b",\"powerStars\":");
                w.usize(slot.power_star_count);
                w.bytes(b",\"bronzeStars\":");
                w.usize(slot.bronze_star_count);
                w.bytes(b",\"cometMedals\":");
                w.usize(slot.comet_medal_count);
                w.bytes(b",\"visitedScenarios\":");
                w.usize(slot.visited_scenario_count);
                w.bytes(b",\"ghostLuigiScenarios\":");
                w.usize(slot.ghost_luigi_scenario_count);
                w.bytes(b",\"standbyLuigiScenarios\":");
                w.usize(slot.standby_luigi_scenario_count);
                w.byte(b'}');
            } else {
                w.bytes(b"null");
            }
            w.bytes(b",\"eventFlags\":{\"entries\":");
            w.usize(slot.event_flag_count);
            w.bytes(b",\"enabled\":");
            w.usize(slot.enabled_event_flag_count);
            w.bytes(b"},\"eventValues\":{\"entries\":");
            w.usize(slot.event_value_count);
            w.bytes(b",\"nonzero\":");
            w.usize(slot.nonzero_event_value_count);
            w.bytes(b"},\"hungryLumas\":{\"fedStarBits\":");
            w.usize(slot.hungry_luma_star_bits);
            w.bytes(b",\"coinGalaxies\":");
            w.usize(slot.coin_luma_galaxy_count);
            w.bytes(b"},\"worldMap\":");
            if slot.world_map_present {
                w.bytes(b"{\"worldNo\":");
                w.usize(slot.world_no);
                w.byte(b'}');
            } else {
                w.bytes(b"null");
            }
            w.byte(b'}');
        }
        idx += 1;
    }
}

fn write_config_slots(w: &mut Writer, analysis: &RawGameDataAnalysis) {
    let mut first = true;
    let mut idx = 0usize;
    while idx < analysis.configs.len() {
        let slot = analysis.configs[idx];
        if slot.present {
            if !first {
                w.byte(b',');
            }
            first = false;
            w.bytes(b"{\"slot\":");
            w.usize(slot.slot);
            w.bytes(b",\"chunkCount\":");
            w.usize(slot.chunk_count);
            w.bytes(b",\"created\":");
            if slot.created_present {
                w.bool(slot.created);
            } else {
                w.bytes(b"null");
            }
            w.bytes(b",\"miiIcon\":");
            if slot.mii_present {
                w.bytes(b"{\"miiChoiceFlag\":");
                w.bool(slot.mii_choice_flag);
                w.bytes(b",\"iconId\":");
                w.usize(slot.icon_id);
                w.bytes(b",\"iconLabel\":");
                w.json_string(icon_label(slot.icon_id));
                w.byte(b'}');
            } else {
                w.bytes(b"null");
            }
            w.bytes(b",\"lastModifiedPresent\":");
            w.bool(slot.misc_present);
            w.byte(b'}');
        }
        idx += 1;
    }
}

fn write_sysconf(w: &mut Writer, sysconf: SysconfSummary) {
    if !sysconf.present {
        w.bytes(b"null");
        return;
    }
    w.bytes(b"{\"chunkCount\":");
    w.usize(sysconf.chunk_count);
    w.bytes(b",\"bankStarBits\":");
    if sysconf.bank_star_bits_present {
        w.usize(sysconf.bank_star_bits);
    } else {
        w.bytes(b"null");
    }
    w.bytes(b",\"bankStarBitsMax\":");
    if sysconf.bank_star_bits_present {
        w.usize(sysconf.bank_star_bits_max);
    } else {
        w.bytes(b"null");
    }
    w.bytes(b",\"giftedLives\":");
    if sysconf.gifted_lives_present {
        w.usize(sysconf.gifted_lives);
    } else {
        w.bytes(b"null");
    }
    w.byte(b'}');
}

fn icon_label(icon_id: usize) -> &'static [u8] {
    match icon_id {
        0 => b"Mii",
        1 => b"Mario",
        2 => b"Luigi",
        3 => b"Yoshi",
        4 => b"Toad",
        5 => b"Peach",
        6 => b"Rosalina",
        7 => b"Luma",
        _ => b"Unknown",
    }
}

fn entry_slot(payload: EncodedPayload<'_>, entry: usize, prefix: &[u8]) -> Option<usize> {
    if !has_bytes(payload, entry, prefix) {
        return None;
    }
    let digit = read_u8(payload, entry + prefix.len())?;
    if !(b'1'..=b'6').contains(&digit) {
        return None;
    }
    let mut idx = prefix.len() + 1;
    while idx < 12 {
        if read_u8(payload, entry + idx)? != 0 {
            return None;
        }
        idx += 1;
    }
    Some((digit - b'0') as usize)
}

fn entry_name_is(payload: EncodedPayload<'_>, entry: usize, name: &[u8]) -> bool {
    if !has_bytes(payload, entry, name) {
        return false;
    }
    let mut idx = name.len();
    while idx < 12 {
        if read_u8(payload, entry + idx) != Some(0) {
            return false;
        }
        idx += 1;
    }
    true
}

fn content_header_info(
    payload: EncodedPayload<'_>,
    header: usize,
    end: usize,
) -> Option<(usize, usize)> {
    let attr_count = read_be_u16(payload, header)? as usize;
    if attr_count > 32 {
        return None;
    }
    let data_size = read_be_u16(payload, header + 2)? as usize;
    let data_start = header.checked_add(4 + attr_count * 4)?;
    if data_start > end || data_start.checked_add(data_size)? > end {
        return None;
    }
    Some((data_size, data_start))
}

fn content_attribute_offset(
    payload: EncodedPayload<'_>,
    header: usize,
    end: usize,
    attr: u16,
) -> Option<usize> {
    let attr_count = read_be_u16(payload, header)? as usize;
    if attr_count > 32 {
        return None;
    }
    let data_size = read_be_u16(payload, header + 2)? as usize;
    let data_start = header.checked_add(4 + attr_count * 4)?;
    if data_start > end || data_start.checked_add(data_size)? > end {
        return None;
    }
    let mut idx = 0usize;
    while idx < attr_count {
        let entry = header + 4 + idx * 4;
        if read_be_u16(payload, entry)? == attr {
            let offset = read_be_u16(payload, entry + 2)? as usize;
            if offset < data_size {
                return Some(offset);
            }
            return None;
        }
        idx += 1;
    }
    None
}

fn content_field_abs(
    payload: EncodedPayload<'_>,
    header: usize,
    end: usize,
    attr: u16,
    width: usize,
) -> Option<usize> {
    let (data_size, data_start) = content_header_info(payload, header, end)?;
    let offset = content_attribute_offset(payload, header, end, attr)?;
    if offset.checked_add(width)? > data_size {
        return None;
    }
    Some(data_start + offset)
}

fn content_u8(payload: EncodedPayload<'_>, header: usize, end: usize, attr: u16) -> Option<u8> {
    let pos = content_field_abs(payload, header, end, attr, 1)?;
    read_u8(payload, pos)
}

fn content_u16(payload: EncodedPayload<'_>, header: usize, end: usize, attr: u16) -> Option<u16> {
    let pos = content_field_abs(payload, header, end, attr, 2)?;
    read_be_u16(payload, pos)
}

fn read_sig(payload: EncodedPayload<'_>, offset: usize) -> [u8; 4] {
    [
        read_u8(payload, offset).unwrap_or(0),
        read_u8(payload, offset + 1).unwrap_or(0),
        read_u8(payload, offset + 2).unwrap_or(0),
        read_u8(payload, offset + 3).unwrap_or(0),
    ]
}

fn read_u8(payload: EncodedPayload<'_>, offset: usize) -> Option<u8> {
    decoded_byte_at(payload.encoded, offset)
}

fn read_be_u16(payload: EncodedPayload<'_>, offset: usize) -> Option<u16> {
    let b0 = decoded_byte_at(payload.encoded, offset)? as u16;
    let b1 = decoded_byte_at(payload.encoded, offset + 1)? as u16;
    Some((b0 << 8) | b1)
}

fn read_be_u32(payload: EncodedPayload<'_>, offset: usize) -> Option<u32> {
    let b0 = decoded_byte_at(payload.encoded, offset)? as u32;
    let b1 = decoded_byte_at(payload.encoded, offset + 1)? as u32;
    let b2 = decoded_byte_at(payload.encoded, offset + 2)? as u32;
    let b3 = decoded_byte_at(payload.encoded, offset + 3)? as u32;
    Some((b0 << 24) | (b1 << 16) | (b2 << 8) | b3)
}

fn has_bytes(payload: EncodedPayload<'_>, offset: usize, expected: &[u8]) -> bool {
    let mut idx = 0;
    while idx < expected.len() {
        if decoded_byte_at(payload.encoded, offset + idx) != Some(expected[idx]) {
            return false;
        }
        idx += 1;
    }
    true
}

fn contains(payload: EncodedPayload<'_>, needle: &[u8]) -> bool {
    if needle.is_empty() || DATA_BIN_SIZE < needle.len() {
        return false;
    }
    let mut idx = 0;
    while idx <= DATA_BIN_SIZE - needle.len() {
        if has_bytes(payload, idx, needle) {
            return true;
        }
        idx += 1;
    }
    false
}

fn decoded_eq(a: EncodedPayload<'_>, b: &[u8]) -> bool {
    let mut idx = 0;
    while idx < b.len() {
        if decoded_byte_at(a.encoded, idx) != Some(b[idx]) {
            return false;
        }
        idx += 1;
    }
    true
}

fn json_string_field(input: &[u8], field: &[u8]) -> Option<(usize, usize)> {
    let key = json_key_position(input, field, 0)?;
    let mut idx = skip_ws(input, key + field.len() + 2);
    if *input.get(idx)? != b':' {
        return None;
    }
    idx = skip_ws(input, idx + 1);
    if *input.get(idx)? != b'"' {
        return None;
    }
    let start = idx + 1;
    idx = start;
    while idx < input.len() {
        match input[idx] {
            b'\\' => idx += 2,
            b'"' => return Some((start, idx - start)),
            _ => idx += 1,
        }
    }
    None
}

fn json_last_object_field(input: &[u8], field: &[u8]) -> Option<(usize, usize)> {
    let mut search = 0;
    let mut result = None;
    while let Some(key) = json_key_position(input, field, search) {
        let mut idx = skip_ws(input, key + field.len() + 2);
        if input.get(idx) == Some(&b':') {
            idx = skip_ws(input, idx + 1);
            if input.get(idx) == Some(&b'{') {
                if let Some(end) = matching_object_end(input, idx) {
                    result = Some((idx, end - idx + 1));
                    search = end + 1;
                    continue;
                }
            }
        }
        search = key + 1;
    }
    result
}

fn json_key_position(input: &[u8], field: &[u8], start_at: usize) -> Option<usize> {
    if field.len() + 2 > input.len() || start_at >= input.len() {
        return None;
    }
    let mut idx = start_at;
    while idx + field.len() + 2 <= input.len() {
        if input[idx] == b'"' && input[idx + field.len() + 1] == b'"' {
            let mut ok = true;
            let mut j = 0;
            while j < field.len() {
                if input[idx + 1 + j] != field[j] {
                    ok = false;
                    break;
                }
                j += 1;
            }
            if ok {
                return Some(idx);
            }
        }
        idx += 1;
    }
    None
}

fn matching_object_end(input: &[u8], start: usize) -> Option<usize> {
    let mut idx = start;
    let mut depth = 0usize;
    let mut in_string = false;
    while idx < input.len() {
        let c = input[idx];
        if in_string {
            if c == b'\\' {
                idx += 2;
                continue;
            }
            if c == b'"' {
                in_string = false;
            }
            idx += 1;
            continue;
        }
        if c == b'"' {
            in_string = true;
        } else if c == b'{' {
            depth += 1;
        } else if c == b'}' {
            depth = depth.checked_sub(1)?;
            if depth == 0 {
                return Some(idx);
            }
        }
        idx += 1;
    }
    None
}

fn skip_ws(input: &[u8], mut idx: usize) -> usize {
    while idx < input.len() {
        match input[idx] {
            b' ' | b'\n' | b'\r' | b'\t' => idx += 1,
            _ => break,
        }
    }
    idx
}

fn decoded_base64_len(input: &[u8]) -> Option<usize> {
    if input.len() % 4 != 0 {
        return None;
    }
    let mut pad = 0usize;
    if input.ends_with(b"==") {
        pad = 2;
    } else if input.ends_with(b"=") {
        pad = 1;
    }
    Some((input.len() / 4) * 3 - pad)
}

fn decoded_byte_at(input: &[u8], offset: usize) -> Option<u8> {
    let decoded_len = decoded_base64_len(input)?;
    if offset >= decoded_len {
        return None;
    }
    let group = (offset / 3) * 4;
    let rem = offset % 3;
    let a = b64_value(*input.get(group)?)?;
    let b = b64_value(*input.get(group + 1)?)?;
    let c_raw = *input.get(group + 2)?;
    let d_raw = *input.get(group + 3)?;
    let c = if c_raw == b'=' { 64 } else { b64_value(c_raw)? };
    let d = if d_raw == b'=' { 64 } else { b64_value(d_raw)? };
    match rem {
        0 => Some((a << 2) | (b >> 4)),
        1 if c != 64 => Some(((b & 0x0F) << 4) | (c >> 2)),
        2 if d != 64 => Some(((c & 0x03) << 6) | d),
        _ => None,
    }
}

#[allow(dead_code)]
fn decode_base64(input: &[u8], out: &mut [u8]) -> Option<usize> {
    let mut idx = 0usize;
    let mut out_len = 0usize;
    while idx < input.len() {
        let a = b64_value(*input.get(idx)?)?;
        let b = b64_value(*input.get(idx + 1)?)?;
        let c_raw = *input.get(idx + 2)?;
        let d_raw = *input.get(idx + 3)?;
        let c = if c_raw == b'=' { 64 } else { b64_value(c_raw)? };
        let d = if d_raw == b'=' { 64 } else { b64_value(d_raw)? };
        if out_len >= out.len() {
            return None;
        }
        out[out_len] = (a << 2) | (b >> 4);
        out_len += 1;
        if c != 64 {
            if out_len >= out.len() {
                return None;
            }
            out[out_len] = ((b & 0x0F) << 4) | (c >> 2);
            out_len += 1;
        }
        if d != 64 {
            if out_len >= out.len() {
                return None;
            }
            out[out_len] = ((c & 0x03) << 6) | d;
            out_len += 1;
        }
        idx += 4;
    }
    Some(out_len)
}

fn b64_value(value: u8) -> Option<u8> {
    match value {
        b'A'..=b'Z' => Some(value - b'A'),
        b'a'..=b'z' => Some(value - b'a' + 26),
        b'0'..=b'9' => Some(value - b'0' + 52),
        b'+' => Some(62),
        b'/' => Some(63),
        _ => None,
    }
}

fn write_base64(w: &mut Writer, bytes: &[u8]) {
    const TABLE: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut i = 0usize;
    while i + 3 <= bytes.len() {
        let n = ((bytes[i] as u32) << 16) | ((bytes[i + 1] as u32) << 8) | bytes[i + 2] as u32;
        w.byte(TABLE[((n >> 18) & 0x3F) as usize]);
        w.byte(TABLE[((n >> 12) & 0x3F) as usize]);
        w.byte(TABLE[((n >> 6) & 0x3F) as usize]);
        w.byte(TABLE[(n & 0x3F) as usize]);
        i += 3;
    }
    let rem = bytes.len() - i;
    if rem == 1 {
        let n = (bytes[i] as u32) << 16;
        w.byte(TABLE[((n >> 18) & 0x3F) as usize]);
        w.byte(TABLE[((n >> 12) & 0x3F) as usize]);
        w.byte(b'=');
        w.byte(b'=');
    } else if rem == 2 {
        let n = ((bytes[i] as u32) << 16) | ((bytes[i + 1] as u32) << 8);
        w.byte(TABLE[((n >> 18) & 0x3F) as usize]);
        w.byte(TABLE[((n >> 12) & 0x3F) as usize]);
        w.byte(TABLE[((n >> 6) & 0x3F) as usize]);
        w.byte(b'=');
    }
}
