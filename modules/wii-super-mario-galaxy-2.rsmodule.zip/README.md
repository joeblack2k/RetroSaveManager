# Super Mario Galaxy 2 Wii Module

This module validates official Wii SD `data.bin` exports for Super Mario Galaxy 2 and exposes only whole-save replacement with verified public samples. It also parses raw decrypted `GameData.bin` payloads read-only for inspection.

The official Wii export keeps `GameData.bin` encrypted inside `data.bin`, so the module does not expose granular lives, Star Bits, Power Stars, comet medals, or galaxy flags. Those fields are documented for decrypted `GameData.bin`, but this bundle does not ship Wii decryption keys and does not patch encrypted inner data.

## Supported Payload

- 75200-byte Wii SD `data.bin`
- 12448-byte raw decrypted `GameData.bin` for read-only semantic inspection
- Backup header at `0xF0C0`
- File header at `0xF140`
- Embedded file name `GameData.bin`
- Embedded file size `0x30A0`
- Title codes `SB4E`, `SB4P`, `SB4J`, and `SB4K` for structural inspection

Raw `GameData.bin` validation checks version `3`, file size `0x30A0`, the 16-bit word checksum/inverse checksum pair, the entry index, chunk-holder version `2`, and known SMG2 chunk signatures.

Read-only semantic fields include per-user PLAY counts, GALA aggregate counts, event flag/value counts, Hungry Luma aggregate counts, world-map world number, config-created/icon state, and sysconf bank/gifted-life values.

## Editable Surface

The only editable field is `templateId`, an enum selecting one exact public GameFAQs/MarioCube `data.bin` sample. Applying a template replaces the full `data.bin` payload and refuses cross-region replacement by title code.

No raw hex writes, filename-only matching, speculative gameplay fields, or raw `GameData.bin` edits are used. Raw `GameData.bin` semantic fields are inspection-only.

## Sample Evidence

Public GameFAQs/MarioCube samples embedded for template replacement:

| id | title code | size | sha256 |
|---|---|---:|---|
| gamefaqs-20695-sb4e | SB4E | 75200 | 66866f9d4951ddf8dc428ee326f62a425ec0b844362bc5b301c333f2d46655d3 |
| gamefaqs-20827-sb4e | SB4E | 75200 | a44c1e29c5365e1870b029f083029ca346570aef2af7aa67a21922d2ea0c49c4 |
| gamefaqs-20813-sb4p | SB4P | 75200 | a1c8d2023685c4a32506ce98746956d95fa75412728a06044b5291aac77d50b5 |
| gamefaqs-24225-sb4p | SB4P | 75200 | feca26ceeb4cc65d96acb110c4f156ee6428d5708e4db25e45fa23d5ed628584 |
