# Sega Saturn - Quake

This module adds read-only semantic recognition for the real Saturn Quake backup RAM entry.

Supported evidence:

- Saturn backup RAM container header `BackUpRam Format`.
- Internal or cartridge archive entry named `LOBOQUAKE__`.
- Archive comment `save games`.
- Entry payload size `1408` bytes.
- Quake payload geometry `12 * 116 + 16` bytes.
- Per-record checksum: stored big-endian 16-bit byte sum over bytes `0x00..0x71`.
- Per-record validity marker at `0x6e` in the verified sample.
- Per-slot read-only state words for health, armor, current ammo, inventory/weapon mask, raw level index, raw difficulty, and progress/stat bytes.

No gameplay writes are exposed. The bundled pack is a details pack with slot-scoped values only; `applyCheats` returns the original payload unchanged.

Known limits:

- Weapon bit labels are intentionally left as numbered Saturn record bits; the verified sample proves the mask and set bits, not every weapon name.
- Level and difficulty are exposed as raw record values. Named map routing and writes need additional before/after saves.
- The verified sample has twelve identical records. The module reports that equality but does not treat the records as repair mirrors.
- YabaSanshiro 4 MiB and 8 MiB extended internal images are intentionally outside this module's manifest because the current module ABI passes base64 payloads through JSON.
