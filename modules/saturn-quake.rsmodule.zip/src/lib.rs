#![no_std]
#![allow(static_mut_refs)]

use core::cmp::min;
use core::panic::PanicInfo;
use core::ptr;
use core::slice;

const HEAP_SIZE: usize = 4_000_000;
const VOLUME_CAP: usize = 0x80000;
const QUAKE_ENTRY_SIZE: usize = 1408;
const QUAKE_RECORD_COUNT: usize = 12;
const QUAKE_RECORD_SIZE: usize = 116;
const QUAKE_PADDING_SIZE: usize = 16;
const QUAKE_LEVEL_OFFSET: usize = 0x00;
const QUAKE_INVENTORY_WEAPON_MASK_OFFSET: usize = 0x02;
const QUAKE_HEALTH_OFFSET: usize = 0x10;
const QUAKE_ARMOR_OFFSET: usize = 0x14;
const QUAKE_CURRENT_AMMO_OFFSET: usize = 0x24;
const QUAKE_MONSTER_TOTAL_OFFSET: usize = 0x40;
const QUAKE_SECRET_TOTAL_OFFSET: usize = 0x42;
const QUAKE_PROGRESS_OFFSET: usize = 0x4c;
const QUAKE_PROGRESS_SIZE: usize = 0x22;
const QUAKE_VALID_MARKER_OFFSET: usize = 0x6e;
const QUAKE_DIFFICULTY_OFFSET: usize = 0x70;
const QUAKE_CHECKSUM_OFFSET: usize = 0x72;
const SATURN_INTERNAL_RAW_SIZE: usize = 0x8000;
const SATURN_INTERNAL_INTERLEAVED_SIZE: usize = SATURN_INTERNAL_RAW_SIZE * 2;
const SATURN_CARTRIDGE_RAW_SIZE: usize = 0x80000;
const SATURN_CARTRIDGE_INTERLEAVED_SIZE: usize = SATURN_CARTRIDGE_RAW_SIZE * 2;
const SATURN_COMBINED_RAW_SIZE: usize = SATURN_INTERNAL_RAW_SIZE + SATURN_CARTRIDGE_RAW_SIZE;
const SATURN_COMBINED_INTERLEAVED_SIZE: usize =
    SATURN_INTERNAL_INTERLEAVED_SIZE + SATURN_CARTRIDGE_INTERLEAVED_SIZE;
const SATURN_INTERNAL_BLOCK_SIZE: usize = 0x40;
const SATURN_CARTRIDGE_BLOCK_SIZE: usize = 0x200;
const SATURN_ARCHIVE_ENTRY_MARKER: u32 = 0x8000_0000;
const SATURN_HEADER_MAGIC: &[u8] = b"BackUpRam Format";

static mut HEAP: [u8; HEAP_SIZE] = [0; HEAP_SIZE];
static mut HEAP_OFFSET: usize = 8;
static mut VOLUME: [u8; VOLUME_CAP] = [0; VOLUME_CAP];
static mut ENTRY: [u8; QUAKE_ENTRY_SIZE] = [0; QUAKE_ENTRY_SIZE];

#[panic_handler]
fn panic(_: &PanicInfo) -> ! {
    loop {}
}

fn heap_base() -> usize {
    ptr::addr_of_mut!(HEAP) as *mut u8 as usize
}

#[no_mangle]
pub extern "C" fn rsm_alloc(len: i32) -> i32 {
    if len < 0 {
        return 0;
    }
    let len = len as usize;
    unsafe {
        let relative = (HEAP_OFFSET + 7) & !7;
        let Some(end) = relative.checked_add(len) else {
            return 0;
        };
        if end >= HEAP_SIZE {
            return 0;
        }
        HEAP_OFFSET = end;
        (heap_base() + relative) as i32
    }
}

#[no_mangle]
pub extern "C" fn rsm_call(command_ptr: i32, command_len: i32, input_ptr: i32, input_len: i32) -> u64 {
    let Some(command) = read_bytes(command_ptr, command_len) else {
        return write_unsupported(b"bad command pointer");
    };
    let input = read_bytes(input_ptr, input_len).unwrap_or(&[]);
    if command == b"capabilities" {
        write_capabilities()
    } else if command == b"parse" {
        write_parse(input)
    } else if command == b"readCheats" {
        write_read_cheats(input)
    } else if command == b"applyCheats" {
        write_apply_cheats(input)
    } else {
        write_unsupported(b"unsupported command")
    }
}

fn read_bytes(ptr: i32, len: i32) -> Option<&'static [u8]> {
    if ptr < 0 || len < 0 {
        return None;
    }
    let ptr = ptr as usize;
    let len = len as usize;
    let end = ptr.checked_add(len)?;
    let base = heap_base();
    if ptr < base || end > base + HEAP_SIZE {
        return None;
    }
    unsafe { Some(slice::from_raw_parts(ptr as *const u8, len)) }
}

struct Writer {
    ptr: usize,
    len: usize,
    cap: usize,
}

impl Writer {
    fn new(cap: usize) -> Option<Writer> {
        let ptr = rsm_alloc(cap as i32);
        if ptr <= 0 {
            return None;
        }
        Some(Writer {
            ptr: ptr as usize,
            len: 0,
            cap,
        })
    }

    fn finish(self) -> u64 {
        ((self.ptr as u64) << 32) | (self.len as u64)
    }

    fn byte(&mut self, value: u8) {
        if self.len >= self.cap {
            return;
        }
        unsafe {
            ptr::write((self.ptr + self.len) as *mut u8, value);
        }
        self.len += 1;
    }

    fn bytes(&mut self, values: &[u8]) {
        for value in values {
            self.byte(*value);
        }
    }

    fn bool(&mut self, value: bool) {
        if value {
            self.bytes(b"true");
        } else {
            self.bytes(b"false");
        }
    }

    fn usize(&mut self, mut value: usize) {
        let mut tmp = [0u8; 20];
        let mut idx = tmp.len();
        if value == 0 {
            self.byte(b'0');
            return;
        }
        while value > 0 {
            idx -= 1;
            tmp[idx] = b'0' + (value % 10) as u8;
            value /= 10;
        }
        self.bytes(&tmp[idx..]);
    }

    fn escaped_json_string(&mut self, value: &[u8]) {
        self.byte(b'"');
        for b in value {
            match *b {
                b'"' => self.bytes(br#"\""#),
                b'\\' => self.bytes(br#"\\"#),
                b'\n' => self.bytes(br#"\n"#),
                b'\r' => self.bytes(br#"\r"#),
                b'\t' => self.bytes(br#"\t"#),
                other => self.byte(other),
            }
        }
        self.byte(b'"');
    }
}

#[derive(Clone, Copy)]
struct Analysis {
    payload_len: usize,
    volume_internal: bool,
    interleaved: bool,
    entry_block_count: usize,
    first_block: usize,
    total_entries: usize,
    non_zero_records: usize,
    valid_marker_records: usize,
    checksum_valid_records: usize,
    checksum_invalid_records: usize,
    identical_records: bool,
    first_slot: SlotState,
    slots: [SlotState; QUAKE_RECORD_COUNT],
}

#[derive(Clone, Copy)]
struct SlotState {
    non_zero: bool,
    non_zero_bytes: usize,
    level_index_raw: u16,
    inventory_weapon_mask: u16,
    health: u32,
    armor: u32,
    current_ammo: u32,
    monster_total: u16,
    secret_total: u16,
    progress_non_default_bytes: usize,
    progress_checksum: u16,
    valid_marker: u16,
    difficulty_raw: u16,
    checksum_stored: u16,
    checksum_computed: u16,
    checksum_valid: bool,
}

const EMPTY_SLOT_STATE: SlotState = SlotState {
    non_zero: false,
    non_zero_bytes: 0,
    level_index_raw: 0,
    inventory_weapon_mask: 0,
    health: 0,
    armor: 0,
    current_ammo: 0,
    monster_total: 0,
    secret_total: 0,
    progress_non_default_bytes: 0,
    progress_checksum: 0,
    valid_marker: 0,
    difficulty_raw: 0,
    checksum_stored: 0,
    checksum_computed: 0,
    checksum_valid: false,
};

fn write_capabilities() -> u64 {
    let Some(mut w) = Writer::new(512) else {
        return 0;
    };
    w.bytes(b"{\"supported\":true,\"parserId\":\"saturn-quake-wasm\",\"abiVersion\":\"rsm-wasm-json-v1\",\"commands\":[\"capabilities\",\"parse\",\"readCheats\",\"applyCheats\"],\"operations\":[\"moduleReadOnly\"],\"editableFields\":0}");
    w.finish()
}

fn write_parse(input: &[u8]) -> u64 {
    let Some(analysis) = decode_and_analyze(input) else {
        return write_unsupported(b"expected Saturn backup RAM with Quake LOBOQUAKE__ entry");
    };

    let Some(mut w) = Writer::new(4096) else {
        return 0;
    };
    w.bytes(b"{\"supported\":true,\"parserLevel\":\"semantic\",\"parserId\":\"saturn-quake-wasm\",\"validatedSystem\":\"saturn\",\"validatedGameId\":\"saturn/quake\",\"validatedGameTitle\":\"Quake\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[\"validated Saturn backup RAM header\",\"found Saturn archive entry LOBOQUAKE__ with comment save games\",\"validated 1408-byte Quake entry geometry as 12 records of 116 bytes plus 16 bytes of padding\",\"validated per-record checksum as 16-bit byte sum over the first 114 record bytes\"],\"warnings\":[\"Read-only support: gameplay fields are exposed for inspection but no writes are enabled without additional before/after samples.\"],\"payloadSizeBytes\":");
    w.usize(analysis.payload_len);
    w.bytes(b",\"slotCount\":");
    w.usize(QUAKE_RECORD_COUNT);
    w.bytes(b",\"activeSlotIndexes\":[");
    write_active_slot_indexes(&mut w, &analysis);
    w.bytes(b"],\"checksumValid\":");
    w.bool(analysis.checksum_invalid_records == 0 && analysis.checksum_valid_records > 0);
    w.bytes(b",\"semanticFields\":{\"saturnEntryFilename\":\"LOBOQUAKE__\",\"saturnEntryComment\":\"save games\",\"saturnEntryVolume\":\"");
    if analysis.volume_internal {
        w.bytes(b"internal");
    } else {
        w.bytes(b"cartridge");
    }
    w.bytes(b"\",\"saturnEntryFirstBlock\":");
    w.usize(analysis.first_block);
    w.bytes(b",\"saturnEntryBlockCount\":");
    w.usize(analysis.entry_block_count);
    w.bytes(b",\"saturnArchiveEntries\":");
    w.usize(analysis.total_entries);
    w.bytes(b",\"saturnInterleaved\":");
    w.bool(analysis.interleaved);
    w.bytes(b",\"saturnEntrySizeBytes\":");
    w.usize(QUAKE_ENTRY_SIZE);
    w.bytes(b",\"quakeRecordCount\":");
    w.usize(QUAKE_RECORD_COUNT);
    w.bytes(b",\"quakeRecordSizeBytes\":");
    w.usize(QUAKE_RECORD_SIZE);
    w.bytes(b",\"quakeRecordNonZeroCount\":");
    w.usize(analysis.non_zero_records);
    w.bytes(b",\"quakeRecordValidMarkerCount\":");
    w.usize(analysis.valid_marker_records);
    w.bytes(b",\"quakeRecordChecksumValidCount\":");
    w.usize(analysis.checksum_valid_records);
    w.bytes(b",\"quakeRecordChecksumInvalidCount\":");
    w.usize(analysis.checksum_invalid_records);
    w.bytes(b",\"identicalCopies\":");
    w.bool(analysis.identical_records);
    w.bytes(b",\"currentSlot\":\"slot01\",\"currentLevel\":");
    w.usize(analysis.first_slot.level_index_raw as usize);
    w.bytes(b",\"difficultyRaw\":");
    w.usize(analysis.first_slot.difficulty_raw as usize);
    w.bytes(b",\"health\":");
    w.usize(analysis.first_slot.health as usize);
    w.bytes(b",\"armor\":");
    w.usize(analysis.first_slot.armor as usize);
    w.bytes(b",\"currentAmmo\":");
    w.usize(analysis.first_slot.current_ammo as usize);
    w.bytes(b",\"inventoryWeaponMask\":");
    w.usize(analysis.first_slot.inventory_weapon_mask as usize);
    w.bytes(b",\"monsterTotal\":");
    w.usize(analysis.first_slot.monster_total as usize);
    w.bytes(b",\"secretTotal\":");
    w.usize(analysis.first_slot.secret_total as usize);
    w.bytes(b",\"progressNonDefaultBytes\":");
    w.usize(analysis.first_slot.progress_non_default_bytes);
    w.bytes(b",\"slotChecksumStored\":");
    w.usize(analysis.first_slot.checksum_stored as usize);
    w.bytes(b",\"slotChecksumComputed\":");
    w.usize(analysis.first_slot.checksum_computed as usize);
    w.bytes(b",\"slotValidMarker\":");
    w.usize(analysis.first_slot.valid_marker as usize);
    w.bytes(b",\"trailingPaddingBytes\":");
    w.usize(QUAKE_PADDING_SIZE);
    w.bytes(b",\"readOnlyGameData\":true,\"safeWritableFields\":0}}");
    w.finish()
}

fn write_read_cheats(input: &[u8]) -> u64 {
    let Some(analysis) = decode_and_analyze(input) else {
        return write_unsupported(b"unsupported Saturn Quake save structure");
    };

    let Some(mut w) = Writer::new(16384) else {
        return 0;
    };
    w.bytes(b"{\"supported\":true,\"gameId\":\"saturn/quake\",\"systemSlug\":\"saturn\",\"editorId\":\"saturn-quake-wasm\",\"adapterId\":\"saturn-quake-wasm\",\"packId\":\"saturn--quake\",\"title\":\"Quake\",\"availableCount\":23,\"values\":{\"structureStatus\":\"verified\",\"quakeRecordCount\":");
    w.usize(QUAKE_RECORD_COUNT);
    w.bytes(b",\"quakeRecordSizeBytes\":");
    w.usize(QUAKE_RECORD_SIZE);
    w.bytes(b",\"saturnEntrySizeBytes\":");
    w.usize(QUAKE_ENTRY_SIZE);
    w.bytes(b",\"validSlotCount\":");
    w.usize(analysis.valid_marker_records);
    w.bytes(b",\"checksumValidSlotCount\":");
    w.usize(analysis.checksum_valid_records);
    w.bytes(b",\"checksumInvalidSlotCount\":");
    w.usize(analysis.checksum_invalid_records);
    w.bytes(b",\"identicalRecordCopies\":");
    w.bool(analysis.identical_records);
    w.bytes(b",\"safeWritableFields\":0,\"saturnEntryBlockCount\":");
    w.usize(analysis.entry_block_count);
    w.bytes(b",\"quakeRecordNonZeroCount\":");
    w.usize(analysis.non_zero_records);
    w.bytes(b"},\"slotValues\":{");
    for i in 0..QUAKE_RECORD_COUNT {
        if i > 0 {
            w.byte(b',');
        }
        w.bytes(b"\"slot");
        write_two_digits(&mut w, i + 1);
        w.bytes(b"\":{");
        write_slot_values(&mut w, analysis.slots[i]);
        w.byte(b'}');
    }
    w.bytes(b"}}");
    w.finish()
}

fn write_apply_cheats(input: &[u8]) -> u64 {
    if decode_and_analyze(input).is_none() {
        return write_apply_error(b"unsupported Saturn Quake save structure");
    }
    let Some((payload_start, payload_len)) = json_string_field(input, b"payload") else {
        return write_apply_error(b"payload missing");
    };
    let Some(mut w) = Writer::new(payload_len + 384) else {
        return 0;
    };
    w.bytes(b"{\"payload\":\"");
    w.bytes(&input[payload_start..payload_start + payload_len]);
    w.bytes(b"\",\"changed\":{},\"integritySteps\":[\"read-only Saturn Quake support: original payload returned unchanged because no safe write fields are currently proven\"]}");
    w.finish()
}

fn decode_and_analyze(input: &[u8]) -> Option<Analysis> {
    let (payload_start, payload_len) = json_string_field(input, b"payload")?;
    let b64 = &input[payload_start..payload_start + payload_len];
    let payload_len = base64_decoded_len(b64)?;

    match payload_len {
        SATURN_INTERNAL_RAW_SIZE => {
            decode_volume(b64, 0, SATURN_INTERNAL_RAW_SIZE, false, SATURN_INTERNAL_RAW_SIZE)?;
            analyze_loaded_volume(payload_len, true, false, SATURN_INTERNAL_BLOCK_SIZE)
        }
        SATURN_INTERNAL_INTERLEAVED_SIZE => {
            decode_volume(
                b64,
                0,
                SATURN_INTERNAL_INTERLEAVED_SIZE,
                true,
                SATURN_INTERNAL_RAW_SIZE,
            )?;
            analyze_loaded_volume(payload_len, true, true, SATURN_INTERNAL_BLOCK_SIZE)
        }
        SATURN_CARTRIDGE_RAW_SIZE => {
            decode_volume(b64, 0, SATURN_CARTRIDGE_RAW_SIZE, false, SATURN_CARTRIDGE_RAW_SIZE)?;
            analyze_loaded_volume(payload_len, false, false, SATURN_CARTRIDGE_BLOCK_SIZE)
        }
        SATURN_CARTRIDGE_INTERLEAVED_SIZE => {
            decode_volume(
                b64,
                0,
                SATURN_CARTRIDGE_INTERLEAVED_SIZE,
                true,
                SATURN_CARTRIDGE_RAW_SIZE,
            )?;
            analyze_loaded_volume(payload_len, false, true, SATURN_CARTRIDGE_BLOCK_SIZE)
        }
        SATURN_COMBINED_RAW_SIZE => {
            decode_volume(b64, 0, SATURN_INTERNAL_RAW_SIZE, false, SATURN_INTERNAL_RAW_SIZE)?;
            if let Some(analysis) =
                analyze_loaded_volume(payload_len, true, false, SATURN_INTERNAL_BLOCK_SIZE)
            {
                return Some(analysis);
            }
            decode_volume(
                b64,
                SATURN_INTERNAL_RAW_SIZE,
                SATURN_CARTRIDGE_RAW_SIZE,
                false,
                SATURN_CARTRIDGE_RAW_SIZE,
            )?;
            analyze_loaded_volume(payload_len, false, false, SATURN_CARTRIDGE_BLOCK_SIZE)
        }
        SATURN_COMBINED_INTERLEAVED_SIZE => {
            decode_volume(
                b64,
                0,
                SATURN_INTERNAL_INTERLEAVED_SIZE,
                true,
                SATURN_INTERNAL_RAW_SIZE,
            )?;
            if let Some(analysis) =
                analyze_loaded_volume(payload_len, true, true, SATURN_INTERNAL_BLOCK_SIZE)
            {
                return Some(analysis);
            }
            decode_volume(
                b64,
                SATURN_INTERNAL_INTERLEAVED_SIZE,
                SATURN_CARTRIDGE_INTERLEAVED_SIZE,
                true,
                SATURN_CARTRIDGE_RAW_SIZE,
            )?;
            analyze_loaded_volume(payload_len, false, true, SATURN_CARTRIDGE_BLOCK_SIZE)
        }
        _ => None,
    }
}

fn decode_volume(
    b64: &[u8],
    decoded_start: usize,
    decoded_len: usize,
    interleaved: bool,
    raw_len: usize,
) -> Option<()> {
    if raw_len > VOLUME_CAP {
        return None;
    }
    let decoded_end = decoded_start.checked_add(decoded_len)?;
    let mut global = 0usize;
    let mut raw_written = 0usize;
    let mut buf = 0u32;
    let mut bits = 0u8;

    unsafe {
        for b in &mut VOLUME[..raw_len] {
            *b = 0;
        }
    }

    for b in b64 {
        let value = match *b {
            b'A'..=b'Z' => *b - b'A',
            b'a'..=b'z' => *b - b'a' + 26,
            b'0'..=b'9' => *b - b'0' + 52,
            b'+' => 62,
            b'/' => 63,
            b'=' => break,
            b'\r' | b'\n' | b'\t' | b' ' => continue,
            _ => return None,
        } as u32;
        buf = (buf << 6) | value;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            let byte = ((buf >> bits) & 0xff) as u8;
            if global >= decoded_start && global < decoded_end {
                let local = global - decoded_start;
                if interleaved {
                    if local % 2 == 0 {
                        if byte != 0xff {
                            return None;
                        }
                    } else {
                        let raw_index = local / 2;
                        if raw_index >= raw_len {
                            return None;
                        }
                        unsafe {
                            VOLUME[raw_index] = byte;
                        }
                        raw_written += 1;
                    }
                } else {
                    if local >= raw_len {
                        return None;
                    }
                    unsafe {
                        VOLUME[local] = byte;
                    }
                    raw_written += 1;
                }
            }
            global += 1;
            if global >= decoded_end && raw_written >= raw_len {
                break;
            }
        }
    }
    if raw_written == raw_len {
        Some(())
    } else {
        None
    }
}

fn analyze_loaded_volume(
    payload_len: usize,
    volume_internal: bool,
    interleaved: bool,
    block_size: usize,
) -> Option<Analysis> {
    let raw_len = if volume_internal {
        SATURN_INTERNAL_RAW_SIZE
    } else {
        SATURN_CARTRIDGE_RAW_SIZE
    };
    unsafe {
        let raw = &VOLUME[..raw_len];
        if !saturn_header_valid(raw, block_size) {
            return None;
        }
        let total_blocks = raw_len / block_size;
        let mut total_entries = 0usize;
        let mut block = 2usize;
        while block < total_blocks {
            let offset = block * block_size;
            if offset + 4 > raw.len() {
                break;
            }
            if read_be_u32(raw, offset) == SATURN_ARCHIVE_ENTRY_MARKER {
                total_entries += 1;
                if let Some(analysis) = parse_quake_entry(
                    raw,
                    block_size,
                    total_blocks,
                    block,
                    payload_len,
                    volume_internal,
                    interleaved,
                    total_entries,
                ) {
                    return Some(analysis);
                }
            }
            block += 1;
        }
    }
    None
}

fn parse_quake_entry(
    raw: &[u8],
    block_size: usize,
    total_blocks: usize,
    first_block: usize,
    payload_len: usize,
    volume_internal: bool,
    interleaved: bool,
    total_entries_so_far: usize,
) -> Option<Analysis> {
    let offset = first_block * block_size;
    if offset + 0x22 > raw.len() {
        return None;
    }
    if &raw[offset + 0x04..offset + 0x0f] != b"LOBOQUAKE__" {
        return None;
    }
    if raw[offset + 0x0f] > 5 {
        return None;
    }
    if &raw[offset + 0x10..offset + 0x1a] != b"save games" {
        return None;
    }
    if read_be_u32(raw, offset + 0x1e) as usize != QUAKE_ENTRY_SIZE {
        return None;
    }

    let mut blocks = [0usize; 64];
    let mut block_count = 1usize;
    blocks[0] = first_block;
    let mut list_offset = offset + 0x22;
    let mut list_index = 1usize;
    loop {
        if list_offset + 2 > raw.len() {
            return None;
        }
        let next_block = read_be_u16(raw, list_offset) as usize;
        if next_block == 0 {
            break;
        }
        if next_block >= total_blocks || block_count >= blocks.len() {
            return None;
        }
        blocks[block_count] = next_block;
        block_count += 1;
        list_offset += 2;
        if list_offset % block_size == 0 {
            if list_index >= block_count {
                return None;
            }
            list_offset = blocks[list_index] * block_size + 4;
            list_index += 1;
        }
    }

    extract_entry_data(raw, block_size, &blocks[..block_count])?;
    let entry_stats = validate_quake_entry_data()?;
    Some(Analysis {
        payload_len,
        volume_internal,
        interleaved,
        entry_block_count: block_count,
        first_block,
        total_entries: total_entries_so_far,
        non_zero_records: entry_stats.non_zero_records,
        valid_marker_records: entry_stats.valid_marker_records,
        checksum_valid_records: entry_stats.checksum_valid_records,
        checksum_invalid_records: entry_stats.checksum_invalid_records,
        identical_records: entry_stats.identical_records,
        first_slot: entry_stats.first_slot,
        slots: entry_stats.slots,
    })
}

fn extract_entry_data(raw: &[u8], block_size: usize, blocks: &[usize]) -> Option<()> {
    let mut block_list_remaining = blocks.len() * 2;
    let mut remaining = QUAKE_ENTRY_SIZE;
    let mut out_len = 0usize;
    unsafe {
        for b in &mut ENTRY[..] {
            *b = 0;
        }
    }
    for (block_index, block) in blocks.iter().enumerate() {
        if remaining == 0 {
            break;
        }
        let block_offset = block.checked_mul(block_size)?;
        let mut inner = if block_index == 0 { 0x22 } else { 0x04 };
        let mut avail = block_size.checked_sub(inner)?;
        if block_list_remaining >= avail {
            block_list_remaining -= avail;
            continue;
        }
        if block_list_remaining > 0 {
            inner += block_list_remaining;
            avail -= block_list_remaining;
            block_list_remaining = 0;
        }
        let take = min(avail, remaining);
        if block_offset + inner + take > raw.len() || out_len + take > QUAKE_ENTRY_SIZE {
            return None;
        }
        unsafe {
            ENTRY[out_len..out_len + take].copy_from_slice(&raw[block_offset + inner..block_offset + inner + take]);
        }
        out_len += take;
        remaining -= take;
    }
    if remaining == 0 {
        Some(())
    } else {
        None
    }
}

#[derive(Clone, Copy)]
struct EntryStats {
    non_zero_records: usize,
    valid_marker_records: usize,
    checksum_valid_records: usize,
    checksum_invalid_records: usize,
    identical_records: bool,
    first_slot: SlotState,
    slots: [SlotState; QUAKE_RECORD_COUNT],
}

fn validate_quake_entry_data() -> Option<EntryStats> {
    let mut non_zero_records = 0usize;
    let mut valid_marker_records = 0usize;
    let mut checksum_valid_records = 0usize;
    let mut checksum_invalid_records = 0usize;
    let mut identical_records = true;
    let mut slots = [EMPTY_SLOT_STATE; QUAKE_RECORD_COUNT];
    let mut first_slot = EMPTY_SLOT_STATE;
    let mut first_slot_set = false;
    unsafe {
        for i in 0..QUAKE_PADDING_SIZE {
            if ENTRY[QUAKE_RECORD_COUNT * QUAKE_RECORD_SIZE + i] != 0 {
                return None;
            }
        }
        for record in 0..QUAKE_RECORD_COUNT {
            let start = record * QUAKE_RECORD_SIZE;
            let slot = analyze_slot(&ENTRY[start..start + QUAKE_RECORD_SIZE]);
            if record > 0 && ENTRY[start..start + QUAKE_RECORD_SIZE] != ENTRY[..QUAKE_RECORD_SIZE] {
                identical_records = false;
            }
            if slot.non_zero {
                non_zero_records += 1;
                if slot.valid_marker == 1 {
                    valid_marker_records += 1;
                }
                if slot.checksum_valid {
                    checksum_valid_records += 1;
                } else {
                    checksum_invalid_records += 1;
                }
                if !first_slot_set {
                    first_slot = slot;
                    first_slot_set = true;
                }
            }
            slots[record] = slot;
        }
    }
    if non_zero_records > 0 {
        Some(EntryStats {
            non_zero_records,
            valid_marker_records,
            checksum_valid_records,
            checksum_invalid_records,
            identical_records,
            first_slot,
            slots,
        })
    } else {
        None
    }
}

fn analyze_slot(record: &[u8]) -> SlotState {
    let mut non_zero_bytes = 0usize;
    for b in record {
        if *b != 0 {
            non_zero_bytes += 1;
        }
    }

    let mut checksum = 0u16;
    for b in &record[..QUAKE_CHECKSUM_OFFSET] {
        checksum = checksum.wrapping_add(*b as u16);
    }

    let mut progress_non_default_bytes = 0usize;
    let mut progress_checksum = 0u16;
    for b in &record[QUAKE_PROGRESS_OFFSET..QUAKE_PROGRESS_OFFSET + QUAKE_PROGRESS_SIZE] {
        progress_checksum = progress_checksum.wrapping_add(*b as u16);
        if *b != 0x10 {
            progress_non_default_bytes += 1;
        }
    }

    let checksum_stored = read_be_u16(record, QUAKE_CHECKSUM_OFFSET);
    SlotState {
        non_zero: non_zero_bytes > 0,
        non_zero_bytes,
        level_index_raw: read_be_u16(record, QUAKE_LEVEL_OFFSET),
        inventory_weapon_mask: read_be_u16(record, QUAKE_INVENTORY_WEAPON_MASK_OFFSET),
        health: read_be_u32(record, QUAKE_HEALTH_OFFSET),
        armor: read_be_u32(record, QUAKE_ARMOR_OFFSET),
        current_ammo: read_be_u32(record, QUAKE_CURRENT_AMMO_OFFSET),
        monster_total: read_be_u16(record, QUAKE_MONSTER_TOTAL_OFFSET),
        secret_total: read_be_u16(record, QUAKE_SECRET_TOTAL_OFFSET),
        progress_non_default_bytes,
        progress_checksum,
        valid_marker: read_be_u16(record, QUAKE_VALID_MARKER_OFFSET),
        difficulty_raw: read_be_u16(record, QUAKE_DIFFICULTY_OFFSET),
        checksum_stored,
        checksum_computed: checksum,
        checksum_valid: checksum == checksum_stored,
    }
}

fn write_active_slot_indexes(w: &mut Writer, analysis: &Analysis) {
    let mut written = 0usize;
    for i in 0..QUAKE_RECORD_COUNT {
        let slot = analysis.slots[i];
        if !slot.non_zero || slot.valid_marker != 1 || !slot.checksum_valid {
            continue;
        }
        if written > 0 {
            w.byte(b',');
        }
        w.usize(i);
        written += 1;
    }
}

fn write_slot_values(w: &mut Writer, slot: SlotState) {
    w.bytes(b"\"slotNonZeroBytes\":");
    w.usize(slot.non_zero_bytes);
    w.bytes(b",\"slotValidMarker\":");
    w.usize(slot.valid_marker as usize);
    w.bytes(b",\"checksumStatus\":\"");
    if slot.checksum_valid && slot.non_zero {
        w.bytes(b"valid");
    } else if slot.non_zero {
        w.bytes(b"invalid");
    } else {
        w.bytes(b"empty");
    }
    w.bytes(b"\",\"checksumStored\":");
    w.usize(slot.checksum_stored as usize);
    w.bytes(b",\"checksumComputed\":");
    w.usize(slot.checksum_computed as usize);
    w.bytes(b",\"levelIndexRaw\":");
    w.usize(slot.level_index_raw as usize);
    w.bytes(b",\"difficultyRaw\":");
    w.usize(slot.difficulty_raw as usize);
    w.bytes(b",\"health\":");
    w.usize(slot.health as usize);
    w.bytes(b",\"armor\":");
    w.usize(slot.armor as usize);
    w.bytes(b",\"currentAmmo\":");
    w.usize(slot.current_ammo as usize);
    w.bytes(b",\"inventoryWeaponMask\":");
    w.usize(slot.inventory_weapon_mask as usize);
    w.bytes(b",\"weaponBits\":");
    write_weapon_bits(w, slot.inventory_weapon_mask);
    w.bytes(b",\"monsterTotal\":");
    w.usize(slot.monster_total as usize);
    w.bytes(b",\"secretTotal\":");
    w.usize(slot.secret_total as usize);
    w.bytes(b",\"progressByteCount\":");
    w.usize(QUAKE_PROGRESS_SIZE);
    w.bytes(b",\"progressNonDefaultBytes\":");
    w.usize(slot.progress_non_default_bytes);
    w.bytes(b",\"progressChecksum\":");
    w.usize(slot.progress_checksum as usize);
}

fn write_weapon_bits(w: &mut Writer, mask: u16) {
    w.byte(b'[');
    let mut written = 0usize;
    for bit in 0..16 {
        if (mask & (1u16 << bit)) == 0 {
            continue;
        }
        if written > 0 {
            w.byte(b',');
        }
        match bit {
            8 => w.bytes(b"\"weaponBit8\""),
            9 => w.bytes(b"\"weaponBit9\""),
            10 => w.bytes(b"\"weaponBit10\""),
            11 => w.bytes(b"\"weaponBit11\""),
            12 => w.bytes(b"\"weaponBit12\""),
            13 => w.bytes(b"\"weaponBit13\""),
            14 => w.bytes(b"\"weaponBit14\""),
            15 => w.bytes(b"\"weaponBit15\""),
            _ => {
                w.bytes(b"\"bit");
                w.usize(bit);
                w.byte(b'"');
            }
        }
        written += 1;
    }
    w.byte(b']');
}

fn write_two_digits(w: &mut Writer, value: usize) {
    w.byte(b'0' + ((value / 10) % 10) as u8);
    w.byte(b'0' + (value % 10) as u8);
}

fn saturn_header_valid(raw: &[u8], block_size: usize) -> bool {
    if raw.len() < block_size * 2 {
        return false;
    }
    let limit = min(0x40, block_size);
    for i in 0..limit {
        if raw[i] != SATURN_HEADER_MAGIC[i % SATURN_HEADER_MAGIC.len()] {
            return false;
        }
    }
    for b in &raw[block_size..block_size * 2] {
        if *b != 0 {
            return false;
        }
    }
    true
}

fn read_be_u16(bytes: &[u8], offset: usize) -> u16 {
    ((bytes[offset] as u16) << 8) | bytes[offset + 1] as u16
}

fn read_be_u32(bytes: &[u8], offset: usize) -> u32 {
    ((bytes[offset] as u32) << 24)
        | ((bytes[offset + 1] as u32) << 16)
        | ((bytes[offset + 2] as u32) << 8)
        | bytes[offset + 3] as u32
}

fn base64_decoded_len(input: &[u8]) -> Option<usize> {
    let mut out_len = 0usize;
    let mut buf = 0u32;
    let mut bits = 0u8;
    for b in input {
        let value = match *b {
            b'A'..=b'Z' => *b - b'A',
            b'a'..=b'z' => *b - b'a' + 26,
            b'0'..=b'9' => *b - b'0' + 52,
            b'+' => 62,
            b'/' => 63,
            b'=' => break,
            b'\r' | b'\n' | b'\t' | b' ' => continue,
            _ => return None,
        } as u32;
        buf = (buf << 6) | value;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out_len += 1;
        }
    }
    Some(out_len)
}

fn json_string_field(input: &[u8], key: &[u8]) -> Option<(usize, usize)> {
    let key_pos = find_key(input, key)?;
    let mut i = key_pos + key.len() + 2;
    while i < input.len() && input[i].is_ascii_whitespace() {
        i += 1;
    }
    if i >= input.len() || input[i] != b':' {
        return None;
    }
    i += 1;
    while i < input.len() && input[i].is_ascii_whitespace() {
        i += 1;
    }
    if i >= input.len() || input[i] != b'"' {
        return None;
    }
    i += 1;
    let start = i;
    while i < input.len() {
        match input[i] {
            b'"' => return Some((start, i - start)),
            b'\\' => i += 2,
            _ => i += 1,
        }
    }
    None
}

fn find_key(input: &[u8], key: &[u8]) -> Option<usize> {
    if key.is_empty() || input.len() < key.len() + 2 {
        return None;
    }
    let mut i = 0usize;
    while i + key.len() + 2 <= input.len() {
        if input[i] == b'"'
            && input[i + key.len() + 1] == b'"'
            && &input[i + 1..i + 1 + key.len()] == key
        {
            return Some(i);
        }
        i += 1;
    }
    None
}

fn write_unsupported(reason: &[u8]) -> u64 {
    let Some(mut w) = Writer::new(256) else {
        return 0;
    };
    w.bytes(b"{\"supported\":false,\"warnings\":[");
    w.escaped_json_string(reason);
    w.bytes(b"]}");
    w.finish()
}

fn write_apply_error(reason: &[u8]) -> u64 {
    let Some(mut w) = Writer::new(256) else {
        return 0;
    };
    w.bytes(b"{\"payload\":\"\",\"changed\":{},\"integritySteps\":[");
    w.escaped_json_string(reason);
    w.bytes(b"]}");
    w.finish()
}
