#include <stdbool.h>
#include <stdint.h>

extern unsigned char __heap_base;

static uint32_t heap_ptr = 0;

static void *rsm_bump_alloc(uint32_t len) {
    if (heap_ptr == 0) {
        heap_ptr = (uint32_t)(uintptr_t)&__heap_base;
    }
    heap_ptr = (heap_ptr + 7u) & ~7u;
    void *ptr = (void *)(uintptr_t)heap_ptr;
    heap_ptr += (len + 7u) & ~7u;
    return ptr;
}

__attribute__((export_name("rsm_alloc")))
int32_t rsm_alloc(int32_t len) {
    if (len <= 0) {
        return 0;
    }
    return (int32_t)(uintptr_t)rsm_bump_alloc((uint32_t)len);
}

typedef struct {
    char *data;
    uint32_t len;
    uint32_t cap;
} builder;

static void b_init(builder *b, uint32_t cap) {
    b->data = (char *)rsm_bump_alloc(cap);
    b->len = 0;
    b->cap = cap;
}

static void b_char(builder *b, char c) {
    if (b->len < b->cap) {
        b->data[b->len++] = c;
    }
}

static uint32_t c_len(const char *s) {
    uint32_t n = 0;
    while (s[n] != 0) {
        n++;
    }
    return n;
}

static void b_strn(builder *b, const char *s, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) {
        b_char(b, s[i]);
    }
}

static void b_str(builder *b, const char *s) {
    b_strn(b, s, c_len(s));
}

static void b_u64(builder *b, uint64_t value) {
    char tmp[24];
    uint32_t n = 0;
    if (value == 0) {
        b_char(b, '0');
        return;
    }
    while (value > 0 && n < sizeof(tmp)) {
        tmp[n++] = (char)('0' + (value % 10u));
        value /= 10u;
    }
    while (n > 0) {
        b_char(b, tmp[--n]);
    }
}

static uint64_t finish(builder *b) {
    return ((uint64_t)(uint32_t)(uintptr_t)b->data << 32) | (uint64_t)b->len;
}

static bool bytes_eq(const uint8_t *a, const char *b, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) {
        if (a[i] != (uint8_t)b[i]) {
            return false;
        }
    }
    return true;
}

static int32_t find_bytes(const uint8_t *input, uint32_t len, const char *needle, uint32_t needle_len) {
    if (needle_len == 0 || len < needle_len) {
        return -1;
    }
    for (uint32_t i = 0; i <= len - needle_len; i++) {
        bool ok = true;
        for (uint32_t j = 0; j < needle_len; j++) {
            if (input[i + j] != (uint8_t)needle[j]) {
                ok = false;
                break;
            }
        }
        if (ok) {
            return (int32_t)i;
        }
    }
    return -1;
}

static uint32_t skip_ws(const uint8_t *input, uint32_t len, uint32_t idx) {
    while (idx < len) {
        uint8_t c = input[idx];
        if (c != ' ' && c != '\n' && c != '\r' && c != '\t') {
            break;
        }
        idx++;
    }
    return idx;
}

typedef struct {
    const uint8_t *ptr;
    uint32_t len;
} slice;

static bool json_string_raw(const uint8_t *input, uint32_t len, const char *field, slice *out) {
    char key[80];
    uint32_t field_len = c_len(field);
    if (field_len + 2 >= sizeof(key)) {
        return false;
    }
    key[0] = '"';
    for (uint32_t i = 0; i < field_len; i++) {
        key[i + 1] = field[i];
    }
    key[field_len + 1] = '"';
    key[field_len + 2] = 0;
    int32_t found = find_bytes(input, len, key, field_len + 2);
    if (found < 0) {
        return false;
    }
    uint32_t idx = skip_ws(input, len, (uint32_t)found + field_len + 2);
    if (idx >= len || input[idx] != ':') {
        return false;
    }
    idx = skip_ws(input, len, idx + 1);
    if (idx >= len || input[idx] != '"') {
        return false;
    }
    uint32_t start = idx + 1;
    idx = start;
    while (idx < len) {
        if (input[idx] == '\\') {
            idx += 2;
            continue;
        }
        if (input[idx] == '"') {
            out->ptr = input + start;
            out->len = idx - start;
            return true;
        }
        idx++;
    }
    return false;
}

static bool json_object_raw(const uint8_t *input, uint32_t len, const char *field, slice *out) {
    char key[80];
    uint32_t field_len = c_len(field);
    if (field_len + 2 >= sizeof(key)) {
        return false;
    }
    key[0] = '"';
    for (uint32_t i = 0; i < field_len; i++) {
        key[i + 1] = field[i];
    }
    key[field_len + 1] = '"';
    key[field_len + 2] = 0;
    int32_t found = find_bytes(input, len, key, field_len + 2);
    if (found < 0) {
        return false;
    }
    uint32_t idx = skip_ws(input, len, (uint32_t)found + field_len + 2);
    if (idx >= len || input[idx] != ':') {
        return false;
    }
    idx = skip_ws(input, len, idx + 1);
    if (idx >= len || input[idx] != '{') {
        return false;
    }
    uint32_t start = idx;
    int32_t depth = 0;
    bool in_string = false;
    while (idx < len) {
        uint8_t c = input[idx];
        if (in_string) {
            if (c == '\\') {
                idx += 2;
                continue;
            }
            if (c == '"') {
                in_string = false;
            }
            idx++;
            continue;
        }
        if (c == '"') {
            in_string = true;
        } else if (c == '{') {
            depth++;
        } else if (c == '}') {
            depth--;
            if (depth == 0) {
                out->ptr = input + start;
                out->len = idx - start + 1;
                return true;
            }
        }
        idx++;
    }
    return false;
}

static bool field_value_start(slice updates, const char *field, uint32_t *idx_out) {
    char key[96];
    uint32_t n = c_len(field);
    if (n + 2 >= sizeof(key)) {
        return false;
    }
    key[0] = '"';
    for (uint32_t i = 0; i < n; i++) {
        key[i + 1] = field[i];
    }
    key[n + 1] = '"';
    key[n + 2] = 0;
    int32_t found = find_bytes(updates.ptr, updates.len, key, n + 2);
    if (found < 0) {
        return false;
    }
    uint32_t idx = skip_ws(updates.ptr, updates.len, (uint32_t)found + n + 2);
    if (idx >= updates.len || updates.ptr[idx] != ':') {
        return false;
    }
    *idx_out = skip_ws(updates.ptr, updates.len, idx + 1);
    return true;
}

static bool parse_bool_value(slice updates, const char *field, bool *value) {
    uint32_t idx = 0;
    if (!field_value_start(updates, field, &idx)) {
        return false;
    }
    if (idx + 4 <= updates.len && bytes_eq(updates.ptr + idx, "true", 4)) {
        *value = true;
        return true;
    }
    if (idx + 5 <= updates.len && bytes_eq(updates.ptr + idx, "false", 5)) {
        *value = false;
        return true;
    }
    return false;
}

static int b64_value(uint8_t c) {
    if (c >= 'A' && c <= 'Z') return (int)(c - 'A');
    if (c >= 'a' && c <= 'z') return (int)(c - 'a' + 26);
    if (c >= '0' && c <= '9') return (int)(c - '0' + 52);
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

static bool base64_decode(slice encoded, uint8_t **out, uint32_t *out_len) {
    uint32_t cap = (encoded.len / 4u) * 3u + 3u;
    uint8_t *dst = (uint8_t *)rsm_bump_alloc(cap);
    uint32_t n = 0;
    for (uint32_t i = 0; i < encoded.len;) {
        int vals[4] = {0, 0, 0, 0};
        int pad = 0;
        for (uint32_t j = 0; j < 4; j++) {
            if (i >= encoded.len) {
                return false;
            }
            uint8_t c = encoded.ptr[i++];
            if (c == '=') {
                vals[j] = 0;
                pad++;
            } else {
                vals[j] = b64_value(c);
                if (vals[j] < 0) {
                    return false;
                }
            }
        }
        uint32_t triple = ((uint32_t)vals[0] << 18) | ((uint32_t)vals[1] << 12) | ((uint32_t)vals[2] << 6) | (uint32_t)vals[3];
        if (n < cap) dst[n++] = (uint8_t)((triple >> 16) & 0xff);
        if (pad < 2 && n < cap) dst[n++] = (uint8_t)((triple >> 8) & 0xff);
        if (pad < 1 && n < cap) dst[n++] = (uint8_t)(triple & 0xff);
    }
    *out = dst;
    *out_len = n;
    return true;
}

static const char b64_table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static void b_base64(builder *b, const uint8_t *src, uint32_t len) {
    uint32_t i = 0;
    while (i < len) {
        uint32_t a = src[i++];
        uint32_t have_b = i < len;
        uint32_t b2 = have_b ? src[i++] : 0;
        uint32_t have_c = i < len;
        uint32_t c = have_c ? src[i++] : 0;
        uint32_t triple = (a << 16) | (b2 << 8) | c;
        b_char(b, b64_table[(triple >> 18) & 0x3f]);
        b_char(b, b64_table[(triple >> 12) & 0x3f]);
        b_char(b, have_b ? b64_table[(triple >> 6) & 0x3f] : '=');
        b_char(b, have_c ? b64_table[triple & 0x3f] : '=');
    }
}

static uint64_t error_response(const char *message) {
    builder b;
    b_init(&b, 256);
    b_str(&b, "{\"supported\":false,\"error\":\"");
    b_str(&b, message);
    b_str(&b, "\"}");
    return finish(&b);
}

static bool decode_payload(const uint8_t *input, uint32_t input_len, uint8_t **payload, uint32_t *payload_len) {
    slice encoded = {0};
    if (!json_string_raw(input, input_len, "payload", &encoded)) {
        return false;
    }
    return base64_decode(encoded, payload, payload_len);
}

#define SMW_SRAM_SIZE 2048u
#define SMW_USED_BYTES 0x35au
#define SMW_SLOT_COUNT 3u
#define SMW_BLOCK_SIZE 0x8fu
#define SMW_DATA_SIZE 0x8du
#define SMW_CHECKSUM_BASE 0x5a5au
#define SMW_LEVEL_FLAGS_OFFSET 0x00u
#define SMW_EVENT_FLAGS_OFFSET 0x60u
#define SMW_MARIO_SUBMAP_OFFSET 0x6fu
#define SMW_LUIGI_SUBMAP_OFFSET 0x70u
#define SMW_MARIO_ANIMATION_OFFSET 0x71u
#define SMW_LUIGI_ANIMATION_OFFSET 0x73u
#define SMW_MARIO_X_OFFSET 0x75u
#define SMW_MARIO_Y_OFFSET 0x77u
#define SMW_LUIGI_X_OFFSET 0x79u
#define SMW_LUIGI_Y_OFFSET 0x7bu
#define SMW_MARIO_X_PTR_OFFSET 0x7du
#define SMW_MARIO_Y_PTR_OFFSET 0x7fu
#define SMW_LUIGI_X_PTR_OFFSET 0x81u
#define SMW_LUIGI_Y_PTR_OFFSET 0x83u
#define SMW_SWITCH_OFFSET 0x85u
#define SMW_EVENT_COUNT_OFFSET 0x8cu
#define SMW_LEVEL_FLAG_COUNT 96u
#define SMW_EVENT_FLAG_COUNT 120u
#define LEVEL_BEATEN_MASK 0x80u
#define LEVEL_MIDWAY_MASK 0x20u
#define LEVEL_MOVE_UP_MASK 0x08u
#define LEVEL_MOVE_DOWN_MASK 0x04u
#define LEVEL_MOVE_LEFT_MASK 0x02u
#define LEVEL_MOVE_RIGHT_MASK 0x01u

static const uint8_t verified_96_exit_data[SMW_DATA_SIZE] = {0x00,0x83,0x83,0x04,0x8f,0x87,0x89,0x8a,0x81,0x8e,0x8d,0x83,0x83,0x83,0x87,0x87,0x86,0x8c,0x04,0x8d,0x84,0x8e,0x08,0x00,0x8a,0x00,0x8e,0x85,0x89,0x8a,0x01,0x83,0x85,0x85,0x8a,0x8f,0x8e,0x89,0x8c,0x85,0x03,0x89,0x8a,0x85,0x01,0x8e,0x8c,0x85,0x05,0x06,0x04,0x8d,0x8e,0x8c,0x00,0x89,0x8b,0x8b,0x83,0x83,0x8d,0x8c,0x87,0x88,0x8c,0x87,0x8b,0x8d,0x8f,0x83,0x8c,0x87,0x01,0x83,0x83,0x83,0x83,0x01,0x83,0x83,0x83,0x83,0x03,0x05,0x8a,0x04,0x89,0x06,0x86,0x85,0x8b,0x09,0x0a,0x00,0x00,0x00,0x7f,0xff,0xff,0xff,0xff,0xff,0xfd,0xff,0xc3,0xff,0x6d,0xb6,0xf7,0xf8,0x00,0x05,0x05,0x02,0x00,0x02,0x00,0x38,0x01,0x18,0x01,0x38,0x01,0x18,0x01,0x13,0x00,0x11,0x00,0x13,0x00,0x11,0x00,0x01,0x01,0x01,0x01,0x00,0x00,0x00,0x60};

static bool parse_u64_value(slice updates, const char *field, uint64_t *value) {
    uint32_t idx = 0;
    if (!field_value_start(updates, field, &idx)) return false;
    uint64_t out = 0;
    bool any = false;
    while (idx < updates.len && updates.ptr[idx] >= '0' && updates.ptr[idx] <= '9') {
        any = true;
        out = out * 10u + (uint64_t)(updates.ptr[idx] - '0');
        idx++;
    }
    if (!any) return false;
    *value = out;
    return true;
}

static bool parse_string_value(slice updates, const char *field, slice *out) {
    uint32_t idx = 0;
    if (!field_value_start(updates, field, &idx)) return false;
    if (idx >= updates.len || updates.ptr[idx] != '"') return false;
    uint32_t start = ++idx;
    while (idx < updates.len) {
        if (updates.ptr[idx] == '\\') { idx += 2; continue; }
        if (updates.ptr[idx] == '"') {
            out->ptr = updates.ptr + start;
            out->len = idx - start;
            return true;
        }
        idx++;
    }
    return false;
}

static bool parse_fixed_decimal_id(slice item, const char *prefix_text, uint32_t digits, uint32_t max_value, uint32_t *value) {
    uint32_t prefix_len = c_len(prefix_text);
    if (item.len != prefix_len + digits) return false;
    for (uint32_t i = 0; i < prefix_len; i++) {
        if (item.ptr[i] != (uint8_t)prefix_text[i]) return false;
    }
    uint32_t out = 0;
    for (uint32_t i = 0; i < digits; i++) {
        uint8_t c = item.ptr[prefix_len + i];
        if (c < '0' || c > '9') return false;
        out = out * 10u + (uint32_t)(c - '0');
    }
    if (out >= max_value) return false;
    *value = out;
    return true;
}

static bool parse_bitmask_value(slice updates, const char *field, const char *prefix_text, uint32_t digits, uint32_t count, bool *selected) {
    uint32_t idx = 0;
    if (!field_value_start(updates, field, &idx)) return false;
    if (idx >= updates.len || updates.ptr[idx] != '[') return false;
    for (uint32_t i = 0; i < count; i++) selected[i] = false;
    idx++;
    while (idx < updates.len) {
        idx = skip_ws(updates.ptr, updates.len, idx);
        if (idx < updates.len && updates.ptr[idx] == ']') return true;
        if (idx >= updates.len || updates.ptr[idx] != '"') return false;
        uint32_t start = ++idx;
        while (idx < updates.len && updates.ptr[idx] != '"') idx++;
        if (idx >= updates.len) return false;
        slice item = {updates.ptr + start, idx - start};
        uint32_t bit = 0;
        if (!parse_fixed_decimal_id(item, prefix_text, digits, count, &bit)) return false;
        selected[bit] = true;
        idx++;
        idx = skip_ws(updates.ptr, updates.len, idx);
        if (idx < updates.len && updates.ptr[idx] == ',') idx++;
    }
    return false;
}

typedef struct {
    bool primary_valid;
    bool backup_valid;
    bool active;
    bool copies_match;
    uint32_t source_start;
} slot_info;

typedef struct {
    bool supported;
    bool blank;
    slot_info slots[SMW_SLOT_COUNT];
    uint32_t valid_slots;
} inspection;

static uint32_t primary_start(uint32_t slot) { return slot * SMW_BLOCK_SIZE; }
static uint32_t backup_start(uint32_t slot) { return 0x1adu + slot * SMW_BLOCK_SIZE; }
static const char *slot_id(uint32_t slot) { if (slot == 0) return "A"; if (slot == 1) return "B"; return "C"; }

static bool all_same_byte(const uint8_t *payload, uint32_t len, uint8_t value) {
    for (uint32_t i = 0; i < len; i++) if (payload[i] != value) return false;
    return true;
}

static bool block_nonzero(const uint8_t *block) {
    for (uint32_t i = 0; i < SMW_BLOCK_SIZE; i++) if (block[i] != 0) return true;
    return false;
}

static uint16_t read_u16_le(const uint8_t *buf, uint32_t offset) { return (uint16_t)buf[offset] | ((uint16_t)buf[offset + 1] << 8); }
static void write_u16_le(uint8_t *buf, uint32_t offset, uint16_t value) { buf[offset] = (uint8_t)(value & 0xff); buf[offset + 1] = (uint8_t)((value >> 8) & 0xff); }

static uint16_t smw_checksum(const uint8_t *block) {
    uint32_t sum = 0;
    for (uint32_t i = 0; i < SMW_DATA_SIZE; i++) sum = (sum + block[i]) & 0xffffu;
    return (uint16_t)((SMW_CHECKSUM_BASE - sum) & 0xffffu);
}

static bool verify_block(const uint8_t *payload, uint32_t len, uint32_t start) {
    if (len != SMW_SRAM_SIZE || start + SMW_BLOCK_SIZE > len) return false;
    const uint8_t *block = payload + start;
    if (!block_nonzero(block)) return false;
    return read_u16_le(block, SMW_DATA_SIZE) == smw_checksum(block);
}

static bool blocks_equal(const uint8_t *a, const uint8_t *b) {
    for (uint32_t i = 0; i < SMW_BLOCK_SIZE; i++) if (a[i] != b[i]) return false;
    return true;
}

static inspection inspect_payload(const uint8_t *payload, uint32_t len) {
    inspection out = {0};
    if (len != SMW_SRAM_SIZE) return out;
    out.blank = all_same_byte(payload, len, 0x00) || all_same_byte(payload, len, 0xff);
    for (uint32_t slot = 0; slot < SMW_SLOT_COUNT; slot++) {
        uint32_t p = primary_start(slot);
        uint32_t b = backup_start(slot);
        slot_info info = {0};
        info.primary_valid = verify_block(payload, len, p);
        info.backup_valid = verify_block(payload, len, b);
        info.active = info.primary_valid || info.backup_valid;
        info.source_start = info.primary_valid ? p : b;
        info.copies_match = info.primary_valid && info.backup_valid && blocks_equal(payload + p, payload + b);
        out.slots[slot] = info;
        if (info.active) out.valid_slots++;
    }
    out.supported = out.valid_slots > 0 || out.blank;
    return out;
}

static const char *submap_id(uint8_t value) {
    switch (value) {
        case 0: return "main";
        case 1: return "yoshisIsland";
        case 2: return "vanillaDome";
        case 3: return "forestOfIllusion";
        case 4: return "valleyOfBowser";
        case 5: return "specialWorld";
        case 6: return "starWorld";
        default: return "unknown";
    }
}

static bool parse_submap_value(slice raw, uint8_t *value) {
    const char *ids[] = {"main","yoshisIsland","vanillaDome","forestOfIllusion","valleyOfBowser","specialWorld","starWorld"};
    for (uint32_t i = 0; i < 7; i++) {
        uint32_t n = c_len(ids[i]);
        if (raw.len == n && bytes_eq(raw.ptr, ids[i], n)) { *value = (uint8_t)i; return true; }
    }
    return false;
}

static void b_dec_fixed(builder *b, uint32_t value, uint32_t digits) {
    uint32_t div = 1;
    for (uint32_t i = 1; i < digits; i++) div *= 10u;
    while (div > 0) {
        b_char(b, (char)('0' + ((value / div) % 10u)));
        div /= 10u;
    }
}

static void append_numbered_array(builder *b, const char *prefix_text, uint32_t digits, const uint8_t *bytes, uint32_t count, uint8_t mask) {
    b_char(b, '[');
    bool first = true;
    for (uint32_t i = 0; i < count; i++) {
        if ((bytes[i] & mask) != 0) {
            if (!first) b_char(b, ',');
            b_char(b, '"');
            b_str(b, prefix_text);
            b_dec_fixed(b, i, digits);
            b_char(b, '"');
            first = false;
        }
    }
    b_char(b, ']');
}

static void append_event_array(builder *b, const uint8_t *block) {
    b_char(b, '[');
    bool first = true;
    for (uint32_t i = 0; i < SMW_EVENT_FLAG_COUNT; i++) {
        uint32_t byte_index = i >> 3;
        uint8_t bit_mask = (uint8_t)(1u << (i & 7u));
        if ((block[SMW_EVENT_FLAGS_OFFSET + byte_index] & bit_mask) != 0) {
            if (!first) b_char(b, ',');
            b_char(b, '"');
            b_str(b, "event");
            b_dec_fixed(b, i, 3);
            b_char(b, '"');
            first = false;
        }
    }
    b_char(b, ']');
}

static void append_switch_array(builder *b, const uint8_t *block) {
    const char *names[] = {"green", "yellow", "blue", "red"};
    b_char(b, '[');
    bool first = true;
    for (uint32_t i = 0; i < 4; i++) {
        if (block[SMW_SWITCH_OFFSET + i]) {
            if (!first) b_char(b, ',');
            b_char(b, '"'); b_str(b, names[i]); b_char(b, '"'); first = false;
        }
    }
    b_char(b, ']');
}

static void append_slot_values(builder *b, const uint8_t *block) {
    b_str(b, "{\"createBlankFile\":false,\"install96ExitTemplate\":false");
    b_str(b, ",\"eventCount\":"); b_u64(b, block[SMW_EVENT_COUNT_OFFSET]);
    b_str(b, ",\"overworldEvents\":"); append_event_array(b, block);
    b_str(b, ",\"greenSwitchBlocks\":"); b_str(b, block[SMW_SWITCH_OFFSET] ? "true" : "false");
    b_str(b, ",\"yellowSwitchBlocks\":"); b_str(b, block[SMW_SWITCH_OFFSET + 1u] ? "true" : "false");
    b_str(b, ",\"blueSwitchBlocks\":"); b_str(b, block[SMW_SWITCH_OFFSET + 2u] ? "true" : "false");
    b_str(b, ",\"redSwitchBlocks\":"); b_str(b, block[SMW_SWITCH_OFFSET + 3u] ? "true" : "false");
    b_str(b, ",\"levelBeatenFlags\":"); append_numbered_array(b, "level", 2, block + SMW_LEVEL_FLAGS_OFFSET, SMW_LEVEL_FLAG_COUNT, LEVEL_BEATEN_MASK);
    b_str(b, ",\"levelMidwayFlags\":"); append_numbered_array(b, "level", 2, block + SMW_LEVEL_FLAGS_OFFSET, SMW_LEVEL_FLAG_COUNT, LEVEL_MIDWAY_MASK);
    b_str(b, ",\"levelMoveUpFlags\":"); append_numbered_array(b, "level", 2, block + SMW_LEVEL_FLAGS_OFFSET, SMW_LEVEL_FLAG_COUNT, LEVEL_MOVE_UP_MASK);
    b_str(b, ",\"levelMoveDownFlags\":"); append_numbered_array(b, "level", 2, block + SMW_LEVEL_FLAGS_OFFSET, SMW_LEVEL_FLAG_COUNT, LEVEL_MOVE_DOWN_MASK);
    b_str(b, ",\"levelMoveLeftFlags\":"); append_numbered_array(b, "level", 2, block + SMW_LEVEL_FLAGS_OFFSET, SMW_LEVEL_FLAG_COUNT, LEVEL_MOVE_LEFT_MASK);
    b_str(b, ",\"levelMoveRightFlags\":"); append_numbered_array(b, "level", 2, block + SMW_LEVEL_FLAGS_OFFSET, SMW_LEVEL_FLAG_COUNT, LEVEL_MOVE_RIGHT_MASK);
    b_str(b, ",\"marioSubmap\":\""); b_str(b, submap_id(block[SMW_MARIO_SUBMAP_OFFSET])); b_char(b, '"');
    b_str(b, ",\"luigiSubmap\":\""); b_str(b, submap_id(block[SMW_LUIGI_SUBMAP_OFFSET])); b_char(b, '"');
    b_str(b, ",\"marioOverworldAnimation\":"); b_u64(b, read_u16_le(block, SMW_MARIO_ANIMATION_OFFSET));
    b_str(b, ",\"luigiOverworldAnimation\":"); b_u64(b, read_u16_le(block, SMW_LUIGI_ANIMATION_OFFSET));
    b_str(b, ",\"marioOverworldX\":"); b_u64(b, read_u16_le(block, SMW_MARIO_X_OFFSET));
    b_str(b, ",\"marioOverworldY\":"); b_u64(b, read_u16_le(block, SMW_MARIO_Y_OFFSET));
    b_str(b, ",\"luigiOverworldX\":"); b_u64(b, read_u16_le(block, SMW_LUIGI_X_OFFSET));
    b_str(b, ",\"luigiOverworldY\":"); b_u64(b, read_u16_le(block, SMW_LUIGI_Y_OFFSET));
    b_str(b, ",\"marioOverworldXPointer\":"); b_u64(b, read_u16_le(block, SMW_MARIO_X_PTR_OFFSET));
    b_str(b, ",\"marioOverworldYPointer\":"); b_u64(b, read_u16_le(block, SMW_MARIO_Y_PTR_OFFSET));
    b_str(b, ",\"luigiOverworldXPointer\":"); b_u64(b, read_u16_le(block, SMW_LUIGI_X_PTR_OFFSET));
    b_str(b, ",\"luigiOverworldYPointer\":"); b_u64(b, read_u16_le(block, SMW_LUIGI_Y_PTR_OFFSET));
    b_char(b, '}');
}

static void build_blank_block(uint8_t *block) {
    for (uint32_t i = 0; i < SMW_BLOCK_SIZE; i++) block[i] = 0;
    block[0x28] = 0x03; block[0x4d] = 0x01; block[0x52] = 0x01; block[0x53] = 0x01;
    block[0x5b] = 0x08; block[0x5c] = 0x02; block[0x57] = 0x04; block[0x30] = 0x01;
    block[SMW_MARIO_SUBMAP_OFFSET] = 1; block[SMW_LUIGI_SUBMAP_OFFSET] = 1;
    write_u16_le(block, SMW_MARIO_ANIMATION_OFFSET, 2); write_u16_le(block, SMW_LUIGI_ANIMATION_OFFSET, 2);
    write_u16_le(block, SMW_MARIO_X_OFFSET, 0x68); write_u16_le(block, SMW_MARIO_Y_OFFSET, 0x78);
    write_u16_le(block, SMW_LUIGI_X_OFFSET, 0x68); write_u16_le(block, SMW_LUIGI_Y_OFFSET, 0x78);
    write_u16_le(block, SMW_MARIO_X_PTR_OFFSET, 0x06); write_u16_le(block, SMW_MARIO_Y_PTR_OFFSET, 0x07);
    write_u16_le(block, SMW_LUIGI_X_PTR_OFFSET, 0x06); write_u16_le(block, SMW_LUIGI_Y_PTR_OFFSET, 0x07);
}

static void append_blank_values(builder *b) {
    uint8_t block[SMW_BLOCK_SIZE];
    build_blank_block(block);
    append_slot_values(b, block);
}

static void append_slot_semantic(builder *b, const uint8_t *payload, const inspection *insp, uint32_t slot, bool *first) {
    const char *id = slot_id(slot);
    const slot_info *info = &insp->slots[slot];
    if (!*first) b_char(b, ',');
    b_str(b, "\"slot"); b_str(b, id); b_str(b, "Valid\":"); b_str(b, info->active ? "true" : "false");
    *first = false;
    if (!info->active) return;
    const uint8_t *block = payload + info->source_start;
    b_str(b, ",\"slot"); b_str(b, id); b_str(b, "PrimaryValid\":"); b_str(b, info->primary_valid ? "true" : "false");
    b_str(b, ",\"slot"); b_str(b, id); b_str(b, "BackupValid\":"); b_str(b, info->backup_valid ? "true" : "false");
    b_str(b, ",\"slot"); b_str(b, id); b_str(b, "CopiesMatch\":"); b_str(b, info->copies_match ? "true" : "false");
    b_str(b, ",\"slot"); b_str(b, id); b_str(b, "EventCount\":"); b_u64(b, block[SMW_EVENT_COUNT_OFFSET]);
    b_str(b, ",\"slot"); b_str(b, id); b_str(b, "SwitchBlocks\":"); append_switch_array(b, block);
}

static uint64_t capabilities_response(void) {
    builder b; b_init(&b, 192);
    b_str(&b, "{\"abiVersion\":\"rsm-wasm-json-v1\",\"operations\":[\"parse\",\"readCheats\",\"applyCheats\"],\"parserId\":\"snes-super-mario-world\",\"supported\":true}");
    return finish(&b);
}

static uint64_t parse_response(const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0; uint32_t payload_len = 0;
    if (!decode_payload(input, input_len, &payload, &payload_len)) return error_response("payload decode failed");
    inspection insp = inspect_payload(payload, payload_len);
    builder b; b_init(&b, 8192);
    if (!insp.supported) { b_str(&b, "{\"supported\":false,\"warnings\":[\"Super Mario World SRAM checksum/mirror validation failed\"]}"); return finish(&b); }
    b_str(&b, "{\"supported\":true,\"parserLevel\":\"semantic\",\"parserId\":\"snes-super-mario-world\",\"validatedSystem\":\"snes\",\"validatedGameId\":\"snes/super-mario-world\",\"validatedGameTitle\":\"Super Mario World\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[\"payloadSize=");
    b_u64(&b, payload_len);
    if (insp.blank) {
        b_str(&b, "\",\"blank SRAM payload accepted for slot creation");
    } else {
        b_str(&b, "\",\"validated 143-byte save blocks with 0x5A5A checksum complement\",\"validSaveSlots=");
        bool first_slot = true;
        for (uint32_t slot = 0; slot < SMW_SLOT_COUNT; slot++) if (insp.slots[slot].active) { if (!first_slot) b_char(&b, ','); b_str(&b, slot_id(slot)); first_slot = false; }
    }
    bool any_mirror = false; for (uint32_t slot = 0; slot < SMW_SLOT_COUNT; slot++) if (insp.slots[slot].copies_match) any_mirror = true;
    if (any_mirror) b_str(&b, "\",\"primary/backup mirror matched for at least one save slot");
    b_str(&b, "\"],\"warnings\":[");
    bool first = true;
    for (uint32_t slot = 0; slot < SMW_SLOT_COUNT; slot++) { const slot_info *info = &insp.slots[slot]; if (info->active && !info->copies_match) { if (!first) b_char(&b, ','); b_str(&b, "\"slot "); b_str(&b, slot_id(slot)); b_str(&b, " has one valid copy or mismatched primary/backup copies\""); first = false; } }
    b_str(&b, "],\"payloadSizeBytes\":"); b_u64(&b, payload_len);
    b_str(&b, ",\"slotCount\":3,\"activeSlotIndexes\":["); first = true;
    for (uint32_t slot = 0; slot < SMW_SLOT_COUNT; slot++) if (insp.slots[slot].active) { if (!first) b_char(&b, ','); b_u64(&b, slot); first = false; }
    b_str(&b, "],\"checksumValid\":true,\"semanticFields\":{"); first = true;
    for (uint32_t slot = 0; slot < SMW_SLOT_COUNT; slot++) append_slot_semantic(&b, payload, &insp, slot, &first);
    b_str(&b, ",\"blankSRAM\":"); b_str(&b, insp.blank ? "true" : "false");
    b_str(&b, ",\"usedBytes\":"); b_u64(&b, SMW_USED_BYTES); b_str(&b, "}}");
    return finish(&b);
}

static uint64_t read_response(const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0; uint32_t payload_len = 0;
    if (!decode_payload(input, input_len, &payload, &payload_len)) return error_response("payload decode failed");
    inspection insp = inspect_payload(payload, payload_len);
    if (!insp.supported) return error_response("no valid Super Mario World save files found");
    builder b; b_init(&b, 32768);
    b_str(&b, "{\"slotValues\":{");
    bool first = true;
    for (uint32_t slot = 0; slot < SMW_SLOT_COUNT; slot++) {
        if (!first) b_char(&b, ',');
        b_char(&b, '"'); b_str(&b, slot_id(slot)); b_str(&b, "\":");
        if (insp.slots[slot].active) append_slot_values(&b, payload + insp.slots[slot].source_start); else append_blank_values(&b);
        first = false;
    }
    b_str(&b, "}}"); return finish(&b);
}

static uint32_t parse_slot_id(slice raw, const inspection *insp) {
    if (raw.len > 0) { uint8_t c = raw.ptr[0]; if (c == 'A' || c == 'a' || c == '1') return 0; if (c == 'B' || c == 'b' || c == '2') return 1; if (c == 'C' || c == 'c' || c == '3') return 2; return 99; }
    for (uint32_t slot = 0; slot < SMW_SLOT_COUNT; slot++) if (insp->slots[slot].active) return slot;
    return 0;
}

static void apply_level_bitmask(slice updates, const char *field, uint8_t *block, uint8_t mask) {
    bool selected[SMW_LEVEL_FLAG_COUNT];
    if (!parse_bitmask_value(updates, field, "level", 2, SMW_LEVEL_FLAG_COUNT, selected)) return;
    for (uint32_t i = 0; i < SMW_LEVEL_FLAG_COUNT; i++) {
        if (selected[i]) block[i] |= mask; else block[i] &= (uint8_t)~mask;
    }
}

static bool apply_event_bitmask(slice updates, uint8_t *block) {
    bool selected[SMW_EVENT_FLAG_COUNT];
    if (!parse_bitmask_value(updates, "overworldEvents", "event", 3, SMW_EVENT_FLAG_COUNT, selected)) return false;
    for (uint32_t i = 0; i < 15; i++) block[SMW_EVENT_FLAGS_OFFSET + i] = 0;
    for (uint32_t i = 0; i < SMW_EVENT_FLAG_COUNT; i++) if (selected[i]) block[SMW_EVENT_FLAGS_OFFSET + (i >> 3)] |= (uint8_t)(1u << (i & 7u));
    return true;
}

static bool update_u16(slice updates, const char *field, uint8_t *block, uint32_t offset, bool *out_of_range) {
    uint64_t value = 0; if (!parse_u64_value(updates, field, &value)) return false;
    if (value > 65535u) { *out_of_range = true; return false; }
    write_u16_le(block, offset, (uint16_t)value); return true;
}

static uint64_t apply_response(const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0; uint32_t payload_len = 0;
    if (!decode_payload(input, input_len, &payload, &payload_len)) return error_response("payload decode failed");
    inspection insp = inspect_payload(payload, payload_len);
    if (!insp.supported) return error_response("no valid Super Mario World save files found");
    slice slot_raw = {0}; bool has_slot = json_string_raw(input, input_len, "slotId", &slot_raw); if (!has_slot) { slot_raw.ptr = 0; slot_raw.len = 0; }
    uint32_t slot = parse_slot_id(slot_raw, &insp); if (slot >= SMW_SLOT_COUNT) return error_response("selected save slot is invalid");
    slice updates = {0}; if (!json_object_raw(input, input_len, "updates", &updates)) return error_response("updates object is required");
    bool create_blank = false; bool install_96 = false;
    bool has_create_blank = parse_bool_value(updates, "createBlankFile", &create_blank) && create_blank;
    bool has_install_96 = parse_bool_value(updates, "install96ExitTemplate", &install_96) && install_96;
    if (!insp.slots[slot].active && !has_create_blank && !has_install_96) return error_response("selected save slot is not present");
    uint8_t block[SMW_BLOCK_SIZE];
    if (has_install_96) {
        for (uint32_t i = 0; i < SMW_DATA_SIZE; i++) block[i] = verified_96_exit_data[i];
        block[SMW_DATA_SIZE] = 0; block[SMW_DATA_SIZE + 1u] = 0;
    } else if (has_create_blank || !insp.slots[slot].active) {
        build_blank_block(block);
    } else {
        for (uint32_t i = 0; i < SMW_BLOCK_SIZE; i++) block[i] = payload[insp.slots[slot].source_start + i];
    }
    bool value = false;
    if (parse_bool_value(updates, "greenSwitchBlocks", &value)) block[SMW_SWITCH_OFFSET] = value ? 1 : 0;
    if (parse_bool_value(updates, "yellowSwitchBlocks", &value)) block[SMW_SWITCH_OFFSET + 1u] = value ? 1 : 0;
    if (parse_bool_value(updates, "blueSwitchBlocks", &value)) block[SMW_SWITCH_OFFSET + 2u] = value ? 1 : 0;
    if (parse_bool_value(updates, "redSwitchBlocks", &value)) block[SMW_SWITCH_OFFSET + 3u] = value ? 1 : 0;
    uint64_t number = 0;
    if (parse_u64_value(updates, "eventCount", &number)) { if (number > 96u) return error_response("eventCount must be 0..96"); block[SMW_EVENT_COUNT_OFFSET] = (uint8_t)number; }
    apply_event_bitmask(updates, block);
    apply_level_bitmask(updates, "levelBeatenFlags", block, LEVEL_BEATEN_MASK);
    apply_level_bitmask(updates, "levelMidwayFlags", block, LEVEL_MIDWAY_MASK);
    apply_level_bitmask(updates, "levelMoveUpFlags", block, LEVEL_MOVE_UP_MASK);
    apply_level_bitmask(updates, "levelMoveDownFlags", block, LEVEL_MOVE_DOWN_MASK);
    apply_level_bitmask(updates, "levelMoveLeftFlags", block, LEVEL_MOVE_LEFT_MASK);
    apply_level_bitmask(updates, "levelMoveRightFlags", block, LEVEL_MOVE_RIGHT_MASK);
    slice raw = {0}; uint8_t submap = 0;
    if (parse_string_value(updates, "marioSubmap", &raw)) { if (!parse_submap_value(raw, &submap)) return error_response("invalid marioSubmap"); block[SMW_MARIO_SUBMAP_OFFSET] = submap; }
    if (parse_string_value(updates, "luigiSubmap", &raw)) { if (!parse_submap_value(raw, &submap)) return error_response("invalid luigiSubmap"); block[SMW_LUIGI_SUBMAP_OFFSET] = submap; }
    bool out_of_range = false;
    update_u16(updates, "marioOverworldAnimation", block, SMW_MARIO_ANIMATION_OFFSET, &out_of_range);
    update_u16(updates, "luigiOverworldAnimation", block, SMW_LUIGI_ANIMATION_OFFSET, &out_of_range);
    update_u16(updates, "marioOverworldX", block, SMW_MARIO_X_OFFSET, &out_of_range);
    update_u16(updates, "marioOverworldY", block, SMW_MARIO_Y_OFFSET, &out_of_range);
    update_u16(updates, "luigiOverworldX", block, SMW_LUIGI_X_OFFSET, &out_of_range);
    update_u16(updates, "luigiOverworldY", block, SMW_LUIGI_Y_OFFSET, &out_of_range);
    update_u16(updates, "marioOverworldXPointer", block, SMW_MARIO_X_PTR_OFFSET, &out_of_range);
    update_u16(updates, "marioOverworldYPointer", block, SMW_MARIO_Y_PTR_OFFSET, &out_of_range);
    update_u16(updates, "luigiOverworldXPointer", block, SMW_LUIGI_X_PTR_OFFSET, &out_of_range);
    update_u16(updates, "luigiOverworldYPointer", block, SMW_LUIGI_Y_PTR_OFFSET, &out_of_range);
    if (out_of_range) return error_response("overworld word fields must be 0..65535");
    write_u16_le(block, SMW_DATA_SIZE, smw_checksum(block));
    uint32_t p = primary_start(slot); uint32_t bkp = backup_start(slot);
    for (uint32_t i = 0; i < SMW_BLOCK_SIZE; i++) { payload[p + i] = block[i]; payload[bkp + i] = block[i]; }
    builder b; uint32_t encoded_len = ((payload_len + 2u) / 3u) * 4u; b_init(&b, encoded_len + 1024u);
    b_str(&b, "{\"payload\":\""); b_base64(&b, payload, payload_len);
    b_str(&b, "\",\"changed\":{},\"integritySteps\":[\"rebuilt Super Mario World 0x5A5A checksum complement\",\"mirrored edited save file to primary and backup SRAM blocks\"]}");
    return finish(&b);
}

__attribute__((export_name("rsm_call")))
uint64_t rsm_call(int32_t command_ptr, int32_t command_len, int32_t input_ptr, int32_t input_len) {
    if (command_ptr <= 0 || command_len <= 0 || input_ptr <= 0 || input_len < 0) return error_response("invalid ABI pointer or length");
    const uint8_t *command = (const uint8_t *)(uintptr_t)command_ptr;
    const uint8_t *input = (const uint8_t *)(uintptr_t)input_ptr;
    if (command_len == 12 && bytes_eq(command, "capabilities", 12)) return capabilities_response();
    if (command_len == 5 && bytes_eq(command, "parse", 5)) return parse_response(input, (uint32_t)input_len);
    if (command_len == 10 && bytes_eq(command, "readCheats", 10)) return read_response(input, (uint32_t)input_len);
    if (command_len == 11 && bytes_eq(command, "applyCheats", 11)) return apply_response(input, (uint32_t)input_len);
    return error_response("unsupported command");
}
