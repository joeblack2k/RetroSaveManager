# Super Mario World Game Support Module

This module supports the standard 2048-byte SNES SRAM used by Super Mario World.

Runtime validation requires at least one valid save-file block. Each save file is a 143-byte block: 141 bytes of data followed by a little-endian checksum complement computed as `0x5A5A - sum(data bytes)`. The module also understands the three mirrored backup blocks and writes edited slots back to both the primary and backup copy.

Supported writable fields:

- Green, Yellow, Blue, and Red switch-block flags for File A, B, or C.
- Event count, clamped to the retail total of 96 exits.
- The 120 documented overworld event bits from the 15-byte event table.
- The documented `bmesudlr` level-state bits for beaten, midway, and up/down/left/right movement.
- Mario/Luigi current submap, overworld animation word, X/Y position, and X/Y tile-pointer words.
- Create Blank File, based on the retail `InitSaveData` Yoshi's Island starting state.
- Install 96-Exit File, based on a verified 96-exit SRAM block from a real save sample.

Known limitations:

- The module exposes documented save-structure fields, but it does not translate every event bit into a named level path or cutscene. Event bits remain numbered `event000` through `event119`.
- Level-state bits remain numbered `level00` through `level95`; only the documented beaten, midway, and movement bits are writable.
- Activating switch blocks only changes the documented switch-block flag bytes unless the user also edits the relevant event/level state.
- The module does not include raw Game Genie, Action Replay, Pro Action Replay, or other trainer-code writes. Those are runtime/RAM patch formats, not parser-backed SRAM edits.

Research sources:

- SMWCentral SRAM map by Lui37, documenting the 858 used bytes, three 143-byte files, three mirrored copies, the switch-block flag bytes, and checksum complement bytes.
- SnesLab SMW save routine by p4plus2, documenting the copy loop, `0x5A5A` checksum complement, and duplicate write at the backup offset.
- SMWCentral RAM map for `$7E:1EA2`, `$7E:1F02`, `$7E:1F11`-`$7E:1F27`, and `$7E:1F2E`, documenting level-state flags, event bits, player map/position fields, switch flags, and event count.
- SMWDisX `bank_00.asm` and `constants.asm`, documenting `!SaveFileSize = 143`, `!TotalExitCount = 96`, submap IDs, initial overworld position, `InitSaveData`, and the save/verify routines.
- EmuNations Super Mario World SRM sample and three RetroMaggedon Super Mario World SNES9X SRM samples, used to verify 2048-byte payload size, slot offsets, little-endian checksum complements, mirrored blocks, event counts, and switch-block byte values.

Build note:

- `parser.wasm` was built from `src/parser.c` with `zig cc` for `wasm32-freestanding`, no entry point, exported memory, and 1 MiB initial memory so it fits RetroSaveManager's 16-page runtime module limit.
