# Pokemon Red/Blue/Yellow Game Boy Module

This module supports 32 KiB Generation 1 Pokemon SRAM for the international Red, Blue, and Yellow layout.

The parser verifies the main save checksum over `0x2598..0x3522`, the stored checksum byte at `0x3523`, a trainer-name terminator, BCD currency fields, and a sane party count before exposing write support.

Supported edits:

- Money at `0x25f3`, stored as 3-byte big-endian BCD.
- Casino coins at `0x2850`, stored as 2-byte big-endian BCD.
- Badge flags at `0x2602`, one bit per Kanto badge.

After edits, the module rebuilds the main checksum. It does not edit party Pokemon, PC boxes, item lists, names, Japanese-region shifted layouts, or raw offsets.

Research sources:

- pret `pokered` SRAM and save code (`ram/sram.asm`, `engine/menus/save.asm`).
- pret `pokeyellow` SRAM and save code (`ram/sram.asm`, `engine/menus/save.asm`).
- RyudoSynbios game-tools-collection Pokemon Red/Blue/Yellow save-editor template and public test saves.
