# Wario Land II Game Boy Module

This module supports the 32 KiB Wario Land II SRAM layout.

The parser validates a recognized section signature at rotating save sections, selects the highest non-erased save-count section, verifies the 16-bit section checksum, and mirrors writes to every valid section with that same save count.

Supported edits:

- Stage Coins at active section offset `+0x12`, 2-byte big-endian BCD, max 999.
- Total Coins at active section offset `+0x0f`, 3-byte big-endian BCD, max 99999.
- Flagman D.D Hi-Score at active section offset `+0x35`, 2-byte big-endian BCD, max 9999.

The module does not expose progression flags, treasure flags, picture-panel flags, hidden events, or raw section writes because those fields require more in-game confirmation before mutation is safe.

Research sources:

- Data Crystal Wario Land II cartridge notes for 32 KiB SRAM.
- RyudoSynbios game-tools-collection Wario Land II save-editor template, utility checksum logic, and public test saves.
