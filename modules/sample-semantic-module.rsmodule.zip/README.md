# Module Demo Cartridge

This is a safe smoke-test module for the RetroSaveManager runtime module loader.

It targets a fictive 4-byte Game Boy save named `Module Demo Cartridge`, so it does not override real game support.
The WASM exports the v1 JSON ABI and returns deterministic parser and cheat responses for loader validation.
