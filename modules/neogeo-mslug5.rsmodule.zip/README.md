# NeoGeo - Metal Slug 5 Module

This module supports Metal Slug 5 MVS backup-RAM saves for RetroSaveManager.

Runtime files:

- `parser.wasm`: sandboxed WASM parser/editor using the `rsm-wasm-json-v1` ABI.
- `cheats/mslug5.yaml`: declarative cheat pack for the WASM editor.
- `src/*`: review source only; the backend never compiles or runs it.

## Evidence

- MAME's NeoGeo driver maps MVS save RAM at `0xd00000-0xd0ffff`, installs it as NVRAM, and identifies Metal Slug 5 as `mslug5`, `Metal Slug 5 (NGM-2680)`, with `MACHINE_SUPPORTS_SAVE`.
- NeoGeoDev documents the MVS backup RAM marker, slot NGH/block table, soft-DIP area, game-name blocks, and cabinet setting byte at backup RAM offset `0x42`.
- NeoGeoDev documents the 68k program header NGH field as BCD, matching Metal Slug 5's `2680` NGH number in MAME.

## Supported Payloads

- `65536` bytes: raw MVS backup RAM.
- `73728` bytes: RetroSaveManager NeoGeo compound layout, with the first `65536` bytes treated as backup RAM and the trailing `8192` bytes preserved unchanged.

The parser returns `supported: true` only when the backup RAM marker is present and one MVS slot table entry contains NGH `0x2680` with a valid backup-RAM block id.

## Editable Field

- `freePlay`: boolean MVS cabinet game-select setting at backup RAM offset `0x42`.

No checksum is rebuilt because the documented MVS backup RAM structure does not define a global checksum for this cabinet setting.

## Not Supported

- Game-specific soft-DIP choices such as lives, difficulty, bonus rate, or continue settings; their labels and bounds live in the Metal Slug 5 program header, not in backup RAM, and were not safely derived here.
- High-score or bookkeeping edits.
- Memory-card data editing.
- Raw offset writes, arbitrary byte edits, trainer codes, or filename-only matching.
