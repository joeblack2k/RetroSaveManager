#include <stdbool.h>
#include <stdint.h>

extern unsigned char __heap_base;

static uint32_t heap_ptr = 0;

static void *rsm_bump_alloc(uint32_t len) {
    if (heap_ptr == 0) {
        heap_ptr = (uint32_t)(uintptr_t)&__heap_base;
    }
    heap_ptr = (heap_ptr + 7u) & ~7u;
    void *ptr = (void *)(uintptr_t)heap_ptr;
    heap_ptr += (len + 7u) & ~7u;
    return ptr;
}

__attribute__((export_name("rsm_alloc")))
int32_t rsm_alloc(int32_t len) {
    if (len <= 0) {
        return 0;
    }
    return (int32_t)(uintptr_t)rsm_bump_alloc((uint32_t)len);
}

typedef struct {
    char *data;
    uint32_t len;
    uint32_t cap;
} builder;

static void b_init(builder *b, uint32_t cap) {
    b->data = (char *)rsm_bump_alloc(cap);
    b->len = 0;
    b->cap = cap;
}

static void b_char(builder *b, char c) {
    if (b->len < b->cap) {
        b->data[b->len++] = c;
    }
}

static void b_strn(builder *b, const char *s, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) {
        b_char(b, s[i]);
    }
}

static uint32_t c_len(const char *s) {
    uint32_t n = 0;
    while (s[n] != 0) {
        n++;
    }
    return n;
}

static void b_str(builder *b, const char *s) {
    b_strn(b, s, c_len(s));
}

static void b_u64(builder *b, uint64_t value) {
    char tmp[24];
    uint32_t n = 0;
    if (value == 0) {
        b_char(b, '0');
        return;
    }
    while (value > 0 && n < sizeof(tmp)) {
        tmp[n++] = (char)('0' + (value % 10u));
        value /= 10u;
    }
    while (n > 0) {
        b_char(b, tmp[--n]);
    }
}

static uint64_t finish(builder *b) {
    return ((uint64_t)(uint32_t)(uintptr_t)b->data << 32) | (uint64_t)b->len;
}

static uint64_t error_response(const char *message) {
    builder b;
    b_init(&b, 256);
    b_str(&b, "{\"supported\":false,\"error\":\"");
    b_str(&b, message);
    b_str(&b, "\"}");
    return finish(&b);
}

static bool bytes_eq(const uint8_t *a, const char *b, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) {
        if (a[i] != (uint8_t)b[i]) {
            return false;
        }
    }
    return true;
}

static bool has_bytes(const uint8_t *payload, uint32_t len, uint32_t offset, const char *expected, uint32_t expected_len) {
    return offset + expected_len <= len && bytes_eq(payload + offset, expected, expected_len);
}

static int32_t find_bytes(const uint8_t *input, uint32_t len, const char *needle, uint32_t needle_len) {
    if (needle_len == 0 || len < needle_len) {
        return -1;
    }
    for (uint32_t i = 0; i <= len - needle_len; i++) {
        bool ok = true;
        for (uint32_t j = 0; j < needle_len; j++) {
            if (input[i + j] != (uint8_t)needle[j]) {
                ok = false;
                break;
            }
        }
        if (ok) {
            return (int32_t)i;
        }
    }
    return -1;
}

static uint32_t skip_ws(const uint8_t *input, uint32_t len, uint32_t idx) {
    while (idx < len) {
        uint8_t c = input[idx];
        if (c != ' ' && c != '\n' && c != '\r' && c != '\t') {
            break;
        }
        idx++;
    }
    return idx;
}

typedef struct {
    const uint8_t *ptr;
    uint32_t len;
} slice;

static bool json_string_raw(const uint8_t *input, uint32_t len, const char *field, slice *out) {
    char key[80];
    uint32_t field_len = c_len(field);
    if (field_len + 2 >= sizeof(key)) {
        return false;
    }
    key[0] = '"';
    for (uint32_t i = 0; i < field_len; i++) {
        key[i + 1] = field[i];
    }
    key[field_len + 1] = '"';
    key[field_len + 2] = 0;
    int32_t found = find_bytes(input, len, key, field_len + 2);
    if (found < 0) {
        return false;
    }
    uint32_t idx = skip_ws(input, len, (uint32_t)found + field_len + 2);
    if (idx >= len || input[idx] != ':') {
        return false;
    }
    idx = skip_ws(input, len, idx + 1);
    if (idx >= len || input[idx] != '"') {
        return false;
    }
    uint32_t start = idx + 1;
    idx = start;
    while (idx < len) {
        if (input[idx] == '\\') {
            idx += 2;
            continue;
        }
        if (input[idx] == '"') {
            out->ptr = input + start;
            out->len = idx - start;
            return true;
        }
        idx++;
    }
    return false;
}

static bool json_object_raw(const uint8_t *input, uint32_t len, const char *field, slice *out) {
    char key[80];
    uint32_t field_len = c_len(field);
    if (field_len + 2 >= sizeof(key)) {
        return false;
    }
    key[0] = '"';
    for (uint32_t i = 0; i < field_len; i++) {
        key[i + 1] = field[i];
    }
    key[field_len + 1] = '"';
    key[field_len + 2] = 0;
    int32_t found = find_bytes(input, len, key, field_len + 2);
    if (found < 0) {
        return false;
    }
    uint32_t idx = skip_ws(input, len, (uint32_t)found + field_len + 2);
    if (idx >= len || input[idx] != ':') {
        return false;
    }
    idx = skip_ws(input, len, idx + 1);
    if (idx >= len || input[idx] != '{') {
        return false;
    }
    uint32_t start = idx;
    int32_t depth = 0;
    bool in_string = false;
    while (idx < len) {
        uint8_t c = input[idx];
        if (in_string) {
            if (c == '\\') {
                idx += 2;
                continue;
            }
            if (c == '"') {
                in_string = false;
            }
            idx++;
            continue;
        }
        if (c == '"') {
            in_string = true;
        } else if (c == '{') {
            depth++;
        } else if (c == '}') {
            depth--;
            if (depth == 0) {
                out->ptr = input + start;
                out->len = idx - start + 1;
                return true;
            }
        }
        idx++;
    }
    return false;
}

static int b64_value(uint8_t c) {
    if (c >= 'A' && c <= 'Z') return (int)(c - 'A');
    if (c >= 'a' && c <= 'z') return (int)(c - 'a' + 26);
    if (c >= '0' && c <= '9') return (int)(c - '0' + 52);
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

static bool base64_decode(slice encoded, uint8_t **out, uint32_t *out_len) {
    uint32_t cap = (encoded.len / 4u) * 3u + 3u;
    uint8_t *dst = (uint8_t *)rsm_bump_alloc(cap);
    uint32_t n = 0;
    for (uint32_t i = 0; i < encoded.len;) {
        int vals[4] = {0, 0, 0, 0};
        int pad = 0;
        for (uint32_t j = 0; j < 4; j++) {
            if (i >= encoded.len) {
                return false;
            }
            uint8_t c = encoded.ptr[i++];
            if (c == '=') {
                vals[j] = 0;
                pad++;
            } else {
                vals[j] = b64_value(c);
                if (vals[j] < 0) {
                    return false;
                }
            }
        }
        uint32_t triple = ((uint32_t)vals[0] << 18) | ((uint32_t)vals[1] << 12) | ((uint32_t)vals[2] << 6) | (uint32_t)vals[3];
        if (n < cap) dst[n++] = (uint8_t)((triple >> 16) & 0xff);
        if (pad < 2 && n < cap) dst[n++] = (uint8_t)((triple >> 8) & 0xff);
        if (pad < 1 && n < cap) dst[n++] = (uint8_t)(triple & 0xff);
    }
    *out = dst;
    *out_len = n;
    return true;
}

static const char b64_table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static void b_base64(builder *b, const uint8_t *src, uint32_t len) {
    uint32_t i = 0;
    while (i < len) {
        uint32_t a = src[i++];
        uint32_t have_b = i < len;
        uint32_t b2 = have_b ? src[i++] : 0;
        uint32_t have_c = i < len;
        uint32_t c = have_c ? src[i++] : 0;
        uint32_t triple = (a << 16) | (b2 << 8) | c;
        b_char(b, b64_table[(triple >> 18) & 0x3f]);
        b_char(b, b64_table[(triple >> 12) & 0x3f]);
        b_char(b, have_b ? b64_table[(triple >> 6) & 0x3f] : '=');
        b_char(b, have_c ? b64_table[triple & 0x3f] : '=');
    }
}

static uint32_t read_u32(const uint8_t *buf, uint32_t offset) {
    return (uint32_t)buf[offset] | ((uint32_t)buf[offset + 1] << 8) | ((uint32_t)buf[offset + 2] << 16) | ((uint32_t)buf[offset + 3] << 24);
}

static void write_u32(uint8_t *buf, uint32_t offset, uint32_t value) {
    buf[offset] = (uint8_t)(value & 0xff);
    buf[offset + 1] = (uint8_t)((value >> 8) & 0xff);
    buf[offset + 2] = (uint8_t)((value >> 16) & 0xff);
    buf[offset + 3] = (uint8_t)((value >> 24) & 0xff);
}

#define HEADER_BLOCK_SIZE 0x40u
#define SAVE_BLOCK_SIZE 0x1e0u
#define SAVE_CHECKSUM_OFFSET 0x10u
#define SAVE_END_OFFSET 0x144u
#define SAVE_KEY2_OFFSET 0x160u
#define SPOILED_ROTTEN_FLAGS_OFFSET 0x34u
#define BOSS_BEATEN_MASK 0x20u
#define STAGE_KNOWN_MASK 0x3fu
#define BOSS_TREASURE_MASK 0x03u
#define LAST_BLOCK_SIZE 0x20u
#define LAST_CHECKSUM_OFFSET 0x04u
#define HARD_MODE_BEATEN_OFFSET 0x0au

static uint32_t checksum_body_sum(const uint8_t *block, uint32_t block_len, uint32_t checksum_offset) {
    uint32_t sum = 0;
    for (uint32_t off = 0; off + 4 <= block_len; off += 4) {
        if (off != checksum_offset && off != checksum_offset + 4) {
            sum += read_u32(block, off);
        }
    }
    return sum;
}

static bool verify_sum_minus_one_checksum(const uint8_t *block, uint32_t block_len, uint32_t checksum_offset) {
    uint32_t expected = checksum_body_sum(block, block_len, checksum_offset) - 1u;
    uint32_t checksum = read_u32(block, checksum_offset);
    uint32_t negated = read_u32(block, checksum_offset + 4u);
    return checksum == expected && negated == ~checksum;
}

static bool verify_sum_checksum(const uint8_t *block, uint32_t block_len, uint32_t checksum_offset) {
    uint32_t expected = checksum_body_sum(block, block_len, checksum_offset);
    uint32_t checksum = read_u32(block, checksum_offset);
    uint32_t negated = read_u32(block, checksum_offset + 4u);
    return checksum == expected && negated == ~checksum;
}

static bool verify_header_block(const uint8_t *payload, uint32_t len, uint32_t start) {
    return start + HEADER_BLOCK_SIZE <= len &&
        has_bytes(payload, len, start + 0x0c, "AGBWarioLand-USver00", 21) &&
        verify_sum_minus_one_checksum(payload + start, HEADER_BLOCK_SIZE, 0);
}

static bool verify_save_block(const uint8_t *payload, uint32_t len, uint32_t start) {
    return start + SAVE_BLOCK_SIZE <= len &&
        has_bytes(payload, len, start, "AutoSAVEWar4key1", 16) &&
        has_bytes(payload, len, start + SAVE_END_OFFSET, "SAVE_END", 8) &&
        has_bytes(payload, len, start + SAVE_KEY2_OFFSET, "key2AutoSAVEWar4", 16) &&
        verify_sum_minus_one_checksum(payload + start, SAVE_BLOCK_SIZE, SAVE_CHECKSUM_OFFSET);
}

static void write_save_checksum(uint8_t *block) {
    for (uint32_t i = 0; i < 8; i++) {
        block[SAVE_CHECKSUM_OFFSET + i] = 0;
    }
    uint32_t checksum = checksum_body_sum(block, SAVE_BLOCK_SIZE, SAVE_CHECKSUM_OFFSET) - 1u;
    write_u32(block, SAVE_CHECKSUM_OFFSET, checksum);
    write_u32(block, SAVE_CHECKSUM_OFFSET + 4u, ~checksum);
}

static void write_header_checksum(uint8_t *block) {
    for (uint32_t i = 0; i < 8; i++) {
        block[i] = 0;
    }
    uint32_t checksum = checksum_body_sum(block, HEADER_BLOCK_SIZE, 0) - 1u;
    write_u32(block, 0, checksum);
    write_u32(block, 4, ~checksum);
}

static bool verify_last_block(const uint8_t *payload, uint32_t len, uint32_t start) {
    return start + LAST_BLOCK_SIZE <= len &&
        has_bytes(payload, len, start + 0x0c, "Nrd1", 4) &&
        verify_sum_checksum(payload + start, LAST_BLOCK_SIZE, LAST_CHECKSUM_OFFSET);
}

static void write_last_checksum(uint8_t *block) {
    for (uint32_t i = 0; i < 8; i++) {
        block[LAST_CHECKSUM_OFFSET + i] = 0;
    }
    uint32_t checksum = checksum_body_sum(block, LAST_BLOCK_SIZE, LAST_CHECKSUM_OFFSET);
    write_u32(block, LAST_CHECKSUM_OFFSET, checksum);
    write_u32(block, LAST_CHECKSUM_OFFSET + 4u, ~checksum);
}

static void patch_global_header_blocks(uint8_t *payload, uint32_t payload_len, bool hard_mode_beaten) {
    uint32_t starts[] = {0x000u, 0x040u, 0x900u};
    for (uint32_t i = 0; i < 3; i++) {
        uint32_t start = starts[i];
        if (start + HEADER_BLOCK_SIZE > payload_len) {
            continue;
        }
        uint8_t block[HEADER_BLOCK_SIZE];
        for (uint32_t j = 0; j < HEADER_BLOCK_SIZE; j++) {
            block[j] = payload[start + j];
        }
        block[HARD_MODE_BEATEN_OFFSET] = hard_mode_beaten ? 1 : 0;
        write_header_checksum(block);
        for (uint32_t j = 0; j < HEADER_BLOCK_SIZE; j++) {
            payload[start + j] = block[j];
        }
    }
}

static bool accepted_size(uint32_t len) {
    return len == 32768u || len == 65536u || len == 131072u;
}

typedef struct {
    bool supported;
    bool slot_active[2];
    bool slot_primary_valid[2];
    bool slot_backup_valid[2];
    bool last_primary_valid[2];
    bool last_backup_valid[2];
    uint32_t header_count;
    bool trailer;
} inspection;

static inspection inspect_payload(const uint8_t *payload, uint32_t len) {
    inspection out = {0};
    if (!accepted_size(len) || len < 0x990u) {
        return out;
    }
    uint32_t headers[] = {0x000u, 0x040u, 0x900u};
    for (uint32_t i = 0; i < 3; i++) {
        if (verify_header_block(payload, len, headers[i])) {
            out.header_count++;
        }
    }
    if (out.header_count == 0) {
        return out;
    }
    if (!has_bytes(payload, len, 0x87u, "WAR4SAVEAWARABGSELECTSAVE", 25)) {
        return out;
    }
    uint32_t starts[2][2] = {{0x100u, 0x300u}, {0x500u, 0x700u}};
    uint32_t last_starts[2][2] = {{0x2e0u, 0x4e0u}, {0x6e0u, 0x8e0u}};
    for (uint32_t slot = 0; slot < 2; slot++) {
        out.slot_primary_valid[slot] = verify_save_block(payload, len, starts[slot][0]);
        out.slot_backup_valid[slot] = verify_save_block(payload, len, starts[slot][1]);
        out.slot_active[slot] = out.slot_primary_valid[slot] || out.slot_backup_valid[slot];
        out.last_primary_valid[slot] = verify_last_block(payload, len, last_starts[slot][0]);
        out.last_backup_valid[slot] = verify_last_block(payload, len, last_starts[slot][1]);
    }
    out.trailer = has_bytes(payload, len, 0x980u, "Xbsj5`BHC`CbdlVq", 16);
    out.supported = out.slot_active[0] || out.slot_active[1];
    return out;
}

static uint32_t active_slot_start(const inspection *insp, uint32_t slot) {
    if (slot == 0) {
        return insp->slot_primary_valid[0] ? 0x100u : 0x300u;
    }
    return insp->slot_primary_valid[1] ? 0x500u : 0x700u;
}

static const char *slot_id(uint32_t slot) {
    return slot == 0 ? "A" : "B";
}

static uint32_t active_last_start(const inspection *insp, uint32_t slot) {
    if (slot == 0) {
        return insp->last_primary_valid[0] ? 0x2e0u : 0x4e0u;
    }
    return insp->last_primary_valid[1] ? 0x6e0u : 0x8e0u;
}

typedef struct {
    const char *id;
    uint32_t offset;
} score_field;

typedef struct {
    const char *id;
    uint32_t offset;
} stage_field;

static const stage_field stage_fields[] = {
    {"hallCollectibles", 0x024u},
    {"palmTreeParadiseCollectibles", 0x03cu},
    {"wildflowerFieldsCollectibles", 0x040u},
    {"mysticLakeCollectibles", 0x044u},
    {"monsoonJungleCollectibles", 0x048u},
    {"curiousFactoryCollectibles", 0x054u},
    {"toxicLandfillCollectibles", 0x058u},
    {"fortyBelowFridgeCollectibles", 0x05cu},
    {"pinballZoneCollectibles", 0x060u},
    {"toyBlockTowerCollectibles", 0x06cu},
    {"bigBoardCollectibles", 0x070u},
    {"doodleWoodsCollectibles", 0x074u},
    {"dominoRowCollectibles", 0x078u},
    {"crescentMoonVillageCollectibles", 0x084u},
    {"arabianNightCollectibles", 0x088u},
    {"fieryCavernCollectibles", 0x08cu},
    {"hotelHorrorCollectibles", 0x090u},
    {"goldenPassageCollectibles", 0x09cu},
};

static const uint32_t stage_field_count = sizeof(stage_fields) / sizeof(stage_fields[0]);

typedef struct {
    const char *beaten_id;
    const char *treasure_id;
    uint32_t offset;
    bool has_treasures;
} boss_field;

static const boss_field boss_fields[] = {
    {"spoiledRottenBossBeaten", 0, 0x034u, false},
    {"cractusBossBeaten", "cractusTreasureChests", 0x04cu, true},
    {"cuckooCondorBossBeaten", "cuckooCondorTreasureChests", 0x064u, true},
    {"aerodentBossBeaten", "aerodentTreasureChests", 0x07cu, true},
    {"catbatBossBeaten", "catbatTreasureChests", 0x094u, true},
};

static const uint32_t boss_field_count = sizeof(boss_fields) / sizeof(boss_fields[0]);

static const score_field score_fields[] = {
    {"scoreHallOfHieroglyphs", 0x0ccu},
    {"scorePalmTreeParadise", 0x0dcu},
    {"scoreWildflowerFields", 0x0e0u},
    {"scoreMysticLake", 0x0e4u},
    {"scoreMonsoonJungle", 0x0e8u},
    {"scoreCuriousFactory", 0x0ecu},
    {"scoreToxicLandfill", 0x0f0u},
    {"scoreFortyBelowFridge", 0x0f4u},
    {"scorePinballZone", 0x0f8u},
    {"scoreToyBlockTower", 0x0fcu},
    {"scoreBigBoard", 0x100u},
    {"scoreDoodleWoods", 0x104u},
    {"scoreDominoRow", 0x108u},
    {"scoreCrescentMoonVillage", 0x10cu},
    {"scoreArabianNight", 0x110u},
    {"scoreFieryCavern", 0x114u},
    {"scoreHotelHorror", 0x118u},
    {"scoreGoldenPassage", 0x11cu},
};

static const uint32_t score_field_count = sizeof(score_fields) / sizeof(score_fields[0]);

typedef struct {
    const char *id;
    uint32_t bit;
} hall_bit;

static const hall_bit hall_bits[] = {
    {"topRightGem", 0},
    {"bottomRightGem", 1},
    {"bottomLeftGem", 2},
    {"topLeftGem", 3},
    {"cd", 4},
    {"keezer", 5},
};

static void append_hall_array(builder *b, uint32_t flags) {
    b_char(b, '[');
    bool first = true;
    for (uint32_t i = 0; i < 6; i++) {
        if ((flags & (1u << hall_bits[i].bit)) != 0) {
            if (!first) b_char(b, ',');
            b_char(b, '"');
            b_str(b, hall_bits[i].id);
            b_char(b, '"');
            first = false;
        }
    }
    b_char(b, ']');
}

static void append_values(builder *b, const uint8_t *block) {
    b_char(b, '{');
    bool first = true;
    for (uint32_t i = 0; i < stage_field_count; i++) {
        if (!first) b_char(b, ',');
        b_char(b, '"');
        b_str(b, stage_fields[i].id);
        b_str(b, "\":");
        append_hall_array(b, read_u32(block, stage_fields[i].offset));
        first = false;
    }
    for (uint32_t i = 0; i < boss_field_count; i++) {
        uint32_t raw = read_u32(block, boss_fields[i].offset);
        b_str(b, ",\"");
        b_str(b, boss_fields[i].beaten_id);
        b_str(b, "\":");
        b_str(b, (raw & BOSS_BEATEN_MASK) ? "true" : "false");
        if (boss_fields[i].has_treasures) {
            b_str(b, ",\"");
            b_str(b, boss_fields[i].treasure_id);
            b_str(b, "\":");
            b_u64(b, raw & BOSS_TREASURE_MASK);
        }
    }
    for (uint32_t i = 0; i < score_field_count; i++) {
        b_str(b, ",\"");
        b_str(b, score_fields[i].id);
        b_str(b, "\":");
        b_u64(b, (uint64_t)read_u32(block, score_fields[i].offset) * 10u);
    }
    b_char(b, '}');
}

static void append_last_values(builder *b, const uint8_t *block) {
    b_str(b, ",\"lastVisitedPassageId\":");
    b_u64(b, block[1]);
    b_str(b, ",\"lastVisitedStageNumber\":");
    b_u64(b, block[2]);
    b_str(b, ",\"lastVisitedMapStepCounter\":");
    b_u64(b, block[3]);
}

static bool field_value_start(slice updates, const char *field, uint32_t *idx_out) {
    char key[96];
    uint32_t n = c_len(field);
    if (n + 2 >= sizeof(key)) return false;
    key[0] = '"';
    for (uint32_t i = 0; i < n; i++) key[i + 1] = field[i];
    key[n + 1] = '"';
    key[n + 2] = 0;
    int32_t found = find_bytes(updates.ptr, updates.len, key, n + 2);
    if (found < 0) return false;
    uint32_t idx = skip_ws(updates.ptr, updates.len, (uint32_t)found + n + 2);
    if (idx >= updates.len || updates.ptr[idx] != ':') return false;
    *idx_out = skip_ws(updates.ptr, updates.len, idx + 1);
    return true;
}

static bool parse_bool_value(slice updates, const char *field, bool *value) {
    uint32_t idx = 0;
    if (!field_value_start(updates, field, &idx)) return false;
    if (idx + 4 <= updates.len && bytes_eq(updates.ptr + idx, "true", 4)) {
        *value = true;
        return true;
    }
    if (idx + 5 <= updates.len && bytes_eq(updates.ptr + idx, "false", 5)) {
        *value = false;
        return true;
    }
    return false;
}

static bool parse_u64_value(slice updates, const char *field, uint64_t *value) {
    uint32_t idx = 0;
    if (!field_value_start(updates, field, &idx)) return false;
    uint64_t out = 0;
    bool any = false;
    while (idx < updates.len && updates.ptr[idx] >= '0' && updates.ptr[idx] <= '9') {
        any = true;
        out = out * 10u + (uint64_t)(updates.ptr[idx] - '0');
        idx++;
    }
    if (!any) return false;
    *value = out;
    return true;
}

static bool parse_stage_bits(slice updates, const char *field, uint32_t *selected) {
    uint32_t idx = 0;
    if (!field_value_start(updates, field, &idx)) return false;
    if (idx >= updates.len || updates.ptr[idx] != '[') return false;
    idx++;
    uint32_t bits = 0;
    while (idx < updates.len) {
        idx = skip_ws(updates.ptr, updates.len, idx);
        if (idx < updates.len && updates.ptr[idx] == ']') {
            *selected = bits;
            return true;
        }
        if (idx >= updates.len || updates.ptr[idx] != '"') return false;
        uint32_t start = ++idx;
        while (idx < updates.len && updates.ptr[idx] != '"') idx++;
        if (idx >= updates.len) return false;
        slice item = {updates.ptr + start, idx - start};
        bool matched = false;
        for (uint32_t i = 0; i < 6; i++) {
            if (item.len == c_len(hall_bits[i].id) && bytes_eq(item.ptr, hall_bits[i].id, item.len)) {
                bits |= 1u << hall_bits[i].bit;
                matched = true;
                break;
            }
        }
        if (!matched) return false;
        idx++;
        idx = skip_ws(updates.ptr, updates.len, idx);
        if (idx < updates.len && updates.ptr[idx] == ',') idx++;
    }
    return false;
}

static uint64_t capabilities_response(void) {
    builder b;
    b_init(&b, 192);
    b_str(&b, "{\"abiVersion\":\"rsm-wasm-json-v1\",\"operations\":[\"parse\",\"readCheats\",\"applyCheats\"],\"parserId\":\"gba-wario-land-4\",\"supported\":true}");
    return finish(&b);
}

static bool decode_payload(const uint8_t *input, uint32_t input_len, uint8_t **payload, uint32_t *payload_len) {
    slice encoded = {0};
    if (!json_string_raw(input, input_len, "payload", &encoded)) {
        return false;
    }
    return base64_decode(encoded, payload, payload_len);
}

static uint64_t parse_response(const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0;
    uint32_t payload_len = 0;
    if (!decode_payload(input, input_len, &payload, &payload_len)) {
        return error_response("payload decode failed");
    }
    inspection insp = inspect_payload(payload, payload_len);
    builder b;
    b_init(&b, 2048);
    if (!insp.supported) {
        b_str(&b, "{\"supported\":false,\"warnings\":[\"Wario Land 4 structural validation failed\"]}");
        return finish(&b);
    }
    b_str(&b, "{\"supported\":true,\"parserLevel\":\"semantic\",\"parserId\":\"gba-wario-land-4\",\"validatedSystem\":\"gba\",\"validatedGameId\":\"gba/wario-land-4\",\"validatedGameTitle\":\"Wario Land 4\",\"trustLevel\":\"module-semantic-verified\",\"evidence\":[\"payloadSize=");
    b_u64(&b, payload_len);
    b_str(&b, "\",\"validGlobalHeaderCopies=");
    b_u64(&b, insp.header_count);
    b_str(&b, "\",\"selected-save marker matched\",\"validSaveSlots=");
    bool first = true;
    for (uint32_t slot = 0; slot < 2; slot++) {
        if (insp.slot_active[slot]) {
            if (!first) b_char(&b, ',');
            b_str(&b, slot_id(slot));
            first = false;
        }
    }
    b_str(&b, "\"");
    if (insp.trailer) {
        b_str(&b, ",\"trailer marker matched\"");
    }
    b_str(&b, "],\"warnings\":[");
    first = true;
    for (uint32_t slot = 0; slot < 2; slot++) {
        if (insp.slot_active[slot] && insp.slot_primary_valid[slot] != insp.slot_backup_valid[slot]) {
            if (!first) b_char(&b, ',');
            b_str(&b, "\"slot ");
            b_str(&b, slot_id(slot));
            b_str(&b, " has only one valid save block copy\"");
            first = false;
        }
    }
    b_str(&b, "],\"payloadSizeBytes\":");
    b_u64(&b, payload_len);
    b_str(&b, ",\"slotCount\":2,\"activeSlotIndexes\":[");
    first = true;
    for (uint32_t slot = 0; slot < 2; slot++) {
        if (insp.slot_active[slot]) {
            if (!first) b_char(&b, ',');
            b_u64(&b, slot);
            first = false;
        }
    }
    b_str(&b, "],\"checksumValid\":true,\"semanticFields\":{\"slotAValid\":");
    b_str(&b, insp.slot_active[0] ? "true" : "false");
    b_str(&b, ",\"slotBValid\":");
    b_str(&b, insp.slot_active[1] ? "true" : "false");
    b_str(&b, ",\"headerCopyCount\":");
    b_u64(&b, insp.header_count);
    b_str(&b, ",\"trailerMagicPresent\":");
    b_str(&b, insp.trailer ? "true" : "false");
    b_str(&b, ",\"hardModeBeaten\":");
    b_str(&b, payload[HARD_MODE_BEATEN_OFFSET] ? "true" : "false");
    b_str(&b, "}}");
    return finish(&b);
}

static uint64_t read_response(const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0;
    uint32_t payload_len = 0;
    if (!decode_payload(input, input_len, &payload, &payload_len)) {
        return error_response("payload decode failed");
    }
    inspection insp = inspect_payload(payload, payload_len);
    if (!insp.supported) {
        return error_response("no valid Wario Land 4 save slots found");
    }
    builder b;
    b_init(&b, 16384);
    b_str(&b, "{\"values\":{\"hardModeBeaten\":");
    b_str(&b, payload[HARD_MODE_BEATEN_OFFSET] ? "true" : "false");
    b_str(&b, "},\"slotValues\":{");
    bool first = true;
    for (uint32_t slot = 0; slot < 2; slot++) {
        if (!insp.slot_active[slot]) continue;
        if (!first) b_char(&b, ',');
        b_char(&b, '"');
        b_str(&b, slot_id(slot));
        b_str(&b, "\":");
        uint32_t start = active_slot_start(&insp, slot);
        append_values(&b, payload + start);
        if (insp.last_primary_valid[slot] || insp.last_backup_valid[slot]) {
            b.len--;
            uint32_t last_start = active_last_start(&insp, slot);
            append_last_values(&b, payload + last_start);
            b_char(&b, '}');
        }
        first = false;
    }
    b_str(&b, "}}");
    return finish(&b);
}

static uint64_t apply_response(const uint8_t *input, uint32_t input_len) {
    uint8_t *payload = 0;
    uint32_t payload_len = 0;
    if (!decode_payload(input, input_len, &payload, &payload_len)) {
        return error_response("payload decode failed");
    }
    inspection insp = inspect_payload(payload, payload_len);
    if (!insp.supported) {
        return error_response("no valid Wario Land 4 save slots found");
    }
    slice slot_raw = {0};
    uint32_t slot = 0;
    if (json_string_raw(input, input_len, "slotId", &slot_raw) && slot_raw.len > 0) {
        if ((slot_raw.len == 1 && (slot_raw.ptr[0] == 'B' || slot_raw.ptr[0] == 'b' || slot_raw.ptr[0] == '2'))) {
            slot = 1;
        }
    }
    if (!insp.slot_active[slot]) {
        return error_response("selected save slot is not present");
    }
    slice updates = {0};
    if (!json_object_raw(input, input_len, "updates", &updates)) {
        return error_response("updates object is required");
    }
    uint32_t start = active_slot_start(&insp, slot);
    uint8_t block[SAVE_BLOCK_SIZE];
    for (uint32_t i = 0; i < SAVE_BLOCK_SIZE; i++) {
        block[i] = payload[start + i];
    }
    bool hard_mode = false;
    if (parse_bool_value(updates, "hardModeBeaten", &hard_mode)) {
        patch_global_header_blocks(payload, payload_len, hard_mode);
    }
    for (uint32_t i = 0; i < stage_field_count; i++) {
        uint32_t selected = 0;
        if (parse_stage_bits(updates, stage_fields[i].id, &selected)) {
            uint32_t old = read_u32(block, stage_fields[i].offset);
            write_u32(block, stage_fields[i].offset, (old & ~STAGE_KNOWN_MASK) | selected);
        }
    }
    for (uint32_t i = 0; i < boss_field_count; i++) {
        bool boss = false;
        if (parse_bool_value(updates, boss_fields[i].beaten_id, &boss)) {
            uint32_t old = read_u32(block, boss_fields[i].offset);
            write_u32(block, boss_fields[i].offset, boss ? (old | BOSS_BEATEN_MASK) : (old & ~BOSS_BEATEN_MASK));
        }
        if (boss_fields[i].has_treasures) {
            uint64_t chests = 0;
            if (parse_u64_value(updates, boss_fields[i].treasure_id, &chests)) {
                if (chests > 3) {
                    return error_response("boss treasure chest count must be 0..3");
                }
                uint32_t old = read_u32(block, boss_fields[i].offset);
                write_u32(block, boss_fields[i].offset, (old & ~BOSS_TREASURE_MASK) | (uint32_t)chests);
            }
        }
    }
    for (uint32_t i = 0; i < score_field_count; i++) {
        uint64_t score = 0;
        if (parse_u64_value(updates, score_fields[i].id, &score)) {
            if (score % 10u != 0 || score / 10u > 0xffffffffu) {
                return error_response("score must be a multiple of 10 and fit Wario Land 4 storage");
            }
            write_u32(block, score_fields[i].offset, (uint32_t)(score / 10u));
        }
    }
    bool has_last_update = false;
    uint64_t last_passage = 0;
    uint64_t last_stage = 0;
    uint64_t last_step = 0;
    bool set_passage = parse_u64_value(updates, "lastVisitedPassageId", &last_passage);
    bool set_stage = parse_u64_value(updates, "lastVisitedStageNumber", &last_stage);
    bool set_step = parse_u64_value(updates, "lastVisitedMapStepCounter", &last_step);
    has_last_update = set_passage || set_stage || set_step;
    uint8_t last_block[LAST_BLOCK_SIZE];
    if (has_last_update) {
        if (!(insp.last_primary_valid[slot] || insp.last_backup_valid[slot])) {
            return error_response("selected save slot has no valid last-visited block");
        }
        if ((set_passage && last_passage > 5) || (set_stage && last_stage > 4) || (set_step && last_step > 255)) {
            return error_response("last-visited values are outside documented ranges");
        }
        uint32_t last_start = active_last_start(&insp, slot);
        for (uint32_t i = 0; i < LAST_BLOCK_SIZE; i++) {
            last_block[i] = payload[last_start + i];
        }
        if (set_passage) last_block[1] = (uint8_t)last_passage;
        if (set_stage) last_block[2] = (uint8_t)last_stage;
        if (set_step) last_block[3] = (uint8_t)last_step;
        write_last_checksum(last_block);
    }
    write_save_checksum(block);
    uint32_t starts[2][2] = {{0x100u, 0x300u}, {0x500u, 0x700u}};
    uint32_t last_starts[2][2] = {{0x2e0u, 0x4e0u}, {0x6e0u, 0x8e0u}};
    for (uint32_t copy = 0; copy < 2; copy++) {
        uint32_t dst = starts[slot][copy];
        if (dst + SAVE_BLOCK_SIZE <= payload_len) {
            for (uint32_t i = 0; i < SAVE_BLOCK_SIZE; i++) {
                payload[dst + i] = block[i];
            }
        }
        if (has_last_update) {
            uint32_t last_dst = last_starts[slot][copy];
            if (last_dst + LAST_BLOCK_SIZE <= payload_len) {
                for (uint32_t i = 0; i < LAST_BLOCK_SIZE; i++) {
                    payload[last_dst + i] = last_block[i];
                }
            }
        }
    }
    builder b;
    uint32_t encoded_len = ((payload_len + 2u) / 3u) * 4u;
    b_init(&b, encoded_len + 512u);
    b_str(&b, "{\"payload\":\"");
    b_base64(&b, payload, payload_len);
    b_str(&b, "\",\"changed\":{},\"integritySteps\":[\"rebuilt Wario Land 4 save block checksum\",\"mirrored edited slot to primary and backup save blocks\"]}");
    return finish(&b);
}

__attribute__((export_name("rsm_call")))
uint64_t rsm_call(int32_t command_ptr, int32_t command_len, int32_t input_ptr, int32_t input_len) {
    if (command_ptr <= 0 || command_len <= 0 || input_ptr <= 0 || input_len < 0) {
        return error_response("invalid ABI pointer or length");
    }
    const uint8_t *command = (const uint8_t *)(uintptr_t)command_ptr;
    const uint8_t *input = (const uint8_t *)(uintptr_t)input_ptr;
    if (command_len == 12 && bytes_eq(command, "capabilities", 12)) {
        return capabilities_response();
    }
    if (command_len == 5 && bytes_eq(command, "parse", 5)) {
        return parse_response(input, (uint32_t)input_len);
    }
    if (command_len == 10 && bytes_eq(command, "readCheats", 10)) {
        return read_response(input, (uint32_t)input_len);
    }
    if (command_len == 11 && bytes_eq(command, "applyCheats", 11)) {
        return apply_response(input, (uint32_t)input_len);
    }
    return error_response("unsupported command");
}
