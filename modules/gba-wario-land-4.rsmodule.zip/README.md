# Wario Land 4 Game Support Module

This module supports the GBA save structure for Wario Land 4 using structural markers and checksums from the documented save layout.

Runtime checks require a recognized raw GBA save size, the Wario Land 4 global header, the selected-save marker, and at least one valid checksummed save-file block. The parser edits only Save File A or B blocks and mirrors edited slot data to that slot's primary and backup copies.

Supported fields:

- Hard Mode beaten global unlock state.
- Collectible flags for every normal stage and Golden Passage, using the documented Hall of Hieroglyphs bit meanings confirmed against repeated `0x2f`/`0x3f` stage values in a real SaveRAM sample.
- Boss beaten state for Spoiled Rotten and the four treasure-bearing passage bosses.
- Boss treasure chest count for the four treasure-bearing passage bosses, stored as the documented low two-bit chest count.
- Documented high-score fields, exposed as the displayed score. Values must be multiples of 10 because the save stores score divided by 10.
- Last-visited-stage passage, stage number, and map step counter fields, with checksum repair and primary/backup mirroring.

Known limitations:

- The module does not edit unknown/padding values.
- The module does not expose raw writes or arbitrary flag masks.
- Last-visited reload-point text is preserved instead of rewritten because the text token table is not fully documented.
- Golden Diva's boss field is not exposed yet because the real SaveRAM sample uses a divergent `0x10` value and the safe bit semantics are not proven.

Research sources:

- WarioWiki, "Wario Land 4 Save File Structure".
- TASVideos user file 638204818075722537, which includes a BizHawk MovieSaveRam.bin for Wario Land 4 (USA, Europe), used to sanity-check magic markers, mirrored save blocks, and checksum repair.

Build note:

- `parser.wasm` was built from `src/parser.c` with `zig cc` for `wasm32-freestanding`, no entry point, exported memory, and 1 MiB initial memory so it fits RetroSaveManager's 16-page runtime module limit.
